# Desktop notification utilities
