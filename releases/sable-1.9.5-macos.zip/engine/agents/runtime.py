
"""AgentRuntime — spawns, tracks, and manages background agent tasks."""
from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import time
from pathlib import Path
from typing import Any, Callable, Coroutine

from engine.agents.agent import Agent
from engine.agents.protocol import AgentEvent, AgentResult, AgentStatus, TaskAssignment
from engine.agents.registry import get_role_config, get_next_account
from engine.agents.resilience import CircuitBreaker

logger = logging.getLogger("sable")



# Type for the SSE push callback: async fn(chat_id, event_dict)
EventCallback = Callable[[str, dict[str, Any]], Coroutine[Any, Any, None]]


class AgentRuntime:
    """Manages agent lifecycle: spawn → run → complete/fail.

    Concurrency controlled via semaphores (per-backend + global).
    Circuit breakers prevent hammering dead providers.
    """

    # Agents older than this are pruned on next spawn/completion cycle
    _PRUNE_AFTER_SECONDS: float = 3600.0  # 1 hour

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        cfg = config or {}
        conc = cfg.get("concurrency", {})
        res = cfg.get("resilience", {})

        self._agents: dict[str, Agent] = {}
        self._tasks: dict[str, asyncio.Task] = {}
        self._spawn_lock = asyncio.Lock()
        self._max_agents: int = conc.get("global_max", 5)
        self._max_depth: int = 3

        # Per-backend semaphores
        self._ds_sem = asyncio.Semaphore(conc.get("deepseek_max", 5))
        self._qwen_sem = asyncio.Semaphore(conc.get("qwen_max", 1))
        self._global_sem = asyncio.Semaphore(self._max_agents)

        # Circuit breakers
        threshold = res.get("circuit_breaker_threshold", 5)
        reset = res.get("circuit_breaker_reset_seconds", 60)
        self._breakers: dict[str, CircuitBreaker] = {
            "deepseek": CircuitBreaker(threshold, reset),
            "qwen": CircuitBreaker(threshold, reset),
            "gemini": CircuitBreaker(threshold, reset),
            "groq": CircuitBreaker(threshold, reset),
            "mistral": CircuitBreaker(threshold, reset),
        }

        # Loop limits (max iterations)
        limits = cfg.get("limits", {})
        self._limits: dict[str, int] = {
            "max_iterations": limits.get("max_iterations", 25),
        }

        # SSE event callback (set by API layer)
        self._event_callback: EventCallback | None = None

        # Main event loop reference (set from the async layer before any thread-pool dispatch)
        self._loop: asyncio.AbstractEventLoop | None = None

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def set_event_callback(self, callback: EventCallback) -> None:
        """Set the async callback that pushes events to SSE clients."""
        self._event_callback = callback

    def update_config(self, config: dict[str, Any]) -> None:
        """Hot-reload concurrency/resilience/limits settings."""
        conc = config.get("concurrency", {})
        res = config.get("resilience", {})
        limits = config.get("limits", {})
        self._max_agents = conc.get("global_max", self._max_agents)
        # Recreate semaphores with new limits (safe — asyncio.Semaphore has no running-state leak)
        if "deepseek_max" in conc:
            self._ds_sem = asyncio.Semaphore(conc["deepseek_max"])
        if "qwen_max" in conc:
            self._qwen_sem = asyncio.Semaphore(conc["qwen_max"])
        if "global_max" in conc:
            self._global_sem = asyncio.Semaphore(conc["global_max"])
        # Update breaker thresholds
        for breaker in self._breakers.values():
            breaker.threshold = res.get("circuit_breaker_threshold", breaker.threshold)
            breaker.reset_timeout = res.get("circuit_breaker_reset_seconds", breaker.reset_timeout)
        # Update loop limits
        if limits:
            self._limits["max_iterations"] = limits.get("max_iterations", self._limits["max_iterations"])

    # ------------------------------------------------------------------
    # Spawning
    # ------------------------------------------------------------------

    @property
    def active_count(self) -> int:
        return sum(1 for a in self._agents.values() if a.status == AgentStatus.RUNNING)

    def _prune_stale_agents(self) -> None:
        """Remove completed/failed agents older than _PRUNE_AFTER_SECONDS."""
        cutoff = time.time() - self._PRUNE_AFTER_SECONDS
        stale_ids = [
            aid for aid, a in self._agents.items()
            if a.status != AgentStatus.RUNNING
            and a.completed_at is not None
            and a.completed_at < cutoff
        ]
        for aid in stale_ids:
            del self._agents[aid]
            self._tasks.pop(aid, None)
        if stale_ids:
            logger.debug("Pruned %d stale agents", len(stale_ids))

    async def spawn(self, assignment: TaskAssignment, chat_id: str) -> Agent:
        """Spawn a new agent. Non-blocking — returns immediately."""
        async with self._spawn_lock:
            # Prune old agents to free slots
            self._prune_stale_agents()

            if self.active_count >= self._max_agents:
                raise RuntimeError(f"Max agents ({self._max_agents}) reached")

            # Depth check
            depth = 0
            if assignment.parent_agent_id:
                parent = self._agents.get(assignment.parent_agent_id)
                depth = (parent.depth + 1) if parent else 1
            if depth >= self._max_depth:
                raise RuntimeError(f"Max depth ({self._max_depth}) reached")

            # Resolve config: tag attrs > role_overrides > defaults
            role_cfg = get_role_config(assignment.role)
            # Resolve browser account: explicit > pool (skip in-use) > None
            browser_dir = assignment.browser_data_dir
            if not browser_dir:
                in_use = {a.browser_data_dir for a in self._agents.values() if a.browser_data_dir and a.status == AgentStatus.RUNNING}
                assigned_account = get_next_account(assignment.role, in_use)
                if assigned_account:
                    from engine.config import _SYSTEM as _AGENT_SYSTEM_DIR
                    acct_profile = _AGENT_SYSTEM_DIR / assigned_account
                    if acct_profile.is_dir():
                        browser_dir = str(acct_profile)
                    else:
                        browser_dir = assigned_account  # fallback to raw name if dir missing

            agent = Agent(
                role=assignment.role,
                task=assignment.task,
                context=assignment.context,
                instruction=assignment.instruction,
                model=assignment.model or role_cfg.default_model,
                browser_data_dir=browser_dir,
                parent_id=assignment.parent_agent_id,
                chat_id=chat_id,
                depth=depth,
                collect=assignment.collect,
            )

            # Attach fallback chain from role config
            agent.model_chain = role_cfg.model_chain

            self._agents[agent.id] = agent

        # DB persist — register as a chat so it appears in sidebar
        from server.database import insert_agent_run, ensure_chat, touch_chat
        ensure_chat(
            chat_id=agent.id,
            title=f"[{agent.role}] {agent.task[:60]}",
            parent_id=chat_id,
            mode="agent",
        )
        touch_chat(agent.id)

        insert_agent_run(
            agent_id=agent.id,
            chat_id=chat_id,
            role=agent.role,
            task=agent.task,
            path=agent.path,
            depth=depth,
            parent_agent_id=agent.parent_id,
            model=agent.model,
            browser_data_dir=agent.browser_data_dir,
        )

        # Emit spawn event
        await self._emit(chat_id, AgentEvent(
            type="agent_spawned",
            agent_id=agent.id,
            data={
                "role": agent.role,
                "task": agent.task,
                "model": agent.model,
            },
        ))

        return agent

    # ------------------------------------------------------------------
    # Waiting (collect mode)
    # ------------------------------------------------------------------

    def _to_awaitable(self, task):
        """Convert a task/future to an asyncio-awaitable."""
        if isinstance(task, concurrent.futures.Future):
            return asyncio.wrap_future(task)
        return task

    async def wait(self, agent_id: str, timeout: float | None = None) -> AgentResult:
        """Wait for a single agent to finish."""
        task = self._tasks.get(agent_id)
        if task and not task.done():
            await asyncio.wait_for(self._to_awaitable(task), timeout=timeout)
        return self._to_result(agent_id)

    async def wait_all(self, agent_ids: list[str], timeout: float | None = None) -> list[AgentResult]:
        """Wait for multiple agents. Returns results in order."""
        tasks = [self._to_awaitable(self._tasks[aid]) for aid in agent_ids if aid in self._tasks and not self._tasks[aid].done()]
        if tasks:
            await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True), timeout=timeout)
        return [self._to_result(aid) for aid in agent_ids if aid in self._agents]

    # ------------------------------------------------------------------
    # Control
    # ------------------------------------------------------------------

    async def kill(self, agent_id: str) -> None:
        """Cancel a running agent."""
        agent = self._agents.get(agent_id)
        if agent:
            agent.cancelled = True  # Checked between tool calls in the loop
        task = self._tasks.get(agent_id)
        if task and not task.done():
            task.cancel()
        if agent:
            agent.mark_failed("Killed by orchestrator")
            from server.database import update_agent_status
            update_agent_status(agent_id, "killed", error="Killed by orchestrator")

    def list_agents(self, chat_id: str | None = None) -> list[Agent]:
        agents = list(self._agents.values())
        if chat_id:
            agents = [a for a in agents if a.chat_id == chat_id]
        return agents

    def get_agent(self, agent_id: str) -> Agent | None:
        return self._agents.get(agent_id)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _emit(self, chat_id: str | None, event: AgentEvent) -> None:
        """Push event to SSE clients via callback."""
        if chat_id and self._event_callback:
            payload = {"type": event.type, "agent_id": event.agent_id, "data": event.data}
            try:
                await self._event_callback(chat_id, payload)
            except Exception as exc:
                logger.debug("SSE emit failed: %s", exc)

    def _to_result(self, agent_id: str) -> AgentResult:
        agent = self._agents[agent_id]
        return AgentResult(
            agent_id=agent.id,
            role=agent.role,
            status=agent.status,
            summary=agent.result or agent.error or "",
            tokens_used=agent.tokens_used,
            error=agent.error,
            duration_seconds=agent.duration,
            skills_used=agent.skills_used,
        )


# ------------------------------------------------------------------
# Module-level singleton
# ------------------------------------------------------------------

_runtime: AgentRuntime | None = None


def get_runtime() -> AgentRuntime:
    """Get or create the AgentRuntime singleton."""
    global _runtime
    if _runtime is None:
        _runtime = AgentRuntime()
    return _runtime
