"""FastAPI-friendly service layer for Sable chat engine."""

from __future__ import annotations

import asyncio
import codecs
import json
import logging
import os
import signal
import sys
from collections.abc import AsyncGenerator
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx  # kept for non-Qwen calls (DeepSeek upload, etc.)
from curl_cffi.requests import AsyncSession as CffiSession

from engine.config import (
    URL,
    STOP_URL,
    get_qwen_tokens_for_account,
    save_qwen_tokens_for_account,
    mark_account_exhausted,
)
from engine.payloads import build_body
from engine.session import BrowserManager, create_new_chat, sanitize_fetch_headers

logger = logging.getLogger("sable")

# --- Raw response logger (Qwen only, server path) ---
_QWEN_LOG_DIR = Path(__file__).resolve().parent.parent / "output" / "qwen_raw"
_QWEN_LOG_DIR.mkdir(parents=True, exist_ok=True)
_QWEN_CHUNK_DIR = _QWEN_LOG_DIR.parent / "qwen_chunks"
_QWEN_CHUNK_DIR.mkdir(parents=True, exist_ok=True)


def _log_qwen_raw_line(line: str) -> None:
    """Append a single raw SSE line to today's log file."""
    logfile = _QWEN_LOG_DIR / f"{datetime.now():%Y-%m-%d}.txt"
    with open(logfile, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now():%H:%M:%S.%f}] {line}\n")


def _log_qwen_stream_chunk(phase: str, content: str) -> None:
    """Log a single parsed streaming content delta."""
    if not content:
        return
    logfile = _QWEN_CHUNK_DIR / f"{datetime.now():%Y-%m-%d}.txt"
    with open(logfile, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now():%H:%M:%S.%f}] [{phase}] {content!r}\n")



class ChatService:
    """Wraps the existing Sable engine into an async, coroutine-safe API-friendly layer.

    NOTE: BrowserManager and create_new_chat (session.py) are async (Playwright's
    async API), so every method here that touches them is async too. Callers
    (e.g. FastAPI route handlers) need `await service.foo()` and
    `async for event in service.stream_events(...)` instead of the old sync calls.
    """

    def __init__(self, user_data_dir: str | None = None) -> None:
        if user_data_dir is None:
            from engine.config import BROWSER_DATA_DIR
            user_data_dir = str(BROWSER_DATA_DIR)
        self._browser = BrowserManager(user_data_dir=user_data_dir)
        self._headers: dict[str, str] | None = None
        # Which account self._headers belong to (guards against fast double-switch
        # races where a stale in-memory header set outlives the active symlink).
        self._headers_account: str | None = None
        self._lock = asyncio.Lock()
        # Derive account name from user_data_dir for token lookup
        # e.g. ".../system/browser-data-acc3" → "browser-data-acc3"
        import re
        basename = Path(user_data_dir).name
        if re.match(r"browser-data-acc\d+$", basename):
            self._account_override: str | None = basename
        else:
            self._account_override = None

        # Scoped browser registry for isolated streams (e.g. critique agents)
        # Each bdd path gets its own BrowserManager + header cache, completely
        # independent from the default self._browser / self._headers.
        self._scoped_browsers: dict[str, BrowserManager] = {}
        self._scoped_headers: dict[str, dict[str, str]] = {}
        self._scoped_accounts: dict[str, str] = {}

    def _get_debug_account_info(self, bdd: str | None = None) -> dict:
        """Return debug info about which account/browser profile is actually being used."""
        from engine.config import _resolve_active_account
        account = self._resolve_account(bdd)
        browser = self._get_browser(bdd)
        browser_dir = str(browser.user_data_dir) if browser else "unknown"
        # Get cached token snippet (first 40 chars of cookies for identification)
        from engine.config import get_qwen_tokens_for_account
        tok = get_qwen_tokens_for_account(account)
        cookie_snippet = (tok.get("cookies", "")[:60] + "...") if tok and tok.get("cookies") else "none"
        has_bx_ua = bool(tok and tok.get("bx_ua"))
        has_umid = bool(tok and tok.get("bx_umidtoken"))
        return {
            "account": account,
            "account_override": self._account_override,
            "active_account_file": _resolve_active_account(),
            "browser_data_dir": browser_dir,
            "cookie_snippet": cookie_snippet,
            "has_bx_ua": has_bx_ua,
            "has_bx_umidtoken": has_umid,
        }

    def _mark_exhausted(self) -> None:
        """Mark the current account as quota-exhausted."""
        from engine.config import _resolve_active_account
        account = self._account_override or _resolve_active_account()
        mark_account_exhausted(account)

    async def close(self) -> None:
        async with self._lock:
            # Close every browser we own: the default plus any scoped ones
            # (provider-pinned accounts, isolated streams).
            for browser in list(self._scoped_browsers.values()):
                try:
                    await browser.close()
                except Exception as exc:
                    logger.warning("scoped browser close failed: %s", exc)
            self._scoped_browsers.clear()
            self._scoped_headers.clear()
            self._scoped_accounts.clear()
            await self._browser.close()
            self._headers = None
            self._headers_account = None

    async def restart_browser(self, headless: bool | None = None) -> None:
        async with self._lock:
            await self._browser.restart(headless=headless)
            self._headers = None
            self._headers_account = None

    @property
    def browser_headless(self) -> bool:
        return self._browser.headless

    def _get_browser(self, bdd: str | None) -> BrowserManager:
        """Return the right BrowserManager. bdd=None → default self._browser."""
        if not bdd:
            return self._browser
        if bdd not in self._scoped_browsers:
            self._scoped_browsers[bdd] = BrowserManager(user_data_dir=bdd)
        return self._scoped_browsers[bdd]

    def _browser_for_provider(self, provider: str) -> BrowserManager:
        """Resolve the BrowserManager a provider should use.

        Providers pinned to an account in settings (provider_accounts) get an
        isolated browser for that profile. Unpinned providers follow the global
        active account and share the default browser.

        Browsers are keyed by data dir — so two providers pinned to the SAME
        account share one BrowserManager (Chromium permits one process per
        profile); different accounts get fully independent browsers that can
        run concurrently.
        """
        from engine.config import get_provider_browser_dir
        try:
            target = str(get_provider_browser_dir(provider))
        except Exception:
            return self._browser
        default_dir = str(self._browser.user_data_dir)
        if target == default_dir:
            return self._browser
        return self._get_browser(target)

    def _resolve_account(self, bdd: str | None, provider: str | None = None) -> str:
        """Resolve account name for a given browser data dir.

        For the default path (no bdd), a provider pin in settings wins, then
        the service override, then the global active account.
        """
        import re as _re
        from engine.config import _resolve_active_account, get_provider_account
        if bdd:
            basename = Path(bdd).name
            if _re.match(r"browser-data-acc\d+$", basename):
                return basename
        if provider:
            pinned = get_provider_account(provider)
            if pinned:
                return pinned
        return self._account_override or _resolve_active_account()

    async def close_scoped(self, bdd: str) -> None:
        """Close and clean up a scoped browser instance."""
        if bdd in self._scoped_browsers:
            async with self._lock:
                await self._scoped_browsers[bdd].close()
                self._scoped_browsers.pop(bdd, None)
                self._scoped_headers.pop(bdd, None)
                self._scoped_accounts.pop(bdd, None)

    async def _ensure_headers(self, bdd: str | None = None) -> dict[str, str]:
        account = self._resolve_account(bdd, provider=None if bdd else "qwen")

        # ── Default path (bdd=None): existing behavior, untouched ──
        if not bdd:
            if self._headers and self._headers_account == account:
                return self._headers
            cached = get_qwen_tokens_for_account(account)
            if cached and cached.get("cookies"):
                from engine.session import build_headers
                self._headers = build_headers(
                    cookies=cached["cookies"],
                    bx_ua=cached.get("bx_ua"),
                    bx_umidtoken=cached.get("bx_umidtoken"),
                )
                self._headers_account = account
                logger.info("Loaded cached Qwen WAF tokens for %s", account)
                return self._headers
            async with self._lock:
                if not self._headers or self._headers_account != account:
                    browser = self._browser_for_provider("qwen")
                    try:
                        await browser.start()
                        self._headers = await browser.get_fresh_headers()
                        self._headers_account = account
                        save_qwen_tokens_for_account(
                            cookies=self._headers.get("Cookie", ""),
                            bx_ua=self._headers.get("bx-ua", ""),
                            bx_umidtoken=self._headers.get("bx-umidtoken", ""),
                            account=account,
                        )
                    except Exception as exc:
                        logger.warning("Browser launch failed for %s: %s: %s", account, type(exc).__name__, exc)
                        # Fall back to cached tokens on disk before giving up
                        cached = get_qwen_tokens_for_account(account)
                        if cached and cached.get("cookies"):
                            from engine.session import build_headers
                            self._headers = build_headers(
                                cookies=cached["cookies"],
                                bx_ua=cached.get("bx_ua"),
                                bx_umidtoken=cached.get("bx_umidtoken"),
                            )
                            self._headers_account = account
                            logger.info("Fell back to cached Qwen WAF tokens for %s after browser failure", account)
                        else:
                            raise RuntimeError(
                                f"Browser launch failed for {account} and no cached tokens available on disk"
                            ) from exc
                return self._headers

        # ── Scoped path (bdd set): isolated browser + header cache ──
        if bdd in self._scoped_headers and self._scoped_accounts.get(bdd) == account:
            return self._scoped_headers[bdd]
        cached = get_qwen_tokens_for_account(account)
        if cached and cached.get("cookies"):
            from engine.session import build_headers
            headers = build_headers(
                cookies=cached["cookies"],
                bx_ua=cached.get("bx_ua"),
                bx_umidtoken=cached.get("bx_umidtoken"),
            )
            self._scoped_headers[bdd] = headers
            self._scoped_accounts[bdd] = account
            logger.info("Loaded cached Qwen WAF tokens for %s (scoped: %s)", account, bdd)
            return headers
        async with self._lock:
            if bdd in self._scoped_headers and self._scoped_accounts.get(bdd) == account:
                return self._scoped_headers[bdd]
            browser = self._get_browser(bdd)
            try:
                await browser.start()
                headers = await browser.get_fresh_headers()
                self._scoped_headers[bdd] = headers
                self._scoped_accounts[bdd] = account
                save_qwen_tokens_for_account(
                    cookies=headers.get("Cookie", ""),
                    bx_ua=headers.get("bx-ua", ""),
                    bx_umidtoken=headers.get("bx-umidtoken", ""),
                    account=account,
                )
                return headers
            except Exception as exc:
                logger.warning("Browser launch failed for %s (scoped %s): %s: %s", account, bdd, type(exc).__name__, exc)
                cached = get_qwen_tokens_for_account(account)
                if cached and cached.get("cookies"):
                    from engine.session import build_headers
                    headers = build_headers(
                        cookies=cached["cookies"],
                        bx_ua=cached.get("bx_ua"),
                        bx_umidtoken=cached.get("bx_umidtoken"),
                    )
                    self._scoped_headers[bdd] = headers
                    self._scoped_accounts[bdd] = account
                    logger.info("Fell back to cached Qwen WAF tokens for %s (scoped) after browser failure", account)
                    return headers
                raise RuntimeError(
                    f"Browser launch failed for {account} (scoped {bdd}) and no cached tokens available on disk"
                ) from exc

    async def _refresh_headers(self, bdd: str | None = None) -> dict[str, str]:
        account = self._resolve_account(bdd)
        browser = self._get_browser(bdd)
        async with self._lock:
            try:
                await browser.start()
                headers = await browser.get_fresh_headers()
                if not bdd:
                    self._headers = headers
                    self._headers_account = account
                else:
                    self._scoped_headers[bdd] = headers
                    self._scoped_accounts[bdd] = account
                save_qwen_tokens_for_account(
                    cookies=headers.get("Cookie", ""),
                    bx_ua=headers.get("bx-ua", ""),
                    bx_umidtoken=headers.get("bx-umidtoken", ""),
                    account=account,
                )
                return headers
            except Exception as exc:
                logger.warning("Browser refresh failed for %s: %s: %s", account, type(exc).__name__, exc)
                # Fall back to cached tokens before giving up
                cached = get_qwen_tokens_for_account(account)
                if cached and cached.get("cookies"):
                    from engine.session import build_headers
                    headers = build_headers(
                        cookies=cached["cookies"],
                        bx_ua=cached.get("bx_ua"),
                        bx_umidtoken=cached.get("bx_umidtoken"),
                    )
                    if not bdd:
                        self._headers = headers
                        self._headers_account = account
                    else:
                        self._scoped_headers[bdd] = headers
                        self._scoped_accounts[bdd] = account
                    logger.info("Fell back to cached Qwen WAF tokens for %s after refresh failure", account)
                    return headers
                raise RuntimeError(
                    f"Browser refresh failed for {account} and no cached tokens available on disk"
                ) from exc

    async def warmup(self, account: str | None = None) -> None:
        """Pre-load WAF headers and keep the browser alive for live header refresh.

        Loads cached tokens instantly so the first request isn't delayed by a
        Chromium launch, then starts the browser in the background so that
        subsequent requests can call get_live_headers() for fresh bx-ua/cookies.

        Pass account= to pin the target — background callers MUST, since the
        active-profile symlink can move between scheduling and execution.
        """
        from engine.config import _resolve_active_account
        account = account or self._account_override or _resolve_active_account()
        # Fast path: headers for this account already in memory
        if self._headers and self._headers_account == account:
            return
        # Medium path: per-account token cache on disk — load instantly,
        # but DON'T return yet. We still need to start the browser below
        # so get_live_headers() has a live context to read from.
        cached = get_qwen_tokens_for_account(account)
        if cached and cached.get("cookies"):
            from engine.session import build_headers
            self._headers = build_headers(
                cookies=cached["cookies"],
                bx_ua=cached.get("bx_ua"),
                bx_umidtoken=cached.get("bx_umidtoken"),
            )
            self._headers_account = account
            logger.info("Warmup: loaded cached Qwen WAF tokens for %s", account)
        # Guard: no valid profile → skip browser launch entirely
        # Slow path: launch browser to fetch fresh headers
        # (BrowserManager.start() guards against missing profiles)
        async with self._lock:
            try:
                await self._browser.start()
                if not self._headers or self._headers_account != account:
                    self._headers = await self._browser.get_fresh_headers()
                    self._headers_account = account
                    # Persist WAF tokens to per-account cache
                    save_qwen_tokens_for_account(
                        cookies=self._headers.get("Cookie", ""),
                        bx_ua=self._headers.get("bx-ua", ""),
                        bx_umidtoken=self._headers.get("bx-umidtoken", ""),
                        account=account,
                    )
                else:
                    logger.info("Warmup: browser started for live header refresh (using cached headers)")
            except Exception as exc:
                # Browser launch failed, but don't nuke cached headers — they're
                # still valid for HTTP requests, just without live refresh capability.
                logger.warning("Warmup browser start failed: %s: %s (cached headers still usable)", type(exc).__name__, exc)

    async def force_refresh_waf(self, account: str | None = None) -> None:
        """Always launch browser to collect fresh WAF tokens, ignoring cache.

        Designed for post-switch background warmup — never blocks the main
        request path. Updates in-memory headers AND persists to disk cache.
        """
        from engine.config import _resolve_active_account
        account = account or self._account_override or _resolve_active_account()
        async with self._lock:
            try:
                await self._browser.start()
                self._headers = await self._browser.get_fresh_headers()
                self._headers_account = account
                save_qwen_tokens_for_account(
                    cookies=self._headers.get("Cookie", ""),
                    bx_ua=self._headers.get("bx-ua", ""),
                    bx_umidtoken=self._headers.get("bx-umidtoken", ""),
                    account=account,
                )
                logger.info("Force-refreshed WAF tokens for %s via browser", account)
            except Exception as exc:
                logger.warning("Force WAF refresh failed for %s: %s: %s", account, type(exc).__name__, exc)
                # Fall back to cached tokens so we're not left empty-handed
                cached = get_qwen_tokens_for_account(account)
                if cached and cached.get("cookies"):
                    from engine.session import build_headers
                    self._headers = build_headers(
                        cookies=cached["cookies"],
                        bx_ua=cached.get("bx_ua"),
                        bx_umidtoken=cached.get("bx_umidtoken"),
                    )
                    self._headers_account = account
                    logger.info("Fell back to cached WAF tokens for %s", account)
                else:
                    self._headers = None
                    self._headers_account = None

    async def refresh_all_provider_tokens(self, account: str | None = None) -> dict[str, bool]:
        """Refresh Qwen WAF + DeepSeek + z.ai + Gemini auth for `account`.

        Single entry point used by startup and post-account-switch warmup so
        every provider's credentials track the active browser profile. Each
        provider is isolated: one failure never blocks the others, and the
        result map reports what actually succeeded.

        account=None resolves to the active profile (pinned/override aware).
        """
        results: dict[str, bool] = {
            "qwen": False, "deepseek": False, "zai": False, "gemini": False,
        }

        # --- Qwen WAF (cookies + bx-ua) ---
        try:
            await self.force_refresh_waf(account=account)
            results["qwen"] = bool(self._headers and self._headers.get("Cookie"))
        except Exception as exc:
            logger.warning("refresh_all: Qwen WAF failed: %s: %s", type(exc).__name__, exc)

        # --- DeepSeek (browser localStorage bearer) ---
        try:
            from connectors.deepseek.client import (
                get_deepseek_client, get_own_token_for_account as _ds_own,
            )
            ds_client = get_deepseek_client()
            own = _ds_own(account) if account else None
            if own:
                ds_client.set_token(own, account=account)
            else:
                ds_token = await self.refresh_deepseek_token()
                if ds_token:
                    # Only persist under the account if it's genuinely ours,
                    # else keep in-memory so we don't smear a foreign token.
                    fresh_own = _ds_own(account) if account else None
                    if account and fresh_own == ds_token:
                        ds_client.set_token(ds_token, account=account)
                    else:
                        ds_client.set_token(ds_token, account=account, persist=False)
            results["deepseek"] = bool(ds_client.token)
        except Exception as exc:
            logger.warning("refresh_all: DeepSeek failed: %s: %s", type(exc).__name__, exc)

        # --- z.ai (browser JWT) ---
        try:
            from connectors.zai.client import get_client as _zai_client
            zai_token = await self.refresh_zai_token()
            if zai_token:
                _zai_client().set_token(zai_token)
                results["zai"] = True
        except Exception as exc:
            logger.warning("refresh_all: z.ai failed: %s: %s", type(exc).__name__, exc)

        # --- Gemini (Google auth cookies → disk snapshot) ---
        try:
            jar = await self.get_gemini_cookies()
            if jar:
                from connectors.gemini_web.client import get_client as _gw
                _gw().invalidate_jar()
                results["gemini"] = True
        except Exception as exc:
            logger.warning("refresh_all: Gemini failed: %s: %s", type(exc).__name__, exc)

        logger.info(
            "refresh_all: account=%s qwen=%s deepseek=%s zai=%s gemini=%s",
            account or "active", results["qwen"], results["deepseek"],
            results["zai"], results["gemini"],
        )
        return results

    async def refresh_deepseek_token(self) -> str:
        """Extract a fresh DeepSeek token. Reuses an already-running browser
        (e.g. one a cold warmup left open); closes it only if this call
        launched it AND warmup hasn't started it for live header refresh."""
        async with self._lock:
            opened_here = not self._browser.is_running
            await self._browser.start()
            try:
                return await self._browser.extract_deepseek_token()
            finally:
                # Never close the browser here — warmup() intentionally keeps
                # it alive so get_live_headers() can read fresh tokens per-request.
                # Only close if we somehow launched it outside of warmup context
                # and no headers are loaded yet (edge case).
                if opened_here and not self._headers:
                    await self._browser.close()

    async def get_zai_page(self):
        """Return a Playwright page on chat.z.ai from the z.ai browser context.

        Uses the provider's pinned account if set (provider_accounts.zai),
        otherwise the shared default browser. Chromium allows one process per
        profile, so the connector must not launch its own.
        """
        browser = self._browser_for_provider("zai")
        # z.ai captcha minting only works in a headed browser (Aliyun rejects
        # headless Chromium). Promote the browser if it's headless.
        await browser.ensure_headed()
        await browser.start()
        ctx = browser.context
        if ctx is None:
            raise RuntimeError("Browser context is not available")
        page = getattr(self, "_zai_page", None)
        bound = getattr(self, "_zai_page_browser", None)
        try:
            # Only reuse if the page belongs to the SAME browser (a pin change
            # swaps the browser, so a stale page from the old context is invalid).
            if page is not None and bound is browser and not page.is_closed():
                return page
        except Exception:
            pass
        page = await ctx.new_page()
        await page.goto("https://chat.z.ai", wait_until="domcontentloaded", timeout=20000)
        for _ in range(12):
            try:
                if await page.evaluate("() => !!localStorage.getItem('token')"):
                    break
            except Exception:
                break
            await page.wait_for_timeout(500)
        # NOTE: the Aliyun captcha SDK is lazy-loaded by the z.ai SPA on first
        # send — window.initAliyunCaptcha is intentionally absent on a fresh
        # page. The connector bootstraps it in-page before minting, so there's
        # nothing to wait for here.
        self._zai_page = page
        self._zai_page_browser = browser
        return page

    async def refresh_zai_token(self) -> str:
        """Extract a fresh z.ai JWT from the provider's browser profile.

        Uses the z.ai pinned account if set, else the shared default browser.
        """
        browser = self._browser_for_provider("zai")
        async with self._lock:
            await browser.start()
            return await browser.extract_zai_token()

    async def get_gemini_cookies(self) -> dict[str, str]:
        """Return Google auth cookies for gemini.google.com.

        Order: ACTIVE account (live browser read) -> disk snapshot fallback.
        A successful live read is snapshotted to disk per account so later
        calls still work when the active account has no Gemini login.

        The connector sends via curl_cffi, but auth cookies live encrypted in
        Chromium's store — only a live context can read them. We reuse the
        shared BrowserManager to avoid the profile-lock conflict.
        """
        from connectors.gemini_web import auth as _gauth

        browser = self._browser_for_provider("gemini_web")
        active_dir = browser.user_data_dir

        # 1) Live read from the provider's account (pinned or active)
        try:
            async with self._lock:
                await browser.start()
                ctx = browser.context
                if ctx is not None:
                    raw = await ctx.cookies("https://gemini.google.com")
                    jar = {c["name"]: c["value"] for c in raw}
                    if _gauth.has_google_auth(jar):
                        _gauth.save_gemini_auth(active_dir, jar)
                        return jar
                    logger.info("account %s has no Gemini auth; trying disk",
                                Path(active_dir).name)
        except Exception as exc:
            logger.warning("live Gemini cookie read failed (%s); trying disk", exc)

        # 2) Fall back to the freshest valid snapshot on disk
        best = _gauth.load_best_gemini_auth()
        if best is not None:
            acct, jar = best
            logger.info("using saved Gemini auth from %s", acct)
            return jar

        raise RuntimeError(
            "No Gemini auth: account has none and no valid disk snapshot"
        )

    async def create_chat(self, model: str | None = None, bdd: str | None = None) -> str | None:
        headers = await self._ensure_headers(bdd)
        chat_id = await create_new_chat(headers, model=model)
        if not chat_id:
            headers = await self._refresh_headers(bdd)
            chat_id = await create_new_chat(headers, model=model)
        return chat_id

    async def upload_file(
        self, file_path: str, bdd: str | None = None
    ) -> dict[str, Any] | None:
        """Upload any file (image or document) to Qwen via STS + OSS."""
        headers = await self._ensure_headers(bdd)
        return await self._browser.upload_file(
            file_path,
            cookies=headers.get("Cookie"),
            bx_ua=headers.get("bx-ua"),
            bx_umidtoken=headers.get("bx-umidtoken"),
        )

    async def upload_image(self, image_path: str) -> dict[str, Any] | None:
        headers = await self._ensure_headers()
        return await self._browser.upload_image(
            image_path,
            cookies=headers.get("Cookie"),
            bx_ua=headers.get("bx-ua"),
            bx_umidtoken=headers.get("bx-umidtoken"),
        )

    async def upload_deepseek_file(
        self,
        file_path: str,
        thinking_enabled: bool = False,
    ) -> dict[str, Any]:
        """Upload a file for DeepSeek (unified) via pure httpx (no browser)."""
        from connectors.deepseek.upload import upload_file

        return await upload_file(
            file_path,
            thinking_enabled=thinking_enabled,
        )

    async def sync_context(self, project_id: str | None = None, custom_instructions: str | None = None, layout_mode: str | None = None, bdd: str | None = None) -> bool:
        browser = self._get_browser(bdd)
        headers = self._scoped_headers.get(bdd) if bdd else self._headers
        if headers:
            return await browser.sync_context(headers=headers, project_id=project_id, custom_instructions=custom_instructions, layout_mode=layout_mode)
        return await browser.sync_context(project_id=project_id, custom_instructions=custom_instructions, layout_mode=layout_mode)

    async def _stop_upstream_generation(self, chat_id: str, response_id: str | None = None) -> bool:
        """Call Qwen's stop API to halt server-side token generation.

        Mirrors what chat.qwen.ai does when you press the stop button:
        POST /api/v2/chat/completions/stop with {chat_id, response_id}.
        Returns True if the server acknowledged the stop.
        """
        # Qwen's stop endpoint REQUIRES response_id — calling without it returns
        # RequestValidationError and burns a request. The caller is responsible
        # for resolving a response_id (frontend value, or the server-side cache
        # in /api/chat/stop) before invoking this.
        if not response_id:
            logger.info("stop_generation skipped: no response_id for chat_id=%s", chat_id)
            return False
        try:
            headers = await self._ensure_headers()
            payload = {"chat_id": chat_id, "response_id": response_id}
            _hdrs = sanitize_fetch_headers(headers)
            async with CffiSession(impersonate="chrome", timeout=5) as client:
                resp = await client.post(STOP_URL, json=payload, headers=_hdrs)
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("success"):
                        logger.info("Upstream generation stopped: chat_id=%s response_id=%s", chat_id, response_id)
                        return True
                _text = resp.text[:200] if hasattr(resp, 'text') else str(resp.content)[:200]
                logger.warning("Stop API returned %s: %s", resp.status_code, _text)
        except Exception as exc:
            logger.warning("Failed to call stop API: %s", exc)
        return False

    async def stream_events(
        self,
        message: str,
        chat_id: str | None = None,
        parent_id: str | None = None,
        files: list[dict[str, Any]] | None = None,
        model: str | None = None,
        thinking_mode: str | None = None,
        bdd: str | None = None,
    ) -> AsyncGenerator[dict[str, Any], None]:
        print(f"[STREAM] ▶ stream_events START chat_id={chat_id} msg_len={len(message)} bdd={bdd}")
        try:
            print(f"[STREAM]   ↳ _ensure_headers(bdd={bdd})...")
            headers = await self._ensure_headers(bdd)
            print(f"[STREAM]   ✓ headers ready (keys={list(headers.keys())[:3]}...)")
            active_chat_id = chat_id

            if not active_chat_id:
                print(f"[STREAM]   ↳ create_new_chat() (no chat_id provided)...")
                active_chat_id = await create_new_chat(headers, model=model)
                if not active_chat_id:
                    print(f"[STREAM]   ↳ create_new_chat() failed, refreshing headers...")
                    headers = await self._refresh_headers(bdd)
                    active_chat_id = await create_new_chat(headers, model=model)

            if not active_chat_id:
                print(f"[STREAM] ✗ Could not create chat session")
                yield {"type": "error", "message": "Could not create chat session"}
                return
        except Exception as exc:
            print(f"[STREAM] ✗ Session startup failed: {type(exc).__name__}: {exc}")
            yield {"type": "error", "message": f"Session startup failed: {type(exc).__name__}: {exc}"}
            return

        print(f"[STREAM] ✓ active_chat_id={active_chat_id}, building body...")

        yield {"type": "meta", "chat_id": active_chat_id, "parent_id": parent_id}
        yield {"type": "status", "message": "calling_upstream"}

        # If sync_context has been failing for this account, inject full instructions
        # into every first message until sync succeeds again. Mirrors DeepSeek's
        # [SYSTEM INSTRUCTION] injection pattern. Persisted per-account in config.
        from engine.config import needs_instruction_fallback
        _stream_account = self._resolve_account(bdd)
        if needs_instruction_fallback(_stream_account):
            try:
                from connectors.common.instruction_builder import build_instructions
                _fb_instr = build_instructions(provider="qwen")
                if _fb_instr:
                    message = f"[SYSTEM INSTRUCTION]\n{_fb_instr}\n\n[USER MESSAGE]\n{message}"
                    print(f"[STREAM] Injected fallback instructions ({len(_fb_instr)} chars) for sync-failed account")
            except Exception as _fb_exc:
                print(f"[STREAM] Failed to build fallback instructions: {_fb_exc}")

        body = build_body(message, active_chat_id, parent_id, files=files, model=model, thinking_mode=thinking_mode)
        params = {"chat_id": active_chat_id}
        print(f"[STREAM] ↳ entering _stream_request() attempt loop...")

        # Anti-burst jitter: randomized gap before sending to prevent WAF throttling.
        # Uses the same shared config as the scraper path (connectors.common.jitter).
        try:
            from connectors.common.jitter import jitter_for as _jitter_for, sleep_jitter as _sleep_jitter
            _jdelay = _jitter_for("qwen")
            if _jdelay:
                yield {"type": "status", "message": f"qwen_delay_{_jdelay:.1f}s"}
                await _sleep_jitter(_jdelay)
        except Exception as _jexc:
            print(f"[STREAM] Qwen jitter skipped: {_jexc}")

        # Sentinel: all setup complete, HTTP request is about to be sent.
        # Consumers can use this to start first-chunk timeouts accurately.
        yield {"type": "request_sent"}

        try:
            async for event in self._stream_request(
                headers=headers,
                body=body,
                params=params,
                chat_id=active_chat_id,
                parent_id=parent_id,
                files=files,
                is_retry=False,
                bdd=bdd,
            ):
                yield event
        except httpx.ConnectError as exc:
            yield {"type": "error", "message": f"Connection failed: {exc}"}
        except httpx.ReadTimeout:
            yield {"type": "error", "message": "Timed out waiting for response"}
        except Exception as exc:
            yield {"type": "error", "message": f"{type(exc).__name__}: {exc}"}
        finally:
            pass

    async def _wait_for_chat_in_progress_clear(
        self,
        headers: dict[str, str],
        body: dict[str, Any],
        params: dict[str, str],
        chat_id: str,
        response_id: str | None = None,
    ) -> bool:
        """Stop-then-wait loop for CHAT_IN_PROGRESS. 10 checks × 3s = 30s max.

        Each iteration:
          1. Call stop API (hammer it — upstream may ignore the first call)
          2. Wait 3s for upstream to release
          3. If stop acknowledged → assume clear (no wasteful probe)
          4. Fallback probe only when stop API isn't responding
          5. After 30s → return False

        All probes are silent — errors here NEVER reach the user.
        """
        # Immediately call stop before first wait — don't waste 3s doing nothing
        print(f"[STREAM]     🔨 Calling stop API immediately for chat {chat_id}")
        stop_ok = await self._stop_upstream_generation(chat_id, response_id)
        if stop_ok:
            print(f"[STREAM]     ✓ Stop API acknowledged on first call")
            await asyncio.sleep(2)
            return True

        for i in range(10):
            await asyncio.sleep(3)
            print(f"[STREAM]     ↳ CHAT_IN_PROGRESS check {i+1}/10 for chat {chat_id}")

            # Re-call stop each iteration — upstream may ignore earlier calls
            try:
                stop_ok = await self._stop_upstream_generation(chat_id, response_id)
            except Exception:
                stop_ok = False

            if stop_ok:
                print(f"[STREAM]     ✓ Stop acknowledged on check {i+1}, waiting 2s...")
                await asyncio.sleep(2)
                return True

            # Fallback probe — only when stop API isn't responding
            still_busy = False
            try:
                _hdrs = sanitize_fetch_headers(headers)
                async with CffiSession(impersonate="chrome", timeout=8) as client:
                    resp = await client.post(URL, headers=_hdrs, json=body, params=params)
                    try:
                        data = resp.json()
                        inner = data.get("data", {})
                        code = inner.get("code", "") if isinstance(inner, dict) else ""
                        if not code:
                            code = data.get("code", "")
                        if code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                            still_busy = True
                    except (json.JSONDecodeError, ValueError):
                        pass
            except Exception:
                continue

            if not still_busy:
                print(f"[STREAM]     ✓ CHAT_IN_PROGRESS cleared after {(i+1)*3}s")
                return True

        print(f"[STREAM]     ✗ CHAT_IN_PROGRESS still present after 30s")
        return False

    def _is_chat_in_progress_error(self, raw: str, status_code: int) -> bool:
        """Check if an error response indicates chat is still generating."""
        try:
            err_data = json.loads(raw)
            inner = err_data.get("data", {})
            if isinstance(inner, dict):
                code = inner.get("code", "")
                if code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                    return True
                details = str(inner.get("details", "")).lower()
                if "in progress" in details or "generating" in details or "busy" in details:
                    return True
        except (json.JSONDecodeError, ValueError):
            pass
        return False

    async def _stream_request(
        self,
        headers: dict[str, str],
        body: dict[str, Any],
        params: dict[str, str],
        chat_id: str,
        parent_id: str | None,
        files: list[dict[str, Any]] | None,
        is_retry: bool,
        bdd: str | None = None,
    ) -> AsyncGenerator[dict[str, Any], None]:
        max_attempts = 3
        last_error_msg: str | None = None
        _CHUNK_TIMEOUT = 30.0  # seconds for first chunk and between chunks

        for attempt in range(1, max_attempts + 1):
            print(f"[STREAM]   ↳ _stream_request attempt {attempt}/{max_attempts}")
            new_parent_id = parent_id
            chosen_response_id: str | None = None
            got_content = False
            _thinking_sent_count = 0  # track cumulative thinking paragraphs already yielded
            status_code = 0
            needs_refresh = False
            _chunk_timeout_triggered = False

            # ── Live header refresh before every request ─────────────────────
            # If the browser is already running, grab fresh bx-ua/bx-umidtoken
            # and cookies instantly (<100ms). This prevents WAF drift between
            # requests without ever triggering a cold Chromium launch.
            # Falls back silently to cached headers when browser isn't up.
            try:
                browser = self._get_browser(bdd)
                if browser.is_running and browser.page and browser.context:
                    print("[STREAM]     🟢 browser is UP — grabbing live headers...")
                    _live = await browser.get_live_headers()
                    if _live and _live.get("Cookie"):
                        headers.update(_live)
                        print(f"[STREAM]     ✓ live headers refreshed (bx-ua={'yes' if _live.get('bx-ua') else 'no'})")
                else:
                    print("[STREAM]     ⏭️  browser not running — skipped live header refresh, using cached")
            except Exception as _hdr_exc:
                print(f"[STREAM]     ⚠ live header refresh skipped: {_hdr_exc}")
            # ─────────────────────────────────────────────────────────────────

            try:
                # curl_cffi impersonates Chrome's TLS fingerprint (cipher suites,
                # extensions, ALPN). httpx uses Python/OpenSSL which Alibaba's WAF
                # detects instantly despite correct headers.
                _clean_headers = sanitize_fetch_headers(headers)
                async with CffiSession(impersonate="chrome", timeout=30) as client:
                    print(f"[STREAM]     ↳ HTTP POST {URL[:60]}...")
                    async with client.stream("POST", URL, headers=_clean_headers, json=body, params=params) as res:
                        status_code = res.status_code
                        print(f"[STREAM]     ✓ HTTP {res.status_code} (attempt {attempt}/{max_attempts})")
                        logger.debug("Upstream HTTP %s (attempt %d/%d)", res.status_code, attempt, max_attempts)
                        yield {"type": "debug", "message": f"HTTP {res.status_code} (attempt {attempt}/{max_attempts})"}

                        if res.status_code in (401, 403):
                            _ = res.content  # drain the response body
                            needs_refresh = True
                        elif res.status_code != 200:
                            raw = res.content.decode(errors="replace") if isinstance(res.content, bytes) else (await res.acontent).decode(errors="replace")
                            # Check if non-200 response is actually a rate-limit or API error
                            try:
                                err_data = json.loads(raw)
                                # ── Early CHAT_IN_PROGRESS detection ──────────────────────
                                # Qwen sometimes returns CHAT_IN_PROGRESS without success:false,
                                # or in a flat structure. Check BEFORE the success gate so it
                                # never leaks as a generic error.
                                _early_code = ""
                                if isinstance(err_data.get("data"), dict):
                                    _early_code = err_data["data"].get("code", "")
                                if not _early_code:
                                    _early_code = err_data.get("code", "")
                                if _early_code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                                    print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS detected early (attempt {attempt}, status={res.status_code})")
                                    logger.info("CHAT_IN_PROGRESS early-detect: status=%s body=%s", res.status_code, raw[:300])
                                    yield {"type": "status", "message": "chat_in_progress_waiting"}
                                    cleared = await self._wait_for_chat_in_progress_clear(
                                        headers, body, params, chat_id, chosen_response_id,
                                    )
                                    if not cleared:
                                        yield {
                                            "type": "error",
                                            "message": "Chat still in progress after 30s — upstream may be stuck",
                                        }
                                        return
                                    headers = await self._refresh_headers(bdd)
                                    continue
                                # ── End early detection ───────────────────────────────────
                                if err_data.get("success") is False:
                                    inner = err_data.get("data", {})
                                    code = inner.get("code", "")
                                    if code == "RateLimited":
                                        hours = inner.get("num", "?")
                                        details = inner.get("details", "Daily usage limit reached.")
                                        mark_account_exhausted(self._resolve_account(bdd))
                                        yield {
                                            "type": "rate_limited",
                                            "message": details,
                                            "hours": hours,
                                            "template": inner.get("template", ""),
                                            **self._get_debug_account_info(bdd),
                                        }
                                        return
                                    if code == "CHAT_NOT_FOUND":
                                        yield {
                                            "type": "chat_not_found",
                                            "message": f"Upstream session expired: {inner.get('details', '')}",
                                        }
                                        return
                                    if code == "PARENT_NOT_FOUND":
                                        yield {
                                            "type": "parent_not_found",
                                            "message": f"Stale parent_id: {inner.get('details', '')}",
                                        }
                                        return
                                    # CHAT_IN_PROGRESS: hammer stop API for 30s, then retry
                                    if code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                                        print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS detected (attempt {attempt})")
                                        yield {"type": "status", "message": "chat_in_progress_waiting"}
                                        cleared = await self._wait_for_chat_in_progress_clear(
                                            headers, body, params, chat_id, chosen_response_id,
                                        )
                                        if not cleared:
                                            yield {
                                                "type": "error",
                                                "message": "Chat still in progress after 30s — upstream may be stuck",
                                            }
                                            return
                                        # Cleared — refresh headers and retry
                                        headers = await self._refresh_headers(bdd)
                                        continue
                                    yield {
                                        "type": "error",
                                        "message": f"API error [{code}]: {inner.get('details', 'Unknown error')}",
                                    }
                                    return
                            except (json.JSONDecodeError, ValueError):
                                pass
                            # Also check raw text for chat-in-progress patterns
                            if self._is_chat_in_progress_error(raw, res.status_code):
                                print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS detected in raw response (attempt {attempt})")
                                yield {"type": "status", "message": "chat_in_progress_waiting"}
                                cleared = await self._wait_for_chat_in_progress_clear(
                                    headers, body, params, chat_id, chosen_response_id,
                                )
                                if not cleared:
                                    yield {
                                        "type": "error",
                                        "message": "Chat still in progress after 30s — upstream may be stuck",
                                    }
                                    return
                                headers = await self._refresh_headers(bdd)
                                continue
                            last_error_msg = f"HTTP {res.status_code}: {raw[:500]}"
                            continue
                        else:
                            buffer = ""
                            _total_bytes = 0
                            _chunk_count = 0
                            _answer_chars = 0
                            _finish_reason = None
                            _last_sse_data = None
                            # Incremental UTF-8 decoder: multi-byte chars
                            # (Bengali, emoji) can span chunk boundaries.
                            _decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
                            logger.info(
                                "Qwen stream started: chat_id=%s attempt=%d model=%s",
                                chat_id, attempt, body.get("model", "?"),
                            )
                            # Use an iterator so we can wrap each next() with asyncio.wait_for
                            _byte_iter = res.aiter_content()
                            while True:
                                try:
                                    chunk = await asyncio.wait_for(
                                        _byte_iter.__anext__(),
                                        timeout=_CHUNK_TIMEOUT,
                                    )
                                except StopAsyncIteration:
                                    break  # stream ended normally
                                except asyncio.TimeoutError:
                                    # Chunk timeout — send stop request, then close backend connection
                                    _chunk_timeout_triggered = True
                                    _phase = "first chunk" if _chunk_count == 0 else f"inter-chunk (after {_chunk_count} chunks)"
                                    print(f"[STREAM]     ⏰ Chunk timeout ({_phase}) after {_CHUNK_TIMEOUT}s — sending stop & closing backend")
                                    logger.warning(
                                        "Chunk timeout (%s) on chat_id=%s attempt=%d — sending stop request",
                                        _phase, chat_id, attempt,
                                    )
                                    await self._stop_upstream_generation(chat_id, chosen_response_id)
                                    last_error_msg = f"Timeout waiting for {_phase}"
                                    break  # exits the async with client.stream → closes connection

                                if not chunk:
                                    continue

                                _total_bytes += len(chunk)
                                _chunk_count += 1
                                buffer += _decoder.decode(chunk)
                                while "\n" in buffer:
                                    line, buffer = buffer.split("\n", 1)
                                    line = line.strip()

                                    # Log every raw SSE line before parsing
                                    _log_qwen_raw_line(line)

                                    if not line.startswith("data: "):
                                        # Check for non-SSE JSON error responses (e.g. rate limit, WAF block)
                                        if line:
                                            try:
                                                err_data = json.loads(line)
                                                # WAF/captcha block: ret contains FAIL_SYS_USER_VALIDATE or RGV587_ERROR
                                                ret_list = err_data.get("ret")
                                                if isinstance(ret_list, list):
                                                    ret_str = " ".join(str(r) for r in ret_list)
                                                    if "FAIL_SYS_USER_VALIDATE" in ret_str or "RGV587_ERROR" in ret_str:
                                                        logger.warning("WAF/captcha block detected: %s", ret_str[:200])
                                                        last_error_msg = f"WAF/captcha block: {ret_str[:200]}"
                                                        break
                                                # ── Early CHAT_IN_PROGRESS detection (SSE body) ──
                                                _early_code_sse = ""
                                                if isinstance(err_data.get("data"), dict):
                                                    _early_code_sse = err_data["data"].get("code", "")
                                                if not _early_code_sse:
                                                    _early_code_sse = err_data.get("code", "")
                                                if _early_code_sse in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                                                    print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS detected early in SSE body (attempt {attempt})")
                                                    logger.info("CHAT_IN_PROGRESS early-detect SSE: body=%s", line[:300])
                                                    yield {"type": "status", "message": "chat_in_progress_waiting"}
                                                    cleared = await self._wait_for_chat_in_progress_clear(
                                                        headers, body, params, chat_id, chosen_response_id,
                                                    )
                                                    if not cleared:
                                                        yield {
                                                            "type": "error",
                                                            "message": "Chat still in progress after 30s — upstream may be stuck",
                                                        }
                                                        return
                                                    headers = await self._refresh_headers(bdd)
                                                    break  # exit chunk loop → retry
                                                # ── End early detection ──────────────────────────
                                                if err_data.get("success") is False:
                                                    inner = err_data.get("data", {})
                                                    code = inner.get("code", "")
                                                    if code == "RateLimited":
                                                        hours = inner.get("num", "?")
                                                        details = inner.get("details", "Daily usage limit reached.")
                                                        mark_account_exhausted(self._resolve_account(bdd))
                                                        yield {
                                                            "type": "rate_limited",
                                                            "message": details,
                                                            "hours": hours,
                                                            "template": inner.get("template", ""),
                                                            **self._get_debug_account_info(bdd),
                                                        }
                                                        return
                                                    if code == "CHAT_NOT_FOUND":
                                                        yield {
                                                            "type": "chat_not_found",
                                                            "message": f"Upstream session expired: {inner.get('details', '')}",
                                                        }
                                                        return
                                                    if code == "PARENT_NOT_FOUND":
                                                        yield {
                                                            "type": "parent_not_found",
                                                            "message": f"Stale parent_id: {inner.get('details', '')}",
                                                        }
                                                        return
                                                    # CHAT_IN_PROGRESS in SSE stream body
                                                    if code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                                                        print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS in SSE stream (attempt {attempt})")
                                                        yield {"type": "status", "message": "chat_in_progress_waiting"}
                                                        cleared = await self._wait_for_chat_in_progress_clear(
                                                            headers, body, params, chat_id, chosen_response_id,
                                                        )
                                                        if not cleared:
                                                            yield {
                                                                "type": "error",
                                                                "message": "Chat still in progress after 30s — upstream may be stuck",
                                                            }
                                                            return
                                                        headers = await self._refresh_headers(bdd)
                                                        break  # exit chunk loop → retry
                                                    # Other API errors
                                                    yield {
                                                        "type": "error",
                                                        "message": f"API error [{code}]: {inner.get('details', 'Unknown error')}",
                                                    }
                                                    return
                                            except json.JSONDecodeError:
                                                pass
                                        continue

                                    try:
                                        data = json.loads(line[6:])
                                        _last_sse_data = data
                                    except json.JSONDecodeError:
                                        logger.warning(
                                            "Qwen SSE JSON parse failed: %s",
                                            line[:200],
                                        )
                                        continue

                                    # Safety: catch CHAT_IN_PROGRESS even inside data: lines
                                    _sse_code = ""
                                    if isinstance(data.get("data"), dict):
                                        _sse_code = data["data"].get("code", "")
                                    if not _sse_code:
                                        _sse_code = data.get("code", "")
                                    if _sse_code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                                        print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS in data: line (attempt {attempt})")
                                        logger.info("CHAT_IN_PROGRESS in data: SSE: %s", line[:300])
                                        yield {"type": "status", "message": "chat_in_progress_waiting"}
                                        cleared = await self._wait_for_chat_in_progress_clear(
                                            headers, body, params, chat_id, chosen_response_id,
                                        )
                                        if not cleared:
                                            yield {
                                                "type": "error",
                                                "message": "Chat still in progress after 30s — upstream may be stuck",
                                            }
                                            return
                                        headers = await self._refresh_headers(bdd)
                                        break  # exit chunk loop → retry

                                    # Catch top-level "error" field in SSE data lines.
                                    # Qwen sometimes sends: data: {"error": {...}, "response_id": "..."}
                                    # instead of normal choices/delta content.
                                    _sse_error = data.get("error")
                                    if _sse_error and not got_content:
                                        if isinstance(_sse_error, dict):
                                            _err_code = _sse_error.get("code", "")
                                            _err_msg = _sse_error.get("message", "") or _sse_error.get("details", "")
                                            # CHAT_IN_PROGRESS via error object
                                            if _err_code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                                                print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS in data.error (attempt {attempt})")
                                                yield {"type": "status", "message": "chat_in_progress_waiting"}
                                                cleared = await self._wait_for_chat_in_progress_clear(
                                                    headers, body, params, chat_id, chosen_response_id,
                                                )
                                                if not cleared:
                                                    yield {"type": "error", "message": "Chat still in progress after 30s"}
                                                    return
                                                headers = await self._refresh_headers(bdd)
                                                break
                                            # Other error codes
                                            if _err_code:
                                                err_text = f"API error [{_err_code}]: {_err_msg or 'Unknown error'}"
                                            else:
                                                err_text = f"Upstream error: {_err_msg or json.dumps(_sse_error)[:200]}"
                                        else:
                                            err_text = f"Upstream error: {str(_sse_error)[:300]}"
                                        logger.warning("SSE data.error on attempt %d: %s", attempt, err_text)
                                        print(f"[STREAM]     ✗ SSE error object: {err_text}")
                                        last_error_msg = err_text
                                        break  # exit chunk loop → retry logic

                                    # Capture finish_reason from choices or top-level
                                    _fr = None
                                    if data.get("choices"):
                                        _fr = data["choices"][0].get("finish_reason")
                                    if not _fr:
                                        _fr = data.get("finish_reason")
                                    if _fr:
                                        _finish_reason = _fr

                                    # Token accounting — the API reports usage on
                                    # the final chunk(s). Surface it for logging.
                                    _usage = data.get("usage")
                                    if isinstance(_usage, dict) and _usage:
                                        logger.info(
                                            "Qwen usage: input=%s output=%s total=%s",
                                            _usage.get("input_tokens"),
                                            _usage.get("output_tokens"),
                                            _usage.get("total_tokens"),
                                        )
                                        yield {"type": "usage", "data": _usage}

                                    created = data.get("response.created")
                                    if isinstance(created, dict):
                                        response_id = created.get("response_id")
                                        if isinstance(response_id, str):
                                            if created.get("response_index") == "0" or chosen_response_id is None:
                                                chosen_response_id = response_id
                                                new_parent_id = response_id

                                    choices = data.get("choices", [])
                                    if not choices:
                                        continue

                                    response_id = data.get("response_id")
                                    if isinstance(response_id, str):
                                        if chosen_response_id is None:
                                            chosen_response_id = response_id
                                            new_parent_id = response_id
                                            # Emit immediately so frontend can use it for stop requests
                                            yield {"type": "response_id", "id": response_id}
                                        elif response_id != chosen_response_id:
                                            continue

                                    delta = choices[0].get("delta", {})
                                    phase = delta.get("phase", "")
                                    content = delta.get("content", "")
                                    extra = delta.get("extra", {})

                                    tool_calls = delta.get("tool_calls") or extra.get("tool_calls")
                                    if tool_calls:
                                        yield {"type": "tool_call", "data": tool_calls}

                                    tool_results = delta.get("tool_results") or extra.get("tool_results")
                                    if tool_results:
                                        yield {"type": "tool_result", "data": tool_results}

                                    if phase in ("thinking_summary", "thinking"):
                                        thoughts = extra.get("summary_thought", {}).get("content", [])
                                        if thoughts:
                                            # API sends cumulative array; only yield new paragraphs
                                            new_parts = thoughts[_thinking_sent_count:]
                                            _thinking_sent_count = len(thoughts)
                                            if new_parts:
                                                joined = "\n\n".join(new_parts)
                                                _log_qwen_stream_chunk(phase, joined)
                                                got_content = True
                                                yield {"type": "thinking", "text": joined}
                                        elif content:
                                            _log_qwen_stream_chunk(phase, content)
                                            got_content = True
                                            yield {"type": "thinking", "text": content}
                                    elif phase == "answer" and content:
                                        _log_qwen_stream_chunk(phase, content)
                                        got_content = True
                                        _answer_chars += len(content)
                                        yield {"type": "answer", "text": content}
                                    elif content:
                                        _log_qwen_stream_chunk(phase or "unknown", content)
                                        got_content = True
                                        _answer_chars += len(content)
                                        yield {"type": "answer", "text": content}

                            # Stream ended — log diagnostics
                            logger.info(
                                "Qwen stream ended: chat_id=%s attempt=%d "
                                "chunks=%d bytes=%d answer_chars=%d "
                                "finish_reason=%s got_content=%s "
                                "buffer_leftover=%d last_data_keys=%s",
                                chat_id, attempt, _chunk_count, _total_bytes,
                                _answer_chars, _finish_reason, got_content,
                                len(buffer), list(_last_sse_data.keys()) if _last_sse_data else "none",
                            )
                            if not got_content and _chunk_count > 0:
                                logger.warning(
                                    "Qwen stream produced %d chunks (%d bytes) but ZERO content. "
                                    "finish_reason=%s buffer_tail=%s",
                                    _chunk_count, _total_bytes, _finish_reason,
                                    buffer[-500:] if buffer else "(empty)",
                                )
                            if got_content and _finish_reason and _finish_reason != "stop":
                                logger.warning(
                                    "Qwen stream finished with reason=%s (not 'stop'). "
                                    "Response likely truncated. answer_chars=%d",
                                    _finish_reason, _answer_chars,
                                )

            except asyncio.CancelledError:
                # Client disconnected (stop button pressed) — tell Qwen to stop generating
                await self._stop_upstream_generation(chat_id, chosen_response_id)
                raise
            except (httpx.ConnectError, ConnectionError, OSError) as exc:
                last_error_msg = f"Connection failed: {exc}"
                continue
            except (httpx.ReadTimeout, asyncio.TimeoutError, TimeoutError):
                last_error_msg = "Timed out waiting for response"
                continue
            except Exception as exc:
                last_error_msg = f"{type(exc).__name__}: {exc}"
                continue

            # If chunk timeout triggered, treat as a retryable failure
            if _chunk_timeout_triggered and not got_content:
                print(f"[STREAM]     ⏰ Chunk timeout on attempt {attempt}/{max_attempts} — will retry")
                if attempt < max_attempts:
                    yield {"type": "status", "message": f"retrying_attempt_{attempt + 1}"}
                    yield {"type": "debug", "message": f"Chunk timeout on attempt {attempt}. Retrying."}
                    headers = await self._refresh_headers(bdd)
                    await asyncio.sleep(1 * attempt)
                    continue
                else:
                    # All 3 attempts timed out
                    print(f"[STREAM]   ✗ All {max_attempts} attempts timed out")
                    yield {"type": "error", "message": "No response from upstream"}
                    return

            if got_content:
                yield {"type": "done", "chat_id": chat_id, "parent_id": new_parent_id}
                return

            if needs_refresh:
                last_error_msg = f"HTTP {status_code} — auth rejected"

            if not got_content and not needs_refresh:
                # Check if buffer has leftover non-SSE JSON (e.g. rate-limit, WAF block on HTTP 200)
                leftover = buffer.strip() if buffer else ""
                if leftover:
                    try:
                        err_data = json.loads(leftover)
                        # WAF/captcha block detection in leftover buffer
                        ret_list = err_data.get("ret")
                        if isinstance(ret_list, list):
                            ret_str = " ".join(str(r) for r in ret_list)
                            if "FAIL_SYS_USER_VALIDATE" in ret_str or "RGV587_ERROR" in ret_str:
                                logger.warning("WAF/captcha block detected in leftover: %s", ret_str[:200])
                                last_error_msg = f"WAF/captcha block: {ret_str[:200]}"
                        # Top-level error object (Qwen sometimes sends {"error": {...}})
                        _leftover_err = err_data.get("error")
                        if _leftover_err and not last_error_msg:
                            if isinstance(_leftover_err, dict):
                                _lo_code = _leftover_err.get("code", "")
                                _lo_msg = _leftover_err.get("message", "") or _leftover_err.get("details", "")
                                if _lo_code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY"):
                                    print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS in leftover buffer")
                                    yield {"type": "status", "message": "chat_in_progress_waiting"}
                                    cleared = await self._wait_for_chat_in_progress_clear(
                                        headers, body, params, chat_id, chosen_response_id,
                                    )
                                    if not cleared:
                                        yield {"type": "error", "message": "Chat still in progress after 30s"}
                                        return
                                    headers = await self._refresh_headers(bdd)
                                    continue  # retry
                                if _lo_code:
                                    last_error_msg = f"API error [{_lo_code}]: {_lo_msg or 'Unknown'}"
                                else:
                                    last_error_msg = f"Upstream error: {_lo_msg or json.dumps(_leftover_err)[:200]}"
                            else:
                                last_error_msg = f"Upstream error: {str(_leftover_err)[:300]}"
                        # Early CHAT_IN_PROGRESS in leftover (before success gate)
                        _lo_early_code = ""
                        if isinstance(err_data.get("data"), dict):
                            _lo_early_code = err_data["data"].get("code", "")
                        if not _lo_early_code:
                            _lo_early_code = err_data.get("code", "")
                        if _lo_early_code in ("CHAT_IN_PROGRESS", "GENERATING", "BUSY") and not last_error_msg:
                            print(f"[STREAM]     ⏳ CHAT_IN_PROGRESS in leftover (early detect)")
                            yield {"type": "status", "message": "chat_in_progress_waiting"}
                            cleared = await self._wait_for_chat_in_progress_clear(
                                headers, body, params, chat_id, chosen_response_id,
                            )
                            if not cleared:
                                yield {"type": "error", "message": "Chat still in progress after 30s"}
                                return
                            headers = await self._refresh_headers(bdd)
                            continue  # retry
                        if err_data.get("success") is False:
                            inner = err_data.get("data", {})
                            code = inner.get("code", "")
                            if code == "RateLimited":
                                hours = inner.get("num", "?")
                                details = inner.get("details", "Daily usage limit reached.")
                                mark_account_exhausted(self._resolve_account(bdd))
                                yield {
                                    "type": "rate_limited",
                                    "message": details,
                                    "hours": hours,
                                    "template": inner.get("template", ""),
                                    **self._get_debug_account_info(bdd),
                                }
                                return
                            if code == "CHAT_NOT_FOUND":
                                yield {
                                    "type": "chat_not_found",
                                    "message": f"Upstream session expired: {inner.get('details', '')}",
                                }
                                return
                            if code == "PARENT_NOT_FOUND":
                                yield {
                                    "type": "parent_not_found",
                                    "message": f"Stale parent_id: {inner.get('details', '')}",
                                }
                                return
                            yield {
                                "type": "error",
                                "message": f"API error [{code}]: {inner.get('details', 'Unknown error')}",
                            }
                            return
                    except (json.JSONDecodeError, ValueError):
                        pass
                last_error_msg = f"Upstream returned HTTP {status_code} with zero content — WAF tokens may be stale or the session expired"

            # Fast-fail: don't waste retries on rate-limit/captcha — escalate immediately
            _fail_lower = (last_error_msg or "").lower()
            print(f"[STREAM]     ↳ post-attempt check: last_error={last_error_msg[:100] if last_error_msg else 'None'}")
            if any(kw in _fail_lower for kw in ("ratelimit", "rate_limit", "rate limit", "quota", "daily usage", "exceeded", "429")):
                print(f"[STREAM]     ⚡ FAST-FAIL rate_limit on attempt {attempt} — skipping retries")
                mark_account_exhausted(self._resolve_account(bdd))
                logger.warning("Rate-limit detected on attempt %d — skipping remaining retries", attempt)
                yield {"type": "rate_limited", "message": last_error_msg, "hours": "?"}
                return
            if attempt < max_attempts:
                logger.warning("Attempt %d failed: %s. Refreshing headers and retrying...", attempt, last_error_msg)
                yield {"type": "status", "message": f"retrying_attempt_{attempt + 1}"}
                yield {"type": "debug", "message": f"Attempt {attempt} failed: {last_error_msg}. Refreshing session."}
                headers = await self._refresh_headers(bdd)
                await asyncio.sleep(1 * attempt)
                continue

        # Defense-in-depth: detect rate-limit/captcha patterns in generic failure messages
        print(f"[STREAM]   ↳ all {max_attempts} attempts exhausted, defense-in-depth check...")
        _fail_lower = (last_error_msg or "").lower()
        if any(kw in _fail_lower for kw in ("ratelimit", "rate_limit", "rate limit", "quota", "daily usage", "exceeded", "429")):
            print(f"[STREAM]   ⚡ DEFENSE-IN-DEPTH rate_limit detected")
            mark_account_exhausted(self._resolve_account(bdd))
            yield {"type": "rate_limited", "message": last_error_msg, "hours": "?"}
        elif any(kw in _fail_lower for kw in ("captcha", "waf", "validate", "rgv587", "blocked", "forbidden")):
            print(f"[STREAM]   ⚡ DEFENSE-IN-DEPTH captcha/waf detected")
            yield {"type": "waf_blocked", "message": last_error_msg}
        else:
            print(f"[STREAM]   ✗ generic error after {max_attempts} attempts: {last_error_msg[:100] if last_error_msg else 'unknown'}")
            # If all failures were timeouts, give a cleaner message
            _err_lower = (last_error_msg or "").lower()
            if "timeout" in _err_lower or "timed out" in _err_lower:
                yield {"type": "error", "message": "No response from upstream"}
            else:
                yield {"type": "error", "message": f"Failed after {max_attempts} attempts: {last_error_msg}"}

    async def chat(
        self,
        message: str,
        chat_id: str | None = None,
        parent_id: str | None = None,
        files: list[dict[str, Any]] | None = None,
        model: str | None = None,
        thinking_mode: str | None = None,
    ) -> dict[str, Any]:
        thinking_parts: list[str] = []
        answer_parts: list[str] = []
        tool_events: list[dict[str, Any]] = []
        final_chat_id = chat_id
        final_parent_id = parent_id
        error: str | None = None

        async for event in self.stream_events(message, chat_id, parent_id, files, model=model, thinking_mode=thinking_mode):
            event_type = event.get("type")

            if event_type == "thinking":
                thinking_parts.append(str(event.get("text", "")))
            elif event_type == "answer":
                answer_parts.append(str(event.get("text", "")))
            elif event_type in ("tool_call", "tool_result"):
                tool_events.append(event)
            elif event_type == "meta":
                final_chat_id = event.get("chat_id") or final_chat_id
            elif event_type == "done":
                final_chat_id = event.get("chat_id") or final_chat_id
                final_parent_id = event.get("parent_id") or final_parent_id
            elif event_type == "chat_not_found":
                # Upstream session expired — create new one, inject history, retry once
                from engine.session import create_new_chat as _cnc
                _hdrs = await self._ensure_headers()
                _new_id = await _cnc(_hdrs, model=model)
                if not _new_id:
                    _hdrs = await self._refresh_headers()
                    _new_id = await _cnc(_hdrs, model=model)
                if _new_id:
                    # Re-call with new session, no history injection (non-streaming is simpler)
                    async for _evt in self.stream_events(message, _new_id, None, files, model=model, thinking_mode=thinking_mode):
                        _t = _evt.get("type")
                        if _t == "thinking":
                            thinking_parts.append(str(_evt.get("text", "")))
                        elif _t == "answer":
                            answer_parts.append(str(_evt.get("text", "")))
                        elif _t in ("tool_call", "tool_result"):
                            tool_events.append(_evt)
                        elif _t == "meta":
                            final_chat_id = _evt.get("chat_id") or final_chat_id
                        elif _t == "done":
                            final_chat_id = _evt.get("chat_id") or final_chat_id
                            final_parent_id = _evt.get("parent_id") or final_parent_id
                        elif _t == "error":
                            error = str(_evt.get("message", "Unknown error"))
                else:
                    error = "Failed to recover: could not create new upstream session"
            elif event_type == "error":
                error = str(event.get("message", "Unknown error"))

        return {
            "chat_id": final_chat_id,
            "parent_id": final_parent_id,
            "thinking": "".join(thinking_parts),
            "answer": "".join(answer_parts),
            "tool_events": tool_events,
            "error": error,
        }