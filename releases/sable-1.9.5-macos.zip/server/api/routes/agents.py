
"""Agent monitoring API: persistent SSE stream + REST endpoints.

Provides real-time agent status updates to the frontend via Server-Sent Events,
plus REST endpoints for listing agents, viewing history, killing stuck agents,
and managing agent configuration.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from engine.config import AGENT_CONFIG_PATH
from engine.agents.registry import get_role_config

router = APIRouter()

# Per-chat SSE client queues: chat_id → list of asyncio.Queue
_agent_sse_clients: dict[str, list[asyncio.Queue]] = {}


def push_agent_event(chat_id: str, event: dict[str, Any]) -> None:
    """Push an agent event to all connected SSE clients for a chat.

    Called by AgentRuntime._emit via the event callback set in application.py.
    """
    queues = _agent_sse_clients.get(chat_id, [])
    payload = json.dumps(event, ensure_ascii=False, default=str)
    for q in queues:
        try:
            q.put_nowait(payload)
        except asyncio.QueueFull:
            pass  # Client too slow or disconnected — skip


def broadcast_agent_event(event: dict[str, Any], exclude_chat_id: str | None = None) -> None:
    """Push an agent event to ALL connected SSE clients across all chats.

    Used for cross-chat notifications (e.g., agent completion when user
    switched to a different chat). Optionally excludes one chat_id to
    avoid duplicate delivery if push_agent_event was already called for it.
    """
    payload = json.dumps(event, ensure_ascii=False, default=str)
    for cid, queues in _agent_sse_clients.items():
        if cid == exclude_chat_id:
            continue
        for q in queues:
            try:
                q.put_nowait(payload)
            except asyncio.QueueFull:
                pass


async def _async_push_agent_event(chat_id: str, event: dict[str, Any]) -> None:
    """Async wrapper for the runtime's event callback signature."""
    push_agent_event(chat_id, event)


# --------------------------------------------------------------------------
# SSE Stream
# --------------------------------------------------------------------------

@router.get("/api/chat/{chat_id}/agent-events")
async def agent_events_stream(chat_id: str, request: Request):
    """Persistent SSE stream for real-time agent events in a chat.

    Frontend opens this on chat load. Sends keepalive comments every 30s
    to prevent proxy/connection timeouts.
    """
    queue: asyncio.Queue = asyncio.Queue(maxsize=50)
    _agent_sse_clients.setdefault(chat_id, []).append(queue)

    async def generate():
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    data = await asyncio.wait_for(queue.get(), timeout=30)
                    yield f"data: {data}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            clients = _agent_sse_clients.get(chat_id, [])
            if queue in clients:
                clients.remove(queue)
            if not clients and chat_id in _agent_sse_clients:
                del _agent_sse_clients[chat_id]

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


# --------------------------------------------------------------------------
# REST Endpoints
# --------------------------------------------------------------------------

# --------------------------------------------------------------------------
# Configuration (must be BEFORE /api/agents/{agent_id} to avoid path capture)
# --------------------------------------------------------------------------

DEFAULT_AGENT_CONFIG: dict[str, Any] = {
    "enabled": True,
    "concurrency": {
        "global_max": 5,
        "deepseek_max": 5,
        "qwen_max": 4,
    },
    "resilience": {
        "circuit_breaker_threshold": 5,
        "circuit_breaker_reset_seconds": 60,
    },
    "limits": {
        "max_iterations": 25,
    },
    "defaults": {
        "analyst_model": "qwen3.7-max",
        "coder_model": "qwen3.7-max",
        "writer_model": "qwen3.7-max",
        "timeout_analyst": 300,
        "timeout_coder": 300,
        "timeout_writer": 300,
        "sysutil_model": "qwen3.7-max",
        "docs_model": "qwen3.7-max",
        "visuals_model": "qwen3.7-max",
        "tester_model": "qwen3.7-max",
        "timeout_sysutil": 300,
        "timeout_docs": 300,
        "timeout_visuals": 300,
        "timeout_tester": 300,
    },
    "roles": {
        "analyst": {
            "default_model": "qwen3.7-max",
            "default_timeout": 300,
            "max_parallel": 4,
            "allowed_skills": ["execute_command", "online_search", "code_editor", "file_uploader"],
            "default_skills": ["online_search", "code_editor"],
            "required_sections": [],
        },
        "coder": {
            "default_model": "qwen3.7-max",
            "default_timeout": 300,
            "max_parallel": 1,
            "allowed_skills": ["execute_command", "code_editor", "online_search"],
            "default_skills": ["code_editor"],
            "required_sections": ["Description", "Files Modified"],
        },

        "writer": {
            "default_model": "qwen3.7-max",
            "default_timeout": 300,
            "max_parallel": 2,
            "allowed_skills": ["execute_command", "code_editor", "online_search"],
            "default_skills": ["code_editor"],
            "required_sections": ["Title", "Structure Overview"],
        },

        "sysutil": {
            "default_model": "qwen3.7-max",
            "default_timeout": 300,
            "max_parallel": 3,
            "allowed_skills": ["execute_command", "system_repair", "phone_control", "youtube_downloader", "grep_search", "code_editor", "online_search", "file_uploader"],
            "default_skills": ["system_repair", "youtube_downloader", "code_editor"],
            "required_sections": ["Task", "Result"],
        },
        "docs": {
            "default_model": "qwen3.7-max",
            "default_timeout": 300,
            "max_parallel": 2,
            "allowed_skills": ["execute_command", "document_skills", "file_uploader", "text_humanizer", "code_editor"],
            "default_skills": ["document_skills", "file_uploader"],
            "required_sections": ["Task", "Document Path"],
        },
        "visuals": {
            "default_model": "qwen3.7-max",
            "default_timeout": 300,
            "max_parallel": 2,
            "allowed_skills": ["execute_command", "graph_master", "svg_creator", "frontend_design", "simulacra_engine", "code_editor"],
            "default_skills": ["graph_master", "svg_creator"],
            "required_sections": ["Task", "Output Path"],
        },
        "tester": {
            "default_model": "qwen3.7-max",
            "default_timeout": 300,
            "max_parallel": 2,
            "allowed_skills": ["execute_command", "testing_debugging", "code_editor", "grep_search"],
            "default_skills": ["testing_debugging", "code_editor"],
            "required_sections": ["Bug Summary", "Root Cause", "Fix Applied"],
        },
    },
    "universal_skills": ["execute_command"],
    "account_assignments": {},
}


def _load_agent_config() -> dict[str, Any]:
    """Load agent config from disk, falling back to defaults."""
    if AGENT_CONFIG_PATH.exists():
        try:
            return json.loads(AGENT_CONFIG_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return DEFAULT_AGENT_CONFIG.copy()


def _save_agent_config(config: dict[str, Any]) -> None:
    """Persist agent config to disk."""
    AGENT_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    AGENT_CONFIG_PATH.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")


@router.get("/api/agents/config")
async def get_agent_config():
    """Get current agent configuration including per-role details."""
    from engine.agents.registry import export_roles
    from engine.config import get_all_models

    config = _load_agent_config()
    config["roles"] = export_roles()
    # Include account assignments (may not exist in older configs)
    config.setdefault("account_assignments", {})
    # Include all available models for the dropdown
    config["available_models"] = [
        {"id": m["id"], "label": m["label"], "api_backend": m.get("api_backend")}
        for m in get_all_models()
    ]
    return config


@router.get("/api/agents/available-skills")
async def get_available_skills():
    """Return list of all discovered skill keys with metadata."""
    from pathlib import Path
    from engine.skills.registry import discover_skills
    skills_dir = Path(__file__).resolve().parent.parent.parent.parent / "skills"
    discovered = discover_skills(skills_dir)
    skills = [
        {"key": s.key, "name": s.name, "trigger": s.trigger}
        for s in discovered
    ]
    return {"skills": skills}


@router.put("/api/agents/config")
async def update_agent_config(request: Request):
    """Update agent configuration. Hot-reloads runtime settings + role overrides."""
    config = await request.json()

    # Merge with defaults (partial updates allowed)
    current = _load_agent_config()
    for key, value in config.items():
        if key in ("roles", "universal_skills"):
            continue  # handled separately
        if isinstance(value, dict) and isinstance(current.get(key), dict):
            current[key].update(value)
        else:
            current[key] = value

    # Save role overrides + universal skills
    if "roles" in config:
        current["roles"] = config["roles"]
    if "universal_skills" in config:
        current["universal_skills"] = config["universal_skills"]

    _save_agent_config(current)

    # Hot-reload runtime concurrency/resilience
    from engine.agents import get_runtime
    get_runtime().update_config(current)

    # Hot-reload role overrides + universal skills
    from engine.agents.registry import apply_role_overrides, apply_account_assignments
    apply_role_overrides(current.get("roles", {}), current.get("universal_skills"))

    # Hot-reload per-role account pools (list-based)
    if "account_assignments" in config:
        current["account_assignments"] = config["account_assignments"]
        _save_agent_config(current)
    apply_account_assignments(current.get("account_assignments", {}))

    return {"status": "updated", "config": current}


@router.get("/api/agents/active")
async def list_active_agents(chat_id: str | None = None):
    """List all agents, optionally filtered by chat."""
    from engine.agents import get_runtime

    rt = get_runtime()
    agents = rt.list_agents(chat_id)
    return [
        {
            "id": a.id,
            "role": a.role,
            "task": a.task,
            "status": a.status.value,
            "model": a.model,
            "duration": round(a.duration, 1),
            "tokens": a.tokens_used,
            "skills_used": a.skills_used,
            "chat_id": a.chat_id,
            "created_at": a.created_at,
            "browser_data_dir": a.browser_data_dir or "",
        }
        for a in agents
    ]


@router.get("/api/agents/{agent_id}/stream")
async def agent_stream(agent_id: str, request: Request, since: int = 0):
    """Per-agent SSE stream — chat-format events for the panel view.

    Drains the agent's stream_queue. Sends keepalive every 15s.
    Closes when the agent finishes (done/error event) or client disconnects.

    Reconnect support: pass ?since=N to replay missed events from the
    agent's history buffer before switching to live events.
    """
    from engine.agents import get_runtime

    rt = get_runtime()
    agent = rt.get_agent(agent_id)
    if not agent:
        return StreamingResponse(
            iter([f"data: {json.dumps({'type': 'error', 'message': 'Agent not found'})}\n\n"]),
            media_type="text/event-stream",
        )

    queue = agent.stream_queue

    async def generate():
        try:
            # Replay missed events on reconnect
            if since > 0:
                for evt in agent.get_stream_history(since_index=since):
                    yield f"data: {json.dumps(evt, ensure_ascii=False, default=str)}\n\n"

            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15)
                    yield f"data: {json.dumps(event, ensure_ascii=False, default=str)}\n\n"
                    # Close stream on terminal events
                    if event.get("type") in ("done", "error"):
                        break
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
                    # If agent is no longer running and queue is empty, close
                    if agent.status.value not in ("spawned", "running") and queue.empty():
                        yield f"data: {json.dumps({'type': 'done', 'result': (agent.result or '')[:500]})}\n\n"
                        break
        finally:
            pass

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


@router.get("/api/agents/{agent_id}/messages")
async def get_agent_history(agent_id: str):
    """Full conversation history + status for an agent.

    Uses the same get_messages() path as main chat so skill_events
    (tool calls, results, file edits) are included in history replay.
    """
    from server.database import get_messages
    from engine.agents import get_runtime

    messages = get_messages(agent_id, include_skill_events=True)
    rt = get_runtime()
    agent = rt.get_agent(agent_id)
    status = agent.status.value if agent else "unknown"
    result = {
        "agent_id": agent_id,
        "messages": messages,
        "status": status,
    }
    if agent:
        result["created_at"] = agent.created_at
        result["model"] = agent.model
        result["browser_data_dir"] = agent.browser_data_dir
        if agent.completed_at:
            result["completed_at"] = agent.completed_at
    return result


@router.get("/api/agents/{agent_id}")
async def get_agent_detail(agent_id: str):
    """Single agent detail including result."""
    from engine.agents import get_runtime

    rt = get_runtime()
    agent = rt.get_agent(agent_id)
    if not agent:
        # Fall back to DB
        from server.database import get_db
        with get_db() as conn:
            row = conn.execute(
                "SELECT * FROM agent_runs WHERE id = ?", (agent_id,)
            ).fetchone()
        if not row:
            return {"error": "Agent not found"}
        return dict(row)

    return {
        "id": agent.id,
        "role": agent.role,
        "task": agent.task,
        "context": agent.context,
        "instruction": agent.instruction,
        "status": agent.status.value,
        "model": agent.model,
        "result": agent.result,
        "error": agent.error,
        "tokens_used": agent.tokens_used,
        "skills_used": agent.skills_used,
        "duration": round(agent.duration, 1),
        "chat_id": agent.chat_id,
        "depth": agent.depth,
        "parent_id": agent.parent_id,
        "browser_data_dir": agent.browser_data_dir or "",
    }


@router.post("/api/agents/{agent_id}/kill")
async def kill_agent(agent_id: str):
    """Kill a running agent — cancels runtime task, stops upstream LLM stream, updates status."""
    from engine.agents import get_runtime
    from server.database import update_agent_status

    rt = get_runtime()
    agent = rt._agents.get(agent_id)

    # 1. Cancel the asyncio task (if any)
    task = rt._tasks.get(agent_id)
    if task and not task.done():
        task.cancel()

    # 2. Stop the upstream LLM generation so the chat.py SSE stream gets CancelledError
    try:
        from engine.service import service as _svc
        from engine.config import get_scraper_settings, scraper_service as _scraper_svc
        from server.database import get_upstream_session_id as _get_usid
        upstream_id = _get_usid(agent_id) or agent_id
        if get_scraper_settings().get("enabled") and _scraper_svc:
            _eng = getattr(_scraper_svc, "_engine", None)
            if _eng:
                await _eng.stop_generation(chat_id=upstream_id)
        elif _svc and hasattr(_svc, "_stop_upstream_generation"):
            await _svc._stop_upstream_generation(upstream_id)
    except Exception as exc:
        logger.warning("kill_agent: upstream stop failed for %s: %s", agent_id, exc)

    # 3. Update agent status
    if agent:
        agent.mark_failed("Stopped by user")
        update_agent_status(agent_id, "killed", error="Stopped by user")
        # Broadcast to all connected SSE clients so topbar/sidebar update
        broadcast_agent_event({
            "type": "agent_failed",
            "agent_id": agent_id,
            "data": {"role": agent.role, "error": "Stopped by user"},
        })
        return {"status": "killed", "agent_id": agent_id}
    return {"error": "Agent not found", "agent_id": agent_id}


@router.post("/api/agents/{agent_id}/message")
async def send_agent_message(agent_id: str, request: Request):
    """Inject a user message into a running agent's conversation (guidance)."""
    from engine.agents import get_runtime
    from server.database import add_agent_message

    body = await request.json()
    text = body.get("message", "").strip()
    if not text:
        return {"error": "message is required"}

    rt = get_runtime()
    agent = rt.get_agent(agent_id)
    if not agent:
        return {"error": "Agent not found", "agent_id": agent_id}
    if agent.status.value not in ("spawned", "running"):
        return {"error": "Agent is not running", "agent_id": agent_id}

    # Queue the message — the loop picks it up between iterations
    agent.pending_user_messages.append(text)
    # Persist to DB for history replay
    add_agent_message(agent_id, "user", text)
    # Push to SSE stream so the panel shows it immediately
    agent.push_stream_event({"type": "user_message", "text": text})

    return {"status": "queued", "agent_id": agent_id}


@router.post("/api/agents/spawn")
async def spawn_agent(request: Request):
    """Manually spawn an agent from the chat UI (@ mention).

    Uses the main chat pipeline (critique pattern): emits agent_start + agent_trigger
    events so the frontend fires POST /api/chat with the agent's chat_id.
    No separate LLM loop — the main chat handles everything.
    """
    from engine.agents import get_runtime
    from engine.agents.protocol import TaskAssignment
    from engine.agents.registry import AGENT_ROLES, get_role_config

    body = await request.json()
    role = body.get("role", "").strip().lower()
    task = body.get("task", "").strip()
    chat_id = body.get("chat_id", "").strip()
    raw_message = body.get("raw_message", "").strip()  # Original user input e.g. "@maria hello"

    if not role or not task or not chat_id:
        return {"error": "role, task, and chat_id are required"}

    valid_roles = tuple(AGENT_ROLES.keys())
    if role not in valid_roles:
        return {"error": f"Invalid role '{role}'. Must be one of: {', '.join(valid_roles)}"}

    rt = get_runtime()
    role_cfg = get_role_config(role)
    agent_model = body.get("model") or role_cfg.default_model

    assignment = TaskAssignment(
        task=task,
        role=role,
        model=agent_model,
        context=body.get("context") or None,
    )
    try:
        agent = await rt.spawn(assignment, chat_id)
    except RuntimeError as exc:
        return {"error": str(exc)}

    # The canonical /api/chat turn persists this task and owns the title.

    # Build system prompt from role instruction
    system_prompt = role_cfg.system_prompt or f"You are a {role} agent. Task: {task}"
    if assignment.context:
        agent_message = f"Context: {assignment.context}\n\nTask: {task}"
    else:
        agent_message = f"Task: {task}"

    # NOTE: rt.spawn() already emits "agent_spawned" via the runtime event callback,
    # which the frontend handles to create the topbar card. We only need to emit
    # agent_trigger here to kick off the LLM turn.

    # Emit agent_trigger — frontend fires POST /api/chat through main pipeline
    push_agent_event(chat_id, {
        "type": "agent_trigger",
        "id": agent.id,
        "message": agent_message,
        "system_prompt": system_prompt,
        "model": agent_model,
        "browser_data_dir": agent.browser_data_dir or None,
        "collect": False,
    })

    return {"status": "spawned", "agent_id": agent.id, "role": role, "model": agent_model}



