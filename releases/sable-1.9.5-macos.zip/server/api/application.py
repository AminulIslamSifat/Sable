from __future__ import annotations

import asyncio
import json
import platform
import shutil
import subprocess
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Generator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from engine.memory_search import get_searcher
from connectors.deepseek.client import get_client as get_deepseek_client

from .dependencies import service
from server.database import init_db, recover_stale_agents, migrate_skill_events_to_table
import server.auth as _auth_mod
from server.config import (
    AUTH_EXEMPT_PREFIXES, WEB_DIR, UPLOAD_DIR,
    _MEMORY_SEARCH_SETTINGS,
)
from engine.config import ASSETS_DIR
from server.utils import logger

# Import routers
from .routes.auth import router as auth_router
from .routes.chats import router as chats_router
from .routes.memory import router as memory_router
from .routes.settings import router as settings_router
from .routes.scraper import router as scraper_router
from .routes.upload import router as upload_router
from .routes.deepseek import router as deepseek_router
from .routes.chat import router as chat_router
from .routes.misc import router as misc_router
from .routes.agents import router as agents_router
from .routes.library import router as library_router
from .routes.email import router as email_router
from .routes.filesystem import router as filesystem_router
from .routes.terminal import router as terminal_router
from .routes.telegram import router as telegram_router
from .routes.research import router as research_router
from .routes.tracknote import router as tracknote_router
from .routes.setup import router as setup_router
from .routes.cookbook import router as cookbook_router
from .routes.checkpoints import router as checkpoints_router
from .routes.personas import router as personas_router
from .routes.update import router as update_router
from .routes.dashboard import router as dashboard_router
from .routes.telegram_bot import router as telegram_bot_router
from .routes.ocr import router as ocr_router
from .routes.ocr_local import router as ocr_local_router

_sidecar_proc: subprocess.Popen | None = None


def _start_sidecar() -> subprocess.Popen | None:
    system = platform.system().lower()
    machine = platform.machine().lower()

    if system == "windows":
        name = "pow-solver-windows-amd64.exe"
    elif system == "linux":
        if "aarch64" in machine or "arm64" in machine:
            name = "pow-solver-linux-arm64"
        else:
            name = "pow-solver-linux-amd64"
    elif system == "darwin":
        name = "pow-solver-darwin-arm64"
    else:
        logger.debug("Sidecar: unsupported platform %s", system)
        return None

    repo_root = Path(__file__).resolve().parents[2]
    sidecar_path = repo_root / "connectors" / "solver" / name

    if not sidecar_path.exists():
        logger.debug("Sidecar binary not found: %s", sidecar_path)
        return None

    try:
        proc = subprocess.Popen(
            [str(sidecar_path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return proc
    except Exception as exc:
        logger.warning("Failed to start sidecar: %s", exc)
        return None


def _raise_nofile_limit() -> None:
    """Raise open file limit for agentic workloads (browsers, agents, streams)."""
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = min(65536, hard)
        if soft < target:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
            logger.info("Raised RLIMIT_NOFILE: %d → %d (hard=%d)", soft, target, hard)
    except ImportError:
        pass  # Windows: no resource module
    except Exception as exc:
        logger.warning("Could not raise RLIMIT_NOFILE: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI) -> Generator[None, None, None]:
    _raise_nofile_limit()

    import asyncio as _aio
    from engine.agents import get_runtime as _get_rt_startup
    _get_rt_startup()._loop = _aio.get_running_loop()

    # Auto-connect enabled MCP servers in the background.
    # Keep a strong reference to prevent silent GC and log any runtime errors.
    async def _mcp_startup() -> None:
        try:
            from engine.mcp.manager import get_mcp_manager
            await get_mcp_manager().connect_all_enabled()
        except Exception as exc:
            logger.error("MCP auto-connect failed: %s: %s", type(exc).__name__, exc)

    app.state._mcp_startup_task = _aio.create_task(_mcp_startup())

    init_db()
    # One-time migration: move skill_events from messages column to dedicated table
    migrated = migrate_skill_events_to_table()
    if migrated:
        logger.info("Migrated skill_events for %d messages to dedicated table", migrated)
    stale = recover_stale_agents()
    if stale:
        logger.info("Recovered %d stale agent(s) from previous session", stale)
    # Load saved agent config and apply to runtime + registry
    try:
        from engine.config import AGENT_CONFIG_PATH
        from engine.agents.registry import apply_role_overrides, apply_account_assignments
        if AGENT_CONFIG_PATH.exists():
            _acfg = json.loads(AGENT_CONFIG_PATH.read_text(encoding="utf-8"))
            # Apply concurrency/resilience/limits to runtime (fixes hardcoded defaults on restart)
            _get_rt_startup().update_config(_acfg)
            if _acfg.get("roles"):
                apply_role_overrides(_acfg["roles"])
            if _acfg.get("account_assignments"):
                apply_account_assignments(_acfg["account_assignments"])
    except Exception:
        pass
    if _MEMORY_SEARCH_SETTINGS.exists():
        try:
            _ms = json.loads(_MEMORY_SEARCH_SETTINGS.read_text(encoding="utf-8"))
            _s = get_searcher()
            if _ms.get("model"):
                _s.set_model(str(_ms["model"]))
            if isinstance(_ms.get("model_thresholds"), dict):
                _s.set_thresholds(_ms["model_thresholds"])
        except Exception:
            pass
    # Start agent ops scheduler (event-driven, no polling)
    try:
        from server.scheduler import start_scheduler
        _aio.create_task(start_scheduler())
    except Exception as exc:
        logger.warning("Agent ops scheduler failed to start: %s: %s", type(exc).__name__, exc)

    # Start Qwen chat history auto-cleanup scheduler (daily 6 PM, 5-day interval)
    try:
        from server.qwen_history_scheduler import start_qwen_history_scheduler
        start_qwen_history_scheduler()
    except Exception as exc:
        logger.warning("Qwen history scheduler failed to start: %s: %s", type(exc).__name__, exc)

    # ── Auto-start Telegram Bot if token is configured ──
    _tg_bot_task = None
    try:
        from engine.config import PERSISTENT_ROOT as _PROOT
        _tg_cfg_path = _PROOT / "system" / ".telegram_bot_config.json"
        if _tg_cfg_path.exists():
            _tg_cfg = json.loads(_tg_cfg_path.read_text(encoding="utf-8"))
            if _tg_cfg.get("bot_token") and _tg_cfg.get("enabled", True):
                from telegram_bot.bot import start_bot_in_background
                _tg_bot_task = _aio.create_task(start_bot_in_background())
                logger.info("Telegram Bot auto-started (token configured)")
            else:
                logger.info("Telegram Bot: skipped (no token or disabled)")
        else:
            logger.info("Telegram Bot: no config file at %s", _tg_cfg_path)
    except Exception as exc:
        logger.warning("Telegram Bot auto-start failed: %s: %s", type(exc).__name__, exc)


    global _sidecar_proc
    _sidecar_proc = _start_sidecar()

    await service.warmup()
    # Refresh ALL providers (Qwen WAF + DeepSeek + z.ai + Gemini) so every
    # backend starts on the active profile's credentials, not a stale one.
    try:
        _tok = await service.refresh_all_provider_tokens()
        logger.info("Startup provider token refresh: %s", _tok)
    except Exception as exc:
        logger.warning("Startup provider token refresh failed: %s: %s", type(exc).__name__, exc)
    # Auto-sync context for the active browser profile on startup
    try:
        await service.sync_context()
        logger.info("Context synced on startup")
    except Exception as exc:
        logger.warning("Startup sync_context failed: %s: %s", type(exc).__name__, exc)
    yield
    # ── Fast shutdown (≤1s budget) ──
    # 1. Cancel running agents immediately
    try:
        from engine.agents import get_runtime as _get_rt
        _rt = _get_rt()
        for _task in list(getattr(_rt, '_tasks', {}).values()):
            if not _task.done():
                _task.cancel()
    except Exception:
        pass

    # 2. Scheduler
    try:
        from server.scheduler import cancel_all
        cancel_all()
    except Exception:
        pass

    # 3. Main browser — 0.5s timeout
    try:
        await asyncio.wait_for(service.close(), timeout=0.5)
    except Exception:
        pass

    # 4. Scraper browser — 0.5s timeout
    try:
        from engine.scraper import scraper as scraper_service
        await asyncio.wait_for(scraper_service.stop(kill_browser=True), timeout=0.5)
    except Exception:
        pass

    # 5. MCP — 0.5s timeout
    try:
        from engine.mcp.manager import get_mcp_manager
        await asyncio.wait_for(get_mcp_manager().shutdown(), timeout=0.5)
    except Exception:
        pass

    # 6. Telegram (Telethon) — 0.3s timeout
    try:
        from server.api.routes.telegram import disconnect_client
        await asyncio.wait_for(disconnect_client(), timeout=0.3)
    except Exception:
        pass

    # 7. Telegram Bot — cancel background task
    if _tg_bot_task and not _tg_bot_task.done():
        _tg_bot_task.cancel()


    if _sidecar_proc is not None:
        try:
            _sidecar_proc.terminate()
            _sidecar_proc.wait(timeout=3)
        except Exception:
            try:
                _sidecar_proc.kill()
            except Exception:
                pass
        _sidecar_proc = None
        try:
            await asyncio.wait_for(_tg_bot_task, timeout=1.0)
        except Exception:
            pass

app = FastAPI(title="Sable API", version="0.4.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Cache policy:
# - HTML (/ and /index.html): no-cache (always revalidate — small payload, must be fresh)
# - Static assets (/static/*): short cache with revalidation. Query-string versioning
#   (?v=N) already handles cache-busting when files change. Without this, browsers
#   re-fetch ~40+ assets on every reload, causing intermittent load failures under
#   server load (startup, MCP connect, etc.).
@app.middleware("http")
async def cache_policy(request: Request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path in ("/", "/index.html"):
        response.headers["Cache-Control"] = "no-cache"
    elif path.startswith("/static/"):
        # Always revalidate — prevents stale CSS/JS during development.
        # ETag/Last-Modified still allows 304 Not Modified when unchanged.
        response.headers["Cache-Control"] = "no-cache, must-revalidate"
    return response

if WEB_DIR.exists():
    app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")

if UPLOAD_DIR.exists():
    app.mount("/system/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

ASSETS_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/assets", StaticFiles(directory=ASSETS_DIR), name="assets")

# ---------- Auth Middleware ----------
@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    path = request.url.path
    if not path.startswith("/api/") or any(path.startswith(p) for p in AUTH_EXEMPT_PREFIXES):
        return await call_next(request)
    auth_header = request.headers.get("authorization", "")
    authorized = auth_header.startswith("Bearer ") and auth_header[7:] == _auth_mod.AUTH_TOKEN
    if not authorized and (
        path == "/api/logs"
        or path.endswith("/agent-events")
        or path.startswith("/api/research/events/")
    ):
        authorized = request.query_params.get("token", "") == _auth_mod.AUTH_TOKEN
    if not authorized:
        return JSONResponse(status_code=401, content={"detail": "Unauthorized"})
    return await call_next(request)

# Include routers
app.include_router(auth_router)
app.include_router(chats_router)
app.include_router(memory_router)
app.include_router(settings_router)
app.include_router(scraper_router)
app.include_router(upload_router)
app.include_router(deepseek_router)
app.include_router(chat_router)
app.include_router(misc_router)
app.include_router(agents_router)
app.include_router(library_router)
app.include_router(email_router)
app.include_router(filesystem_router)
app.include_router(terminal_router)
app.include_router(telegram_router)
app.include_router(research_router)
app.include_router(tracknote_router)
app.include_router(setup_router)
app.include_router(cookbook_router)
app.include_router(checkpoints_router)
app.include_router(personas_router)
app.include_router(update_router)
app.include_router(dashboard_router)
app.include_router(telegram_bot_router)
app.include_router(ocr_router)
app.include_router(ocr_local_router)

# Wire agent runtime event callback → SSE push
from .routes.agents import _async_push_agent_event, push_agent_event
from engine.agents import get_runtime as _get_agent_runtime
_get_agent_runtime().set_event_callback(_async_push_agent_event)

# Wire auto-turn engine: agent results → signal frontend to run a normal chat turn
from engine.agents.auto_turn import auto_turn as _auto_turn


async def _auto_turn_signal(chat_id: str, message: str, parent_chat_id: str | None = None) -> None:
    """Push an auto_turn_trigger event so the frontend initiates a normal /api/chat call."""
    push_agent_event(chat_id, {
        "type": "auto_turn_trigger",
        "agent_id": None,
        "data": {
            "message": message,
            "parent_chat_id": parent_chat_id or chat_id,
        },
    })


_auto_turn.set_signal_fn(_auto_turn_signal)