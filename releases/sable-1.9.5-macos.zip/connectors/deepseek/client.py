
"""DeepSeek API connector for Sable.

Pure HTTP backend — no browser needed for chat (only for initial token extraction).
Solves PoW via compiled Go binary (~80ms), streams SSE responses.

Yields events matching Sable's stream interface:
  {"type": "answer", "text": "..."}
  {"type": "thinking", "text": "..."}
  {"type": "done", "parent_id": "..."}
  {"type": "error", "message": "..."}
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import random
import subprocess
import sys
from collections.abc import AsyncGenerator, Awaitable, Callable
from pathlib import Path
from typing import Any

from curl_cffi.requests import AsyncSession
from curl_cffi.requests.exceptions import ReadTimeout as CurlReadTimeout

from connectors.common.instruction_builder import get_tool_format

logger = logging.getLogger("sable.deepseek_api")

BASE_URL = "https://chat.deepseek.com"
_SOLVER_DIR = Path(__file__).resolve().parent / "pow_solver"
_SOLVER_NAME = "pow_solver.exe" if sys.platform == "win32" else "pow_solver"
SOLVER_PATH = _SOLVER_DIR / _SOLVER_NAME

# Raw request/response logging
from engine.config import LOGS_DIR as _LOGS_DIR
_RAW_LOG_PATH = _LOGS_DIR / "deepseek_raw.txt"


def _log_raw(direction: str, payload: str) -> None:
    """Append a timestamped raw payload to the log file."""
    try:
        _RAW_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        from datetime import datetime
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(_RAW_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"\n{'='*80}\n[{ts}] {direction}\n{'='*80}\n{payload}\n")
    except Exception:
        pass

# Per-account token store: {"browser-data-acc1": ["jwt1", "jwt2", ...], ...}
# Tokens never expire, so we accumulate them in a list per account.
# Capped at MAX_TOKENS_PER_ACCOUNT to prevent unbounded file growth.
_SYSTEM_DIR = Path(__file__).resolve().parent.parent.parent / "system"
TOKEN_STORE_PATH = _SYSTEM_DIR / ".deepseek_tokens.json"
MAX_TOKENS_PER_ACCOUNT = 10


# Per-account device fingerprint store (browser identity header)
FP_STORE_PATH = _SYSTEM_DIR / ".deepseek_fp.json"


def _load_fp_store() -> dict[str, str]:
    if FP_STORE_PATH.exists():
        try:
            raw = json.loads(FP_STORE_PATH.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                return raw
        except Exception:
            pass
    return {}


def _save_fp_store(store: dict[str, str]) -> None:
    import tempfile
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8",
        dir=str(FP_STORE_PATH.parent), suffix=".tmp",
        delete=False,
    ) as tmp:
        json.dump(store, tmp, indent=2)
        tmp_path = tmp.name
    os.replace(tmp_path, str(FP_STORE_PATH))


def get_fp_for_account(account: str | None = None) -> str | None:
    acct = account or _resolve_active_account()
    store = _load_fp_store()
    return store.get(acct)


def set_fp_for_account(value: str, account: str | None = None) -> None:
    acct = account or _resolve_active_account()
    store = _load_fp_store()
    store[acct] = value
    _save_fp_store(store)


def _auto_rotate_enabled(provider: str) -> bool:
    """Check if auto-rotation is enabled for a provider via settings.json."""
    try:
        path = _SYSTEM_DIR / "settings.json"
        if not path.is_file():
            return True
        settings = json.loads(path.read_text(encoding="utf-8"))
        per_provider = settings.get("account_auto_switch")
        if isinstance(per_provider, dict) and provider in per_provider:
            return bool(per_provider[provider])
        return bool(settings.get("account_auto_switch_enabled", True))
    except Exception:
        return True

# Legacy single-token cache (migrated on first access)
_LEGACY_TOKEN_CACHE = Path(__file__).resolve().parent / ".token_cache.json"
_LEGACY_MIGRATED = False  # guard so migration only runs once


# --------------------------------------------------------------------------
# Per-account token store helpers (list-based — tokens accumulate)
# --------------------------------------------------------------------------

def _resolve_active_account() -> str:
    """Get the active account name. Delegates to engine.config.get_active_account()."""
    from engine.config import get_active_account
    return get_active_account()


def _load_token_store() -> dict[str, list[str]]:
    """Load the per-account token store, migrating legacy formats if needed.

    Returns {account: [token, ...]}. Handles migration from:
      - Old flat format {account: "token"} → {account: ["token"]}
      - Legacy single-token .token_cache.json (runs once only)
    """
    global _LEGACY_MIGRATED
    raw: dict = {}
    if TOKEN_STORE_PATH.exists():
        try:
            raw = json.loads(TOKEN_STORE_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass

    store: dict[str, list[str]] = {}
    for key, val in raw.items():
        if isinstance(val, list):
            valid = [t for t in val if t and t != "None"]
        elif isinstance(val, str) and val and val != "None":
            # Migrate old flat format → list
            valid = [val]
        else:
            valid = []
        # Collapse to the single CURRENT token. An account has exactly one
        # live auth token; anything older is a stale duplicate left behind by
        # a refresh. Keeping only the latest also cleans the file on next save.
        store[key] = valid[-1:]

    # One-time migration from legacy single-token file (guarded)
    if not store and not _LEGACY_MIGRATED and _LEGACY_TOKEN_CACHE.exists():
        _LEGACY_MIGRATED = True
        try:
            legacy = json.loads(_LEGACY_TOKEN_CACHE.read_text(encoding="utf-8"))
            tok = legacy.get("token")
            if tok and tok != "None":
                account = _resolve_active_account()
                store[account] = [tok]
                _save_token_store(store)
                _LEGACY_TOKEN_CACHE.unlink(missing_ok=True)
                logger.info("Migrated legacy token to per-account list store (%s)", account)
        except Exception:
            pass
    return store


def _save_token_store(store: dict[str, list[str]]) -> None:
    """Persist the per-account token store atomically (write-to-tmp + rename)."""
    import tempfile
    try:
        data = json.dumps(store, indent=2)
        fd, tmp_path = tempfile.mkstemp(
            dir=str(TOKEN_STORE_PATH.parent), suffix=".tmp"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data)
            os.replace(tmp_path, str(TOKEN_STORE_PATH))
        except BaseException:
            # Clean up temp file on any failure
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except Exception as exc:
        logger.warning("Could not save token store: %s", exc)


def get_own_token_for_account(account: str) -> str | None:
    """Strict lookup — ONLY returns a token actually captured FOR this account.

    Unlike get_token_for_account(), this NEVER falls back to another account.
    Use this for capture/refresh paths so we never persist a foreign token
    under the wrong account key (the bug that smeared 'ds' badges everywhere).
    """
    store = _load_token_store()
    tokens = [t for t in store.get(account, []) if t and t != "None"]
    return tokens[-1] if tokens else None


def get_token_for_account(account: str | None = None) -> str | None:
    """Get the most recent token for an account, falling back to any available.

    READ-ONLY helper for chat/API calls. The cross-account fallback is
    intentional here: any live token beats none. Do NOT use this as the
    source value for save_token_for_account() — use get_own_token_for_account().

    Returns the last token in the list (most recently added) since tokens
    don't expire and newer ones are preferred.
    """
    store = _load_token_store()
    if not store:
        return None

    def _latest(tokens: list[str]) -> str | None:
        valid = [t for t in tokens if t and t != "None"]
        return valid[-1] if valid else None

    # Primary: requested account
    if account and account in store:
        tok = _latest(store[account])
        if tok:
            return tok
    # Fallback: active account
    active = _resolve_active_account()
    if active in store:
        tok = _latest(store[active])
        if tok:
            return tok
    # Last resort: any account with a valid token
    for tokens in store.values():
        tok = _latest(tokens)
        if tok:
            return tok
    return None


def get_unique_tokens() -> list[str]:
    """Load all tokens from the store, deduplicate, return unique valid tokens."""
    store = _load_token_store()
    seen: set[str] = set()
    unique: list[str] = []
    for tokens in store.values():
        for tok in tokens:
            if tok and tok != "None" and tok not in seen:
                seen.add(tok)
                unique.append(tok)
    return unique


def get_unique_tokens_with_accounts() -> list[dict[str, str]]:
    """Return unique tokens with their browser-data account association.

    Returns list of {"token": ..., "account": "browser-data-accN"} dicts.
    If a token appears under multiple accounts, first occurrence wins.
    """
    store = _load_token_store()
    seen: set[str] = set()
    result: list[dict[str, str]] = []
    for account, tokens in store.items():
        for tok in tokens:
            if tok and tok != "None" and tok not in seen:
                seen.add(tok)
                result.append({"token": tok, "account": account})
    return result


def save_token_for_account(token: str, account: str | None = None) -> None:
    """Store the CURRENT token for an account, overwriting any previous value.

    Refresh must be idempotent: the newest token replaces the old one so a
    single account never accumulates stale duplicates. A refresh means "this
    is now the live token for this account" — accumulating old ones only
    bloated the rotation pool with dead keys. Uses atomic write.
    """
    if not token or token == "None":
        return
    acct = account or _resolve_active_account()
    store = _load_token_store()
    store[acct] = [token]
    _save_token_store(store)

# Application-level headers only.
# TLS fingerprint, User-Agent, sec-ch-ua, Accept-Language are all injected
# automatically by curl_cffi's impersonate="chrome" — no need to set them here.
CLIENT_HEADERS = {
    "x-client-version": "2.5.0",
    "x-client-platform": "web",
    "x-client-bundle-id": "com.deepseek.chat",
    "x-client-locale": "en_US",
    "x-client-timezone-offset": "21600",
}

# Client-side history cap (matches Gemini/Mistral sliding window)
_MAX_SESSION_CHARS = 100_000

# Account/token-switch context compression (Hermes pattern, mirrors Qwen).
# Chats under this many chars are serialized raw; bigger ones get summarized.
_SWITCH_SUMMARIZE_MIN = 40_000
_SWITCH_HEAD_TURNS = 2   # user/assistant pairs kept verbatim at the start
_SWITCH_TAIL_TURNS = 4   # user/assistant pairs kept verbatim at the end

# Self-summarization (LLM-in-the-loop context compression) is DISABLED.
# It fired a full extra completion call BEFORE the real request, adding
# 10-30s of pre-send latency whenever history crossed the force threshold.
# Flip to True to re-enable.
_ENABLE_SELF_SUMMARIZE = False


def _split_head_tail(
    messages: list[dict[str, Any]],
) -> tuple[str, str, list[dict[str, Any]]]:
    """Split history into (head_text, tail_text, middle) for summarization.

    Head = first `_SWITCH_HEAD_TURNS` message pairs, tail = last
    `_SWITCH_TAIL_TURNS` pairs, both kept verbatim. Middle = everything
    between them, to be compressed by the summarizer.
    """
    if not messages:
        return "", "", []

    head_n = _SWITCH_HEAD_TURNS * 2
    tail_n = _SWITCH_TAIL_TURNS * 2

    # Not enough to bother splitting — keep everything verbatim.
    if len(messages) <= head_n + tail_n:
        rendered = "\n".join(
            f"[{m.get('role', 'user')}]: {m.get('content', '')}" for m in messages
        )
        return rendered, "", []

    head_msgs = messages[:head_n]
    tail_msgs = messages[-tail_n:]
    middle = messages[head_n:-tail_n]

    head_text = "\n".join(
        f"[{m.get('role', 'user')}]: {m.get('content', '')}" for m in head_msgs
    )
    tail_text = "\n".join(
        f"[{m.get('role', 'user')}]: {m.get('content', '')}" for m in tail_msgs
    )
    return head_text, tail_text, middle

from connectors.common.context_summarizer import (
    should_inject_hint, should_force_summarize, get_hint_text,
    extract_summarize_tag, strip_summarize_tag, build_summary_prompt,
    rewrite_history_with_summary, compute_force_cut_index,
)


def _msg_chars(msg: dict[str, Any]) -> int:
    """Character count of a DeepSeek-format history message."""
    return len(msg.get("content", ""))


def _trim_history(history: list[dict[str, Any]], prefix_len: int, max_chars: int) -> list[dict[str, Any]]:
    """Trim history to fit within max_chars, preserving prefix messages."""
    prefix = history[:prefix_len]
    msgs = history[prefix_len:]
    total = sum(_msg_chars(m) for m in msgs)
    while total > max_chars and len(msgs) > 1:
        total -= _msg_chars(msgs.pop(0))
    return prefix + msgs


# Instruction loading — uses shared builder with project-aware overrides
_instruction_cache: str | None = None
_cached_project_id: str | None = "__none__"
_cached_layout_mode: str | None = "__none__"
_cached_version: int = -1


def _load_instructions(project_id: str | None = None, layout_mode: str | None = None) -> str:
    """Load instruction context for first-message injection. Project-aware."""
    global _instruction_cache, _cached_project_id, _cached_version, _cached_layout_mode
    from connectors.common.instruction_builder import get_instruction_version
    current_version = get_instruction_version()
    # Invalidate cache when project, layout mode, or instruction version changes
    if (project_id != _cached_project_id
            or layout_mode != _cached_layout_mode
            or current_version != _cached_version):
        _instruction_cache = None
        _cached_project_id = project_id
        _cached_layout_mode = layout_mode
        _cached_version = current_version
    if _instruction_cache is not None:
        return _instruction_cache
    from connectors.common.instruction_builder import build_instructions
    _instruction_cache = build_instructions(
        project_id=project_id, provider="deepseek", layout_mode=layout_mode,
    )
    return _instruction_cache


class DeepSeekAPIError(Exception):
    """Raised on auth failure or unexpected API response."""


class DeepSeekClient:
    """Async DeepSeek chat client with PoW solving and automatic token rotation.

    Mirrors the Gemini/Mistral connector pattern:
      - Client-side conversation history per chat_id (no server-side session)
      - Full context serialized into prompt each request (parent_id=None, stateless)
      - Automatic round-robin token rotation with failover across unique tokens
      - Sliding-window history trimming at _MAX_SESSION_CHARS
    """

    def __init__(
        self,
        token: str | None = None,
        token_refresher: Callable[[], Awaitable[str]] | None = None,
        account: str | None = None,
        model_id: str | None = None,
    ) -> None:
        self._token = token
        self._token_refresher = token_refresher
        self._account = account  # e.g. "browser-data-acc15"; None = active
        self._model_id = model_id or "deepseek-instant"
        self._http: AsyncSession | None = None
        self._lock = asyncio.Lock()
        # Client-side conversation history: chat_id → [message dicts]
        self._sessions: dict[str, list[dict[str, Any]]] = {}
        # Server-side message chaining: chat_id → last assistant message_id
        # Used as parent_message_id for the next request so DeepSeek chains server-side.
        # DeepSeek message_id is an integer (not string).
        self._parent_ids: dict[str, int | None] = {}
        # Token rotation state (always active — like Gemini/Mistral key rotation)
        self._rotate_tokens: list[str] = []
        self._rotate_idx: int = 0
        self._rotate_sessions: dict[str, str] = {}  # token → deepseek session_id
        self._last_prepare_error: str | None = None  # surfaced when all tokens fail

        # Load per-model max session chars from config
        from engine.config import get_model_config
        config = get_model_config(self._model_id)
        self._max_session_chars = config.get("max_session_chars", 100_000)

    @property
    def account(self) -> str:
        """Resolved account name for this client instance."""
        return self._account or _resolve_active_account()

    def set_token_refresher(self, refresher: Callable[[], Awaitable[str]] | None) -> None:
        """Inject an external coroutine that returns a fresh DeepSeek token."""
        self._token_refresher = refresher

    # ------------------------------------------------------------------
    # Token management (per-account)
    # ------------------------------------------------------------------

    @property
    def token(self) -> str | None:
        if self._token:
            return self._token
        # Check persisted user preference before generic fallback
        preferred = self._get_preferred_token_from_settings()
        if preferred:
            self._token = preferred
            return self._token
        # Resolve from per-account store (with fallback)
        self._token = get_token_for_account(self._account)
        return self._token

    @property
    def is_available(self) -> bool:
        """Whether the connector has valid credentials."""
        return self.token is not None

    def set_token(self, token: str, account: str | None = None, *, persist: bool = True) -> None:
        """Set and (optionally) persist token under the given account.

        Pass persist=False when the token came from a cross-account fallback
        (e.g. rotation handoff) so it is used in-memory but NOT written under
        an account it doesn't belong to.
        """
        self._token = token
        # Invalidate rotation cache so next request picks up the new token
        self._rotate_tokens = []
        self._rotate_idx = 0
        # Account/token switch == new upstream chat. Drop stale parent chains
        # so the next turn doesn't reference a message_id that never existed on
        # the new account, and drop the incoming token's cached session so it
        # gets a fresh chat_session instead of inheriting the old one.
        self._parent_ids.clear()
        if token:
            self._rotate_sessions.pop(token, None)
        if persist and token:
            save_token_for_account(token, account or self._account)

    # ------------------------------------------------------------------
    # Token rotation (automatic round-robin + failover, like Gemini/Mistral)
    # ------------------------------------------------------------------

    @staticmethod
    def _get_preferred_token_from_settings() -> str | None:
        """Read the user's manually-selected DeepSeek token from settings.json."""
        try:
            path = _SYSTEM_DIR / "settings.json"
            if not path.is_file():
                return None
            settings = json.loads(path.read_text(encoding="utf-8"))
            tok = settings.get("deepseek_preferred_token")
            if tok and isinstance(tok, str) and tok != "None":
                return tok
        except Exception:
            pass
        return None

    def _init_rotation(self) -> None:
        """Load all unique tokens across accounts for round-robin rotation.

        DeepSeek tokens are browser-session-bound JWTs but they work like API
        keys — no browser needed to use them. Load ALL unique tokens from the
        store so auto-rotate can failover across accounts when one gets
        rate-limited or muted.
        """
        # Load all unique tokens across all accounts for rotation
        all_tokens = get_unique_tokens()

        # If a specific token was explicitly set (e.g. manual switch), ensure
        # it's in the pool and start from it — but DON'T restrict to just it
        if self._token and self._token not in all_tokens:
            all_tokens.insert(0, self._token)

        if all_tokens:
            self._rotate_tokens = all_tokens
            # Priority: persisted user preference > in-memory > active account.
            # User preference MUST win because application.py calls set_token()
            # on startup with a freshly-scraped browser token, which would
            # otherwise silently override the user's manual key selection.
            preferred = (
                self._get_preferred_token_from_settings()
                or self._token
                or get_own_token_for_account(self.account)
            )
            if preferred and preferred in self._rotate_tokens:
                self._rotate_idx = self._rotate_tokens.index(preferred)
            else:
                self._rotate_idx = 0
            # Keep in-memory token in sync with rotation starting point so
            # the .token property, is_available, etc. reflect the actual active key.
            start_token = self._current_rotate_token
            if start_token and start_token != self._token:
                self._token = start_token
        else:
            self._rotate_tokens = []
            self._rotate_idx = 0

        logger.info("[DeepSeek] Rotation pool loaded: %d tokens (account=%s, starting at idx=%d)",
                     len(self._rotate_tokens), self.account, self._rotate_idx)

    @property
    def _current_rotate_token(self) -> str | None:
        if not self._rotate_tokens:
            return None
        return self._rotate_tokens[self._rotate_idx % len(self._rotate_tokens)]

    @staticmethod
    def _mask_token(token: str | None) -> str:
        """Mask a JWT token for safe display: show first 8 + last 4 chars."""
        if not token or len(token) < 16:
            return "***"
        return f"{token[:8]}…{token[-4:]}"

    def _advance_rotation(self) -> None:
        if not self._rotate_tokens:
            return
        if not _auto_rotate_enabled("deepseek"):
            logger.info("[DeepSeek] Auto-rotate disabled — staying on current token")
            return
        self._rotate_idx = (self._rotate_idx + 1) % len(self._rotate_tokens)

    def _auth_headers_for(self, token: str) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {token}", **CLIENT_HEADERS}
        fp = get_fp_for_account(self._account)
        if fp:
            headers["x-hif-leim"] = fp
        return headers

    def _auth_headers(self) -> dict[str, str]:
        """Auth headers using current rotation token (or fallback single token)."""
        if self._rotate_tokens:
            tok = self._current_rotate_token
        else:
            tok = self.token
        if not tok:
            raise DeepSeekAPIError("No DeepSeek token available.")
        return {"Authorization": f"Bearer {tok}", **CLIENT_HEADERS}

    async def _prepare_request_with_rotation(self) -> tuple[str, dict[str, str]] | None:
        """Pick a usable token, get/create its session, solve PoW.

        Returns (session_id, headers) or None if all tokens exhausted.
        Always uses parent_id=None (stateless) — context is in the prompt.
        Advances past tokens that fail; does NOT advance on success (caller does).
        """
        if not self._rotate_tokens:
            self._init_rotation()
        if not self._rotate_tokens:
            return None

        auto_rotate = _auto_rotate_enabled("deepseek")
        # When auto-rotate is off, only try the current token once.
        # When on, try all tokens in the pool.
        max_tries = 1 if not auto_rotate else len(self._rotate_tokens)
        tried = 0

        while tried < max_tries:
            token = self._current_rotate_token
            if not token:
                if not auto_rotate:
                    break
                self._advance_rotation()
                tried += 1
                continue

            auth = self._auth_headers_for(token)

            # One persistent session per token (avoids ~460ms create overhead per turn)
            if token not in self._rotate_sessions:
                try:
                    session_id = await self._create_session(headers=auth)
                    self._rotate_sessions[token] = session_id
                except DeepSeekAPIError as exc:
                    logger.warning("Rotation: session failed for %s...: %s", token[:10], exc)
                    self._last_prepare_error = str(exc)
                    if not auto_rotate:
                        break
                    self._advance_rotation()
                    tried += 1
                    continue
                except Exception as exc:
                    logger.warning("Rotation: session failed for %s...: %s", token[:10], exc)
                    self._last_prepare_error = str(exc)
                    if not auto_rotate:
                        break
                    self._advance_rotation()
                    tried += 1
                    continue
            session_id = self._rotate_sessions[token]

            try:
                challenge = await self._get_challenge(headers=auth)
                loop = asyncio.get_running_loop()
                nonce = await loop.run_in_executor(None, self._solve_pow, challenge)
                pow_header = self._build_pow_header(challenge, nonce)
            except DeepSeekAPIError as exc:
                logger.warning("Rotation: PoW failed for %s...: %s", token[:10], exc)
                self._last_prepare_error = str(exc)
                if not auto_rotate:
                    break
                self._advance_rotation()
                tried += 1
                continue
            except Exception as exc:
                logger.warning("Rotation: PoW failed for %s...: %s", token[:10], exc)
                self._last_prepare_error = str(exc)
                if not auto_rotate:
                    break
                self._advance_rotation()
                tried += 1
                continue

            headers = {**auth, "X-DS-PoW-Response": pow_header, "Content-Type": "application/json"}
            headers["Referer"] = f"https://chat.deepseek.com/a/chat/s/{session_id}"
            return session_id, headers

        return None

    # ------------------------------------------------------------------
    # Token auto-refresh
    # ------------------------------------------------------------------

    @property
    def _BROWSER_PROFILE(self) -> Path:
        from engine.config import BROWSER_DATA_DIR
        return BROWSER_DATA_DIR

    async def refresh_token(self) -> str:
        """Public method — refresh token using injected refresher or fallback browser profile."""
        return await self._refresh_token()

    async def _refresh_token(self) -> str:
        """Refresh token via external provider when available, else standalone browser."""
        if self._token_refresher is not None:
            logger.info("Refreshing DeepSeek token via injected browser session...")
            token = await self._token_refresher()
            if not token:
                raise DeepSeekAPIError("Token refresher returned an empty token.")
            self.set_token(token)
            logger.info("Token refreshed successfully via injected browser session.")
            return token
        return await self._refresh_token_from_browser()

    async def _refresh_token_from_browser(self) -> str:
        """Fallback: open persistent browser profile, read DeepSeek token from localStorage."""
        from playwright.async_api import async_playwright

        logger.info("Refreshing DeepSeek token from standalone browser profile...")
        async with async_playwright() as pw:
            ctx = await pw.chromium.launch_persistent_context(
                user_data_dir=str(self._BROWSER_PROFILE),
                headless=True,
                args=["--disable-gpu", "--no-sandbox"],
            )
            page = ctx.pages[0] if ctx.pages else await ctx.new_page()
            await page.goto("https://chat.deepseek.com", wait_until="domcontentloaded", timeout=15000)
            await page.wait_for_timeout(2000)  # let JS hydrate localStorage
            token = await page.evaluate("() => localStorage.getItem('userToken')")
            await ctx.close()

        if not token:
            raise DeepSeekAPIError("No userToken found in browser profile. Log in to chat.deepseek.com first.")

        token = self._parse_localstorage_token(token)
        self.set_token(token)
        logger.info("Token refreshed successfully from standalone browser.")
        return token

    @staticmethod
    def _parse_localstorage_token(raw: str) -> str:
        # localStorage stores JSON: {"value":"<jwt>","__version":"0"}
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return str(parsed.get("value", raw))
        except (json.JSONDecodeError, AttributeError):
            pass
        return raw.strip('"')

    # ------------------------------------------------------------------
    # HTTP client lifecycle
    # ------------------------------------------------------------------

    async def _get_http(self) -> AsyncSession:
        if self._http is None:
            # impersonate="chrome" replicates Chromium's exact TLS fingerprint
            # (cipher suites, extensions, ALPN, HTTP/2 SETTINGS frame).
            # This is what WAF checks — raw httpx/OpenSSL mismatches the Chrome UA.
            self._http = AsyncSession(impersonate="chrome", timeout=120)
        return self._http

    async def close(self) -> None:
        if self._http is not None:
            await self._http.close()
            self._http = None

    # ------------------------------------------------------------------
    # PoW solving
    # ------------------------------------------------------------------

    def _solve_pow(self, challenge: dict[str, Any]) -> int:
        """Solve PoW challenge via Go binary. Blocking — call from thread."""
        if not SOLVER_PATH.exists():
            raise DeepSeekAPIError(f"Go solver not found at {SOLVER_PATH}")
        result = subprocess.run(
            [str(SOLVER_PATH)],
            input=json.dumps(challenge),
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            raise DeepSeekAPIError(f"PoW solver failed: {result.stderr.strip()}")
        nonce = int(result.stdout.strip())
        return nonce

    def _build_pow_header(self, challenge: dict[str, Any], nonce: int) -> str:
        """Build base64-encoded X-DS-PoW-Response header value."""
        payload = {
            "algorithm": challenge["algorithm"],
            "challenge": challenge["challenge"],
            "salt": challenge["salt"],
            "answer": nonce,
            "signature": challenge["signature"],
            "target_path": challenge["target_path"],
        }
        return base64.b64encode(
            json.dumps(payload, separators=(",", ":")).encode()
        ).decode()

    # ------------------------------------------------------------------
    # API calls
    # ------------------------------------------------------------------

    async def _get_challenge(self, headers: dict[str, str] | None = None) -> dict[str, Any]:
        """Request a fresh PoW challenge. Auto-refreshes token from browser on 401.

        Pass explicit `headers` (rotation mode) to use a specific pooled token — on
        401 this raises instead of triggering a browser refresh (rotation tokens are
        pre-collected JWTs; a dead one is skipped by the caller, not refreshed).
        """
        http = await self._get_http()
        explicit = headers is not None
        hdrs = headers if explicit else self._auth_headers()

        # No token at all — try browser refresh before anything else (non-rotation only)
        if not explicit and not self.token:
            await self._refresh_token()
            hdrs = self._auth_headers()

        resp = await http.post(
            f"{BASE_URL}/api/v0/chat/create_pow_challenge",
            json={"target_path": "/api/v0/chat/completion"},
            headers=hdrs,
        )
        if resp.status_code == 401:
            if explicit:
                raise DeepSeekAPIError("401 on challenge with rotation token")
            # Token expired — auto-refresh from persistent browser profile
            logger.warning("401 on challenge — refreshing token...")
            await self._refresh_token()
            resp = await http.post(
                f"{BASE_URL}/api/v0/chat/create_pow_challenge",
                json={"target_path": "/api/v0/chat/completion"},
                headers=self._auth_headers(),
            )
            if resp.status_code == 401:
                raise DeepSeekAPIError("Token still invalid after browser refresh. Log in to chat.deepseek.com.")
        resp.raise_for_status()
        data = resp.json()
        if not isinstance(data, dict) or data.get("code") != 0:
            msg = data.get("msg", "unknown") if isinstance(data, dict) else "unknown"
            raise DeepSeekAPIError(f"Challenge failed: {msg}")
        inner = data.get("data")
        biz = inner.get("biz_data") if isinstance(inner, dict) else None
        challenge = biz.get("challenge") if isinstance(biz, dict) else None
        if not challenge:
            raise DeepSeekAPIError(f"Challenge response missing challenge field (data={inner})")
        return challenge

    async def _create_session(self, headers: dict[str, str] | None = None) -> str:
        """Create a new chat session, return its UUID. Auto-refreshes token on 401.

        Pass explicit `headers` (rotation mode) to use a specific pooled token — on
        401 this raises instead of triggering a browser refresh.
        """
        http = await self._get_http()
        explicit = headers is not None
        hdrs = headers if explicit else self._auth_headers()
        resp = await http.post(
            f"{BASE_URL}/api/v0/chat_session/create",
            json={},
            headers=hdrs,
        )
        if resp.status_code == 401:
            if explicit:
                raise DeepSeekAPIError("401 creating session with rotation token")
            logger.warning("401 on session create — refreshing token...")
            await self._refresh_token()
            resp = await http.post(
                f"{BASE_URL}/api/v0/chat_session/create",
                json={},
                headers=self._auth_headers(),
            )
            if resp.status_code == 401:
                raise DeepSeekAPIError("Token still invalid after refresh. Log in to chat.deepseek.com.")
        resp.raise_for_status()
        data = resp.json()
        # DeepSeek sometimes returns 200 with data=null for muted/rate-limited accounts
        inner = data.get("data") if isinstance(data, dict) else None
        biz = inner.get("biz_data") if isinstance(inner, dict) else None
        if not biz:
            msg = data.get("msg", "unknown") if isinstance(data, dict) else "unknown"
            code = data.get("code", "?") if isinstance(data, dict) else "?"
            raise DeepSeekAPIError(f"Session create returned no biz_data (code={code}, msg={msg})")
        # Response shape: biz_data.chat_session.id (or legacy biz_data.id)
        chat_session = biz.get("chat_session")
        if isinstance(chat_session, dict) and "id" in chat_session:
            return chat_session["id"]
        session_id = biz.get("id")
        if not session_id:
            raise DeepSeekAPIError(f"Session create response missing id: {biz}")
        return session_id

    # ------------------------------------------------------------------
    # Client-side session history (mirrors Gemini/Mistral pattern)
    # ------------------------------------------------------------------

    async def _maybe_summarize(
        self, chat_id: str, history: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Check thresholds and summarize if needed. Returns updated history."""
        if not _ENABLE_SELF_SUMMARIZE:
            return history
        prefix_len = 1 if history and history[0].get("role") == "system" else 0
        total_chars = sum(_msg_chars(m) for m in history[prefix_len:])
        if should_force_summarize(total_chars, self._max_session_chars):
            cut_idx = compute_force_cut_index(history, prefix_len)
            msgs_to_summarize = history[prefix_len:cut_idx]
            if len(msgs_to_summarize) >= 2:
                prompt = build_summary_prompt(msgs_to_summarize, _msg_chars)
                summary = await self._call_self_summarize(prompt)
                if summary:
                    logger.info("Force-summarized %d messages for chat %s", len(msgs_to_summarize), chat_id)
                    history = rewrite_history_with_summary(history, summary, cut_idx, prefix_len, fmt="openai")
                    self._sessions[chat_id] = history
        return history

    async def _call_self_summarize(self, prompt: str) -> str | None:
        """Call the same DeepSeek model to generate a summary. Non-streaming."""
        if not _ENABLE_SELF_SUMMARIZE:
            return None
        # Use a simple non-streaming call via the same API
        prepared = await self._prepare_request_with_rotation()
        if prepared is None:
            return None
        session_id, headers = prepared
        body = {
            "chat_session_id": session_id,
            "parent_message_id": None,
            "model_type": None,  # ponytail: DeepSeek unified — always null
            "prompt": prompt,
            "ref_file_ids": [],
            "thinking_enabled": False,
            "search_enabled": True,
            "action": None,
            "preempt": False,
        }
        _log_raw("USER_MESSAGE [summarize]", prompt)
        try:
            http = await self._get_http()
            full_answer = ""
            async with http.stream(
                "POST", f"{BASE_URL}/api/v0/chat/completion", json=body, headers=headers,
            ) as resp:
                if resp.status_code != 200:
                    return None
                async for event in self._iter_completion_events(resp):
                    if event.get("type") == "answer":
                        full_answer += event.get("text", "")
            _log_raw("RESPONSE [summarize] (raw)", full_answer)
            result = strip_summarize_tag(full_answer).strip()
            return result if result else None
        except Exception as e:
            logger.warning("DeepSeek summarizer error: %s", e)
            return None

    async def _build_switch_prompt(
        self, history: list[dict[str, Any]], current_message: str,
    ) -> str:
        """Build a fresh-chat seed prompt for an account/token switch (Hermes pattern).

        Mirrors Qwen's `_build_switch_context`: keep the head (system + first user
        turns) and the tail verbatim, compress the middle via the same model, then
        end with a `continue` cue. This lets a brand-new DeepSeek chat resume the
        conversation without shipping the entire raw transcript.
        """
        prefix_len = 1 if history and history[0].get("role") == "system" else 0
        body = history[prefix_len:]
        total_chars = sum(_msg_chars(m) for m in body)

        # Small enough — plain serialization is fine and cheaper.
        if total_chars <= _SWITCH_SUMMARIZE_MIN:
            return self._serialize_history(history, current_message)

        head, tail, middle = _split_head_tail(body)

        middle_text = "\n".join(
            f"[{m.get('role', 'user')}]: {m.get('content', '')}" for m in middle
        )

        flow = ""
        if middle_text.strip():
            try:
                summary = await self._call_self_summarize(
                    build_summary_prompt(middle, _msg_chars)
                )
                flow = summary or middle_text
            except Exception as exc:
                logger.warning("DeepSeek switch summarizer failed (%s) — using raw middle", exc)
                flow = middle_text

        parts: list[str] = []
        if prefix_len:
            parts.append(f"[System Instructions]\n{history[0].get('content', '')}")
        if head:
            parts.append(head)
        if flow.strip():
            parts.append(f"## Conversation Flow\n{flow}")
        if tail:
            parts.append(tail)
        parts.append("continue")
        _reminder = self._get_reminder()
        if _reminder:
            current_message = f"{_reminder}\n\n{current_message}"
        parts.append(f"User: {current_message}")
        return "\n\n".join(parts)

    def _get_or_create_session(
        self, chat_id: str | None, inject_instructions: bool,
        system_instruction: str | None = None,
        project_id: str | None = None,
        layout_mode: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get existing session history or create a new one (sliding window)."""
        if chat_id and chat_id in self._sessions:
            history = self._sessions[chat_id]
            prefix_len = 1 if history and history[0].get("role") == "system" else 0
            total_chars = sum(_msg_chars(m) for m in history[prefix_len:])
            if total_chars > self._max_session_chars:
                self._sessions[chat_id] = _trim_history(history, prefix_len, self._max_session_chars)
            return self._sessions[chat_id]

        history: list[dict[str, Any]] = []
        instructions = system_instruction if system_instruction else (_load_instructions(project_id=project_id, layout_mode=layout_mode) if inject_instructions else None)
        if instructions:
            history.append({"role": "system", "content": instructions})

        if chat_id:
            self._sessions[chat_id] = history
        return history

    # Tool-calling format reminder — prepended to EVERY user message (chained,
    # full-context, and rotation paths). Built dynamically from the active
    # tool_call_format setting so it always matches what the system prompt says.
    @classmethod
    def _get_reminder(cls) -> str:
        """Build a compact reminder showing the current tool call format.

        Uses placeholder tag names / non-parseable JSON so Sable's own
        response parser never fires on these examples.
        """
        fmt = get_tool_format("deepseek")
        if not fmt:
            return ""

        # Detect which format is active by checking for signature strings
        if "Hermes XML" in fmt or "invoke name" in fmt:
            # Hermes XML format
            _tc_o = "<" + "tool_call" + ">"
            _tc_c = "</" + "tool_call" + ">"
            return (
                "[reminder] Tool calling structure:\n"
                + _tc_o + "\n"
                + '<invoke name="TOOL_NAME">\n'
                + '<parameter name="arg">value</parameter>\n'
                + "</invoke>\n"
                + _tc_c + "\n"
                + "[user message]"
            )
        elif "DSML" in fmt or "|DSML|" in fmt:
            # DSML format
            return (
                "[reminder] Tool calling structure:\n"
                + "<|DSML|tool_calls>\n"
                + '  <|DSML|invoke name="TOOL_NAME">\n'
                + '    <|DSML|parameter name="arg" string="true">value</|DSML|parameter>\n'
                + "  </|DSML|invoke>\n"
                + "</|DSML|tool_calls>\n"
                + "[user message]"
            )
        elif "Native" in fmt or "[] wrapper" in fmt:
            # Native bracket format
            return (
                "[reminder] Tool calling structure:\n"
                + '[{"name": "TOOL_NAME", "arguments": {ARGS}}]\n'
                + "[user message]"
            )
        elif "None" in fmt or "native API" in fmt:
            return ""
        else:
            # Default: Qwen JSON (action tags)
            _ao = "<" + "action" + ">"
            _ac = "</" + "action" + ">"
            return (
                "[reminder] Tool calling structure:\n"
                + _ao + '[{"name": "TOOL_NAME", "arguments": {ARGS}}]' + _ac + "\n"
                + _ao + '[{"name": "TOOL_A", "arguments": {}}, {"name": "TOOL_B", "arguments": {}}]' + _ac + "\n"
                + "[user message]"
            )

    @classmethod
    def _serialize_history(cls, history: list[dict[str, Any]], current_message: str) -> str:
        """Serialize client-side history + current message into a single prompt string.

        The tool-call format reminder is prepended to EVERY user message
        (both historical and current) so DeepSeek always sees the correct
        format immediately before each user turn.
        """
        reminder = cls._get_reminder()
        parts: list[str] = []
        for msg in history:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                parts.append(f"[System Instructions]\n{content}")
            elif role == "user":
                if reminder:
                    parts.append(f"User: {reminder}\n{content}")
                else:
                    parts.append(f"User: {content}")
            elif role == "assistant":
                parts.append(f"Assistant: {content}")
        # Prepend reminder to the current (last) user message as well
        if reminder:
            warned_message = f"{reminder}\n{current_message}"
        else:
            warned_message = current_message
        parts.append(f"User: {warned_message}")
        return "\n\n".join(parts)

    # ------------------------------------------------------------------
    # SSE response parsing
    # ------------------------------------------------------------------

    async def _iter_completion_events(
        self,
        resp,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Parse an open /chat/completion SSE stream into Sable events.

        Extracts message_id from response events for server-side chaining.
        """
        current_frag_type: str = "RESPONSE"
        last_message_id: int | None = None  # Track assistant message ID from stream

        async for raw_line in resp.aiter_lines():
            # curl_cffi yields bytes; httpx yielded str. Normalize.
            line = raw_line.decode("utf-8", errors="replace") if isinstance(raw_line, bytes) else raw_line
            if not line.startswith("data: "):
                continue
            payload = line[6:]
            if payload == "[DONE]":
                break
            try:
                obj = json.loads(payload)
            except json.JSONDecodeError:
                continue

            # Check for business-layer errors (muted account, etc.)
            # DeepSeek returns HTTP 200 with biz_code for account-level issues
            biz_code = obj.get("biz_code")
            if biz_code is not None and biz_code != 0:
                biz_msg = obj.get("biz_msg", "unknown")
                mute_until = None
                biz_data = obj.get("biz_data")
                if isinstance(biz_data, dict):
                    mute_until = biz_data.get("mute_until")
                logger.warning("DeepSeek biz_code=%s: %s (mute_until=%s)", biz_code, biz_msg, mute_until)
                yield {
                    "type": "biz_error",
                    "biz_code": biz_code,
                    "biz_msg": biz_msg,
                    "mute_until": mute_until,
                }
                return  # Stop parsing — stream is dead

            # Extract response_message_id from initial handshake event
            # Format: {"request_message_id":1,"response_message_id":2,"model_type":"default"}
            if "response_message_id" in obj:
                rid = obj["response_message_id"]
                if isinstance(rid, int):
                    last_message_id = rid

            v = obj.get("v")
            p = obj.get("p")
            o = obj.get("o")

            if v is None and p is None:
                continue
            if p == "response" and o == "BATCH":
                # BATCH events contain token usage / status, not message IDs
                continue
            if p == "response/status" and o == "SET":
                if v == "FINISHED":
                    yield {"type": "done", "parent_id": last_message_id}
                continue
            if p and "elapsed_secs" in p:
                continue
            if p == "response/fragments" and o == "APPEND":
                if isinstance(v, list) and v:
                    new_type = v[0].get("type", "RESPONSE")
                    current_frag_type = new_type
                    content = v[0].get("content", "")
                    if content:
                        etype = "thinking" if new_type == "THINK" else "answer"
                        yield {"type": etype, "text": content}
                continue
            if p == "response/fragments/-1/content":
                # Handle both o="APPEND" and o=None — DeepSeek sometimes sends
                # content continuation events without the APPEND operation tag.
                # Without this, fragments like 'tool' in '<tool_call>' get dropped,
                # producing broken tags like '<tool_call>'.
                text = v if isinstance(v, str) else ""
                if text:
                    etype = "thinking" if current_frag_type == "THINK" else "answer"
                    yield {"type": etype, "text": text}
                continue
            if isinstance(v, dict) and "response" in v:
                # Extract message_id from response metadata
                resp_data = v["response"]
                if resp_data.get("message_id"):
                    last_message_id = resp_data["message_id"]
                fragments = resp_data.get("fragments", [])
                for frag in fragments:
                    ftype = frag.get("type", "RESPONSE")
                    current_frag_type = ftype
                    content = frag.get("content", "")
                    if content:
                        etype = "thinking" if ftype == "THINK" else "answer"
                        yield {"type": etype, "text": content}
                continue
            if isinstance(v, str) and p is None:
                etype = "thinking" if current_frag_type == "THINK" else "answer"
                yield {"type": etype, "text": v}
                continue

    # ------------------------------------------------------------------
    # Public interface — streaming
    # ------------------------------------------------------------------

    async def stream_chat(
        self,
        message: str,
        model: str | None = None,
        thinking_mode: str | None = None,
        chat_id: str | None = None,
        ref_file_ids: list[str] | None = None,
        inject_instructions: bool = True,
        system_instruction: str | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Stream a chat completion. Yields Sable-compatible event dicts.

        Uses server-side message chaining via parent_message_id (like Qwen).
        Only the current user message is sent as prompt; DeepSeek chains context
        server-side using the parent_message_id from the previous response.
        Falls back to full-context serialization when parent is unknown (fresh
        session, token rotation, summarization, or first message).
        """
        thinking_enabled = str(thinking_mode or "").lower() in ("thinking", "deepthink")
        file_ids = [str(fid) for fid in (ref_file_ids or []) if str(fid).strip()]
        project_id = kwargs.pop("project_id", None)
        db_history = kwargs.pop("db_history", None)
        layout_mode = kwargs.pop("layout_mode", None)

        # Build client-side history (instructions as first entry, sliding window)
        history = self._get_or_create_session(chat_id, inject_instructions, system_instruction=system_instruction, project_id=project_id, layout_mode=layout_mode)
        # Browser sends "default" for first message in session, null for subsequent
        model_type = "default" if len(history) <= 1 else None
        # Seed from DB when session is fresh (cross-provider switch)
        if db_history and chat_id and len(history) <= 1:
            for _m in db_history:
                history.append({"role": _m["role"], "content": _m["content"]})

        # Context summarization: check thresholds before sending
        # If summarization fires, we lose the parent chain — must send full context
        _summarized_this_turn = False
        if chat_id:
            old_history_len = len(history)
            history = await self._maybe_summarize(chat_id, history)
            if len(history) != old_history_len:
                _summarized_this_turn = True
                # Summarization broke the parent chain — reset tracked parent
                self._parent_ids[chat_id] = None
            prefix_len = 1 if history and history[0].get("role") == "system" else 0
            total_chars = sum(_msg_chars(m) for m in history[prefix_len:])
            if _ENABLE_SELF_SUMMARIZE and should_inject_hint(total_chars, self._max_session_chars):
                hint = get_hint_text(total_chars, self._max_session_chars)
                message = message + hint

        # Determine whether to use chained mode or full-context fallback
        _parent_id = self._parent_ids.get(chat_id) if chat_id else None
        _is_first_message = len(history) <= 1  # Only system instruction (or empty)
        _use_chaining = (
            _parent_id is not None
            and not _summarized_this_turn
            and not _is_first_message
        )

        if _use_chaining:
            # Chained mode: send only the current message, DeepSeek uses parent
            _reminder = self._get_reminder()
            prompt = (
                f"{_reminder}\n\n{message}"
                if _reminder else message
            )
            logger.debug("DeepSeek chained mode: parent=%s, chat=%s", _parent_id, chat_id)
        else:
            # Full-context fallback: serialize entire history into prompt
            prompt = self._serialize_history(history, message)
            _parent_id = None  # Stateless when sending full context
            logger.debug("DeepSeek full-context mode: chat=%s, reason=%s",
                         chat_id, "first_msg" if _is_first_message else "no_parent" if not self._parent_ids.get(chat_id) else "summarized")

        # Ensure rotation pool is loaded before computing attempts
        # ponytail: ceiling=single-call init; upgrade path=move to __init__ if needed elsewhere
        if not self._rotate_tokens:
            self._init_rotation()

        # Try each token with round-robin rotation + per-token retry + failover
        # When auto-rotate is disabled, only try the current token (no failover)
        if not _auto_rotate_enabled("deepseek"):
            attempts = 1
        else:
            attempts = max(1, len(self._rotate_tokens))
        last_err = self._last_prepare_error or "unknown"
        _MAX_RETRIES_PER_TOKEN = 8
        _RETRY_DELAY_SECS = 5.0
        # Per-token failure reasons — kept so the final error reports EACH token
        # instead of only the last one (which made debugging rotation a nightmare).
        token_errors: list[str] = []

        def _all_failed_message() -> str:
            if not token_errors:
                return f"All DeepSeek tokens failed ({last_err})."
            lines = "\n".join(f"  • {e}" for e in token_errors)
            return f"All {len(token_errors)} DeepSeek token(s) failed:\n{lines}"

        # Anti-burst jitter: ONE gap per send (each tool-call round / user turn),
        # never per retry or token rotation. Retries use _RETRY_DELAY_SECS below.
        # Every tool call + its output is a fresh user message upstream, so this
        # spacing is what keeps the burst from tripping DeepSeek's WAF.
        try:
            from connectors.common.jitter import jitter_for as _jitter_for, sleep_jitter as _sleep_jitter
            _jdelay = _jitter_for("deepseek")
            if _jdelay:
                # Emit status BEFORE sleeping so the UI card updates first
                yield {"type": "status", "message": f"deepseek_delay_{_jdelay:.1f}s"}
                await _sleep_jitter(_jdelay)
        except Exception as _jexc:
            logger.debug("DeepSeek jitter skipped: %s", _jexc)

        for _attempt in range(attempts):
            # On rotation (attempt > 0) the previously selected token failed.
            # Drop its cached session so _prepare_request_with_rotation spins up
            # a BRAND-NEW chat_session — the old one belongs to the dead token
            # and any parent chain into it is meaningless.
            if _attempt > 0:
                _tok = self._current_rotate_token
                if _tok:
                    self._rotate_sessions.pop(_tok, None)
                    logger.info("DeepSeek rotation #%d: forcing fresh session for token %s",
                                _attempt, self._mask_token(_tok))

            prepared = await self._prepare_request_with_rotation()
            if prepared is None:
                yield {"type": "error", "message": _all_failed_message()}
                return
            session_id, headers = prepared

            # On rotation (attempt > 0), send a Hermes-style seed prompt (head +
            # summarized middle + tail + 'continue') instead of the raw transcript,
            # so the fresh chat resumes context without a context bomb.
            current_parent_id = _parent_id
            current_prompt = prompt
            if _attempt > 0:
                current_parent_id = None
                try:
                    current_prompt = await self._build_switch_prompt(history, message)
                except Exception as _seed_exc:
                    logger.warning("DeepSeek rotation #%d: switch-prompt build failed (%s), using raw serialize",
                                   _attempt, _seed_exc)
                    current_prompt = self._serialize_history(history, message)
                logger.info("DeepSeek rotation #%d: rebuilt seed prompt (%d chars)",
                            _attempt, len(current_prompt))

            body = {
                "chat_session_id": session_id,
                "parent_message_id": current_parent_id,
                "model_type": model_type,
                "prompt": current_prompt,
                "ref_file_ids": file_ids,
                "thinking_enabled": thinking_enabled,
                "search_enabled": True,
                "action": None,
                "preempt": False,
            }

            _log_raw("USER_MESSAGE (prompt sent)", current_prompt)

            # Per-token retry loop: retry same token before rotating
            for _retry in range(_MAX_RETRIES_PER_TOKEN):
                try:
                    http = await self._get_http()
                    full_answer = ""
                    full_thinking = ""

                    async with http.stream(
                        "POST", f"{BASE_URL}/api/v0/chat/completion", json=body, headers=headers,
                    ) as resp:
                        # Auth/rate-limit errors → no retry, rotate immediately
                        if resp.status_code in (401, 403, 429):
                            await resp.content
                            last_err = f"HTTP {resp.status_code}"
                            logger.warning("DeepSeek auth error (%s), rotating immediately...", last_err)
                            break  # Break retry loop → rotate to next token

                        if resp.status_code != 200:
                            error_body = await resp.content
                            last_err = f"HTTP {resp.status_code}: {error_body.decode(errors='replace')[:200]}"
                            logger.warning("DeepSeek HTTP error (%s), rotating immediately...", last_err)
                            break  # Break retry loop → rotate to next token

                        _response_parent_id: int | None = None
                        _got_biz_error = False
                        async for event in self._iter_completion_events(resp):
                            etype = event.get("type")
                            if etype == "answer":
                                full_answer += event.get("text", "")
                            elif etype == "thinking":
                                full_thinking += event.get("text", "")
                            elif etype == "done":
                                _response_parent_id = event.get("parent_id")
                            elif etype == "biz_error":
                                _got_biz_error = True
                                last_err = f"biz_code:{event.get('biz_code')} ({event.get('biz_msg', 'unknown')})"
                                logger.warning("DeepSeek biz_error: %s", last_err)
                                break  # Break SSE parsing
                            yield event

                        if _got_biz_error:
                            break  # Break retry loop → rotate to next token

                    _log_raw("RESPONSE (raw)", (full_thinking + "\n---\n" + full_answer) if full_thinking else full_answer)

                    # Empty response detection: HTTP 200 but zero content
                    if not full_answer and not full_thinking:
                        last_err = "empty_response"
                        if _retry < _MAX_RETRIES_PER_TOKEN - 1:
                            logger.warning("DeepSeek empty response, retry %d/%d in %.0fs...",
                                           _retry + 1, _MAX_RETRIES_PER_TOKEN, _RETRY_DELAY_SECS)
                            yield {"type": "status", "message": f"deepseek_retry_{_retry + 1}"}
                            await asyncio.sleep(_RETRY_DELAY_SECS)
                            continue  # Retry same token
                        else:
                            logger.warning("DeepSeek empty response after %d retries, rotating...",
                                           _MAX_RETRIES_PER_TOKEN)
                            break  # Break retry loop → rotate to next token

                    # Success — save user message + assistant response to history
                    _summarize_idx = extract_summarize_tag(full_answer)
                    clean_answer = strip_summarize_tag(full_answer)
                    history.append({"role": "user", "content": message})
                    response_content = full_thinking + clean_answer if full_thinking else clean_answer
                    if response_content:
                        history.append({"role": "assistant", "content": response_content})

                    # Store the assistant message ID for next-turn chaining
                    if chat_id and _response_parent_id:
                        self._parent_ids[chat_id] = _response_parent_id
                    elif chat_id and not _response_parent_id:
                        self._parent_ids[chat_id] = None
                        logger.warning("DeepSeek: no message_id in response for chat %s, chain reset", chat_id)

                    # Handle model-triggered summarization
                    if _summarize_idx is not None and chat_id:
                        prefix_len = 1 if history and history[0].get("role") == "system" else 0
                        actual_cut = max(prefix_len, min(_summarize_idx, len(history) - 1))
                        msgs_to_summarize = history[prefix_len:actual_cut]
                        if len(msgs_to_summarize) >= 2:
                            sum_prompt = build_summary_prompt(msgs_to_summarize, _msg_chars)
                            summary = await self._call_self_summarize(sum_prompt)
                            if summary:
                                logger.info("Model-triggered summarization at index %d for chat %s", _summarize_idx, chat_id)
                                history = rewrite_history_with_summary(history, summary, actual_cut, prefix_len, fmt="openai")
                                self._sessions[chat_id] = history
                                self._parent_ids[chat_id] = None

                    if chat_id:
                        prefix_len = 1 if history and history[0].get("role") == "system" else 0
                        total_chars = sum(_msg_chars(m) for m in history[prefix_len:])
                        if total_chars > self._max_session_chars:
                            self._sessions[chat_id] = _trim_history(history, prefix_len, self._max_session_chars)

                    return  # Success — done

                except CurlReadTimeout:
                    last_err = "timeout (120s)"
                    if _retry < _MAX_RETRIES_PER_TOKEN - 1:
                        logger.warning("DeepSeek timeout, retry %d/%d in %.0fs...",
                                       _retry + 1, _MAX_RETRIES_PER_TOKEN, _RETRY_DELAY_SECS)
                        yield {"type": "status", "message": f"deepseek_retry_{_retry + 1}"}
                        await asyncio.sleep(_RETRY_DELAY_SECS)
                        continue  # Retry same token
                    else:
                        logger.warning("DeepSeek timeout after %d retries, rotating...",
                                       _MAX_RETRIES_PER_TOKEN)
                        break  # Break retry loop → rotate to next token
                except Exception as exc:
                    last_err = f"{type(exc).__name__}: {exc}"
                    if _retry < _MAX_RETRIES_PER_TOKEN - 1:
                        logger.warning("DeepSeek error (%s), retry %d/%d in %.0fs...",
                                       last_err, _retry + 1, _MAX_RETRIES_PER_TOKEN, _RETRY_DELAY_SECS)
                        yield {"type": "status", "message": f"deepseek_retry_{_retry + 1}"}
                        await asyncio.sleep(_RETRY_DELAY_SECS)
                        continue  # Retry same token
                    else:
                        logger.warning("DeepSeek error after %d retries (%s), rotating...",
                                       _MAX_RETRIES_PER_TOKEN, last_err)
                        break  # Break retry loop → rotate to next token

            # All retries exhausted for this token → record why, then rotate
            if chat_id:
                self._parent_ids[chat_id] = None
            _old_token = self._current_rotate_token
            token_errors.append(f"token {self._mask_token(_old_token)}: {last_err}")
            self._advance_rotation()
            _new_token = self._current_rotate_token
            logger.warning("DeepSeek rotated token: %s → %s (reason: %s)",
                           self._mask_token(_old_token), self._mask_token(_new_token), last_err)
            yield {
                "type": "token_rotation",
                "reason": last_err,
                "from_token": self._mask_token(_old_token),
                "to_token": self._mask_token(_new_token),
                "from_index": (_attempt) % len(self._rotate_tokens) if self._rotate_tokens else 0,
                "to_index": self._rotate_idx,
                "total_tokens": len(self._rotate_tokens),
                # New account → new upstream chat. Context carries via the seed
                # prompt, not the old session's parent chain. Mirrors Qwen's
                # account_switch signal so the frontend can mark a new chat.
                "new_chat": True,
            }

        yield {"type": "error", "message": _all_failed_message()}

    # ------------------------------------------------------------------
    # Public interface — non-streaming
    # ------------------------------------------------------------------

    async def chat(
        self,
        message: str,
        model: str | None = None,
        thinking_mode: str | None = None,
        chat_id: str | None = None,
        ref_file_ids: list[str] | None = None,
        inject_instructions: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Non-streaming chat. Returns {answer, thinking, parent_id, error}."""
        answer_parts: list[str] = []
        thinking_parts: list[str] = []
        parent_id: str | None = None
        error: str | None = None

        async for event in self.stream_chat(
            message,
            model=model,
            thinking_mode=thinking_mode,
            chat_id=chat_id,
            ref_file_ids=ref_file_ids,
            inject_instructions=inject_instructions,
            **kwargs,
        ):
            etype = event.get("type")
            if etype == "answer":
                answer_parts.append(event.get("text", ""))
            elif etype == "thinking":
                thinking_parts.append(event.get("text", ""))
            elif etype == "done":
                parent_id = event.get("parent_id")
            elif etype == "error":
                error = event.get("message", "Unknown error")

        return {
            "answer": "".join(answer_parts),
            "thinking": "".join(thinking_parts),
            "parent_id": parent_id,
            "error": error,
        }


# Module-level client pool: account_name → DeepSeekClient
_clients: dict[str, DeepSeekClient] = {}
_default_client: DeepSeekClient | None = None


def get_client(account: str | None = None) -> DeepSeekClient:
    """Get or create a DeepSeek client for the given account.

    All clients now use automatic token rotation + client-side history (mirrors
    Gemini/Mistral pattern). No opt-in flag needed.

    account=None → default client (resolves active account dynamically).
    account="browser-data-acc7" → dedicated client pinned to that account.
    """
    if account is None:
        global _default_client
        if _default_client is None:
            _default_client = DeepSeekClient()
        return _default_client
    if account not in _clients:
        _clients[account] = DeepSeekClient(account=account)
    return _clients[account]
