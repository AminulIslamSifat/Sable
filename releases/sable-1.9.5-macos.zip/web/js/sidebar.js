        let _renderChatsToken = 0;
    async function renderChats() {
      const token = ++_renderChatsToken;
      chatsEl.innerHTML = '';
      chatsEl.classList.remove('has-project-banner');

      // Split chats: scraper (browser-*) vs API
      const q = chatSearchQuery.toLowerCase().trim();
      // If we have server-side search results, show those instead of title filtering
      if (q && chatSearchResults !== null) {
        chatsEl.innerHTML = '';
        // Group results by chat_id
        const byChat = new Map();
        for (const r of chatSearchResults) {
          if (!byChat.has(r.chat_id)) byChat.set(r.chat_id, { title: r.title, messages: [] });
          byChat.get(r.chat_id).messages.push(r);
        }
        for (const [chatId, group] of byChat) {
          const lbl = document.createElement('div');
          lbl.className = 'chat-group-label';
          lbl.textContent = group.title || 'Untitled';
          lbl.style.cursor = 'pointer';
          lbl.onclick = () => selectChat(chatId);
          chatsEl.appendChild(lbl);
          for (const msg of group.messages.slice(0, 5)) {
            const row = document.createElement('div');
            row.className = 'chat-row';
            const btn = document.createElement('button');
            btn.className = 'chat-item';
            const snippet = (msg.content || '').replace(/\n/g, ' ').slice(0, 120);
            btn.textContent = `${msg.role === 'user' ? '👤' : '🤖'} ${snippet}`;
            btn.title = msg.created_at || '';
            btn.onclick = () => selectChat(chatId);
            row.appendChild(btn);
            chatsEl.appendChild(row);
          }
        }
        if (byChat.size === 0) {
          const empty = document.createElement('div');
          empty.className = 'chat-group-label';
          empty.textContent = 'No matches found';
          chatsEl.appendChild(empty);
        }
        return;
      }
      // ── Project folder / banner at top of chat list ──
      await loadProjects();
      if (token !== _renderChatsToken) return; // stale call, newer render started
      // Show/hide project menu button based on active project
      const projectMenuBtn = document.getElementById('projectMenuBtn');
      if (projectMenuBtn) projectMenuBtn.style.display = activeProjectId ? '' : 'none';
      const projectFolderBtnEl = document.getElementById('projectFolderBtn');
      if (projectFolderBtnEl) projectFolderBtnEl.style.display = activeProjectId ? 'none' : '';

      if (activeProjectId) {
        const proj = projectList.find(p => p.id === activeProjectId);
        const banner = document.createElement('div');
        banner.className = 'project-banner';
        const nameSpan = document.createElement('span');
        nameSpan.className = 'project-name';
        nameSpan.textContent = proj ? proj.name : 'Project';
        banner.appendChild(nameSpan);
        chatsEl.classList.add('has-project-banner');
        chatsEl.appendChild(banner);
      }

      const filtered = q ? chatList.filter(c => (c.title || '').toLowerCase().includes(q)) : chatList;
      const allChats = filtered
        .sort((a, b) => {
          const pa = a.pinned ? 1 : 0;
          const pb = b.pinned ? 1 : 0;
          if (pa !== pb) return pb - pa; // pinned first
          return (b.updated_at || b.created_at || '').localeCompare(a.updated_at || a.created_at || '');
        });

      const __groupOf = (c) => {
        const raw = c.updated_at || c.created_at || c.last_message_at || null;
        if (!raw) return 'Chats';
        const d = new Date(typeof raw === 'number' ? (raw < 1e12 ? raw * 1000 : raw) : raw);
        if (isNaN(d.getTime())) return 'Chats';
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const yesterday = new Date(today.getTime() - 86400000);
        const ds = new Date(d.getFullYear(), d.getMonth(), d.getDate());
        if (ds >= today) return 'Today';
        if (ds >= yesterday) return 'Yesterday';
        return 'Earlier';
      };

      const renderChatRow = (chat, isScraper) => {
        const row = document.createElement("div");
        row.className = "chat-row";
        row.dataset.chatId = chat.id;
        const btn = document.createElement("button");
        btn.className = "chat-item" + (chat.id === activeChatId ? " active" : "");
        if (isScraper) {
          const icon = document.createElement("i");
          icon.setAttribute("data-lucide", "globe");
          icon.className = "icon-lucide chat-item-icon";
          btn.appendChild(icon);
        } else if (chat.mode === 'agent') {
          const icon = document.createElement("i");
          icon.setAttribute("data-lucide", "bot");
          icon.className = "icon-lucide chat-item-icon";
          btn.appendChild(icon);
        }
        const titleSpan = document.createElement("span");
        titleSpan.textContent = chat.title || "New chat";
        titleSpan.className = "chat-item-title";
        btn.appendChild(titleSpan);
        if (chat.pinned) {
          const pin = document.createElement("i");
          pin.setAttribute("data-lucide", "pin");
          pin.className = "icon-lucide chat-pin-icon";
          pin.title = "Pinned";
          btn.appendChild(pin);
        }
        // Show running indicator for agent chats that are actively streaming
        const _isRunning = activeStreams.has(chat.id) ||
          (typeof _activeAgentControllers !== "undefined" && _activeAgentControllers.has(chat.id));
        if (_isRunning) {
          row.classList.add("streaming");
          if (chat.mode === 'agent') {
            const dot = document.createElement("span");
            dot.className = "agent-running-dot";
            dot.title = "Agent running";
            btn.appendChild(dot);
          }
        }
        btn.onclick = () => selectChat(chat.id);
        const del = document.createElement("button");
        del.className = "chat-delete";
        del.textContent = "×";
        del.title = "Delete chat";
        del.onclick = (e) => { e.stopPropagation(); deleteChat(chat.id); };
        row.appendChild(btn);
        row.appendChild(del);
        row.addEventListener("contextmenu", (e) => {
          e.preventDefault();
          e.stopPropagation();
          openChatRowMenu(e.clientX, e.clientY, chat);
        });
        return row;
      };

      function openChatRowMenu(x, y, chat) {
        const menu = document.getElementById("chatRowMenu");
        if (!menu) return;
        menu.innerHTML = "";
        const addItem = (label, icon, danger, fn) => {
          const b = document.createElement("button");
          b.className = "ctx-item" + (danger ? " ctx-danger" : "");
          const ic = document.createElement("span");
          ic.className = "ctx-icon";
          ic.innerHTML = `<i data-lucide="${icon}" class="icon-lucide"></i>`;
          b.appendChild(ic);
          b.appendChild(document.createTextNode(label));
          b.onclick = () => { closeChatRowMenu(); fn(); };
          menu.appendChild(b);
        };
        addItem(chat.pinned ? "Unpin chat" : "Pin chat", "pin", false, () => togglePinChat(chat.id, !chat.pinned));
        const sep = document.createElement("div");
        sep.className = "ctx-sep";
        menu.appendChild(sep);
        addItem("Delete chat", "trash-2", true, () => deleteChat(chat.id));
        if (typeof lucide !== "undefined") lucide.createIcons();
        menu.style.left = Math.min(x, window.innerWidth - menu.offsetWidth - 12) + "px";
        menu.style.top = Math.min(y, window.innerHeight - menu.offsetHeight - 12) + "px";
        menu.classList.add("open");
      }

      function closeChatRowMenu() {
        const menu = document.getElementById("chatRowMenu");
        if (menu) menu.classList.remove("open");
      }

      document.addEventListener("click", closeChatRowMenu);
      document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeChatRowMenu(); });
      window.addEventListener("resize", closeChatRowMenu);
      window.addEventListener("scroll", closeChatRowMenu, true);

      async function togglePinChat(chatId, pinned) {
        const chat = chatList.find(c => c.id === chatId);
        const prev = chat ? !!chat.pinned : false;
        if (chat) chat.pinned = pinned ? 1 : 0;
        renderChats();
        try {
          const res = await fetch(`/api/chats/${chatId}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ pinned }),
          });
          if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || "Pin failed");
          showToast(pinned ? "Chat pinned" : "Chat unpinned", "success");
        } catch (err) {
          if (chat) chat.pinned = prev ? 1 : 0;
          renderChats();
          showToast("Pin failed: " + err.message, "error");
        }
      }
      window._sableTogglePinChat = togglePinChat;

      // All chats unified with date groups
      let __lastGroup = null;
      for (const chat of allChats) {
        const __g = __groupOf(chat);
        if (__g !== __lastGroup) {
          __lastGroup = __g;
          const lbl = document.createElement('div');
          lbl.className = 'chat-group-label';
          lbl.textContent = __g;
          chatsEl.appendChild(lbl);
        }
        const isScraper = chat.id.startsWith('browser-');
        chatsEl.appendChild(renderChatRow(chat, isScraper));
      }

      // Activate lucide icons for dynamically created elements
      if (typeof lucide !== 'undefined') lucide.createIcons();

      // Sync tab titles from chatList (backend auto-titles after first msg)
      for (const [id, tab] of openTabs) {
        const meta = chatList.find(c => c.id === id);
        if (meta && meta.title && meta.title !== tab.title) {
          tab.title = meta.title;
        }
      }
      renderTabBar();
    }

    function currentModelEntry() {
      return modelList.find(m => m.id === selectedModel) || modelList[0];
    }

    // Rebuilds the sidebar thinking-mode dropdown for whichever model is
    // currently selected — each model supports a different set of modes
    // (e.g. qwen3.8-max-preview only has "Thinking", qwen3.7-plus has
    // Fast/Auto/Thinking), so this runs on load and on every model change.
    function populateThinkingModes(preferredModeId) {
      const entry = currentModelEntry();
      const modes = (entry && entry.thinking_modes && entry.thinking_modes.length > 0)
        ? entry.thinking_modes
        : [{ id: "thinking", label: "Thinking" }];

      selectedThinkingMode = (preferredModeId && modes.some(m => m.id === preferredModeId))
        ? preferredModeId
        : modes[0].id;

      if (thinkingSwitcherEl) {
        thinkingSwitcherEl.innerHTML = "";
        thinkingSwitcherEl.style.setProperty('--n', modes.length);
        for (let idx = 0; idx < modes.length; idx++) {
          const m = modes[idx];
          const btn = document.createElement("button");
          btn.textContent = m.label || m.id;
          btn.dataset.modeId = m.id;
          if (m.id === selectedThinkingMode) {
            btn.classList.add('active');
            thinkingSwitcherEl.style.setProperty('--i', idx);
          }
          btn.addEventListener('click', () => {
            if (btn.classList.contains('active')) return;
            selectedThinkingMode = m.id;
            thinkingSwitcherEl.querySelectorAll('button').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            thinkingSwitcherEl.style.setProperty('--i', idx);
            try { localStorage.setItem(THINKING_MODE_KEY, selectedThinkingMode); } catch (err) {}
            if (typeof window._sableSaveChatModelSettings === "function") window._sableSaveChatModelSettings();
          });
          thinkingSwitcherEl.appendChild(btn);
        }

        // Only one available mode — hide the switcher entirely.
        thinkingSwitcherEl.style.display = modes.length <= 1 ? 'none' : '';
      }

      try { localStorage.setItem(THINKING_MODE_KEY, selectedThinkingMode); } catch (err) {}
      syncStatusBarThinking();
    }

