"""Qwen Engine Configuration — Endpoints, Models, and Default Constants."""

import logging
import os
from pathlib import Path

logger = logging.getLogger("sable")

# Project root (two levels up from this file: engine/config.py → engine/ → project root)
_ROOT = Path(__file__).resolve().parent.parent

# Persistent storage root — each project instance gets its own system/ folder.
# Override with SABLE_PERSISTENT_ROOT env var if you need a shared location.
_PERSISTENT_OVERRIDE = os.getenv("SABLE_PERSISTENT_ROOT")
PERSISTENT_ROOT = (
    Path(_PERSISTENT_OVERRIDE).resolve()
    if _PERSISTENT_OVERRIDE
    else _ROOT
)

# --------------------------------------------------------------------------
# Server bind settings — single source of truth for the FastAPI/uvicorn app.
# Override with SABLE_HOST / SABLE_PORT environment variables when needed.
# --------------------------------------------------------------------------
def _host_from_settings() -> str | None:
    """Bind host persisted from web settings (Network Access option)."""
    try:
        import json as _json
        p = _ROOT / "system" / "network_settings.json"
        host = _json.loads(p.read_text(encoding="utf-8")).get("host")
        return host if host in ("0.0.0.0", "127.0.0.1") else None
    except Exception:
        return None


# Env var wins > web settings > default (all interfaces)
HOST = os.getenv("SABLE_HOST") or _host_from_settings() or "0.0.0.0"
# User home directory — single source of truth for all ~ expansion
HOME_DIR = Path.home()

# Output directories — where generated content lands
# Lives outside project root so outputs survive tree wipes/rebuilds.
OUTPUT_ROOT = HOME_DIR / "sable_output"
RESEARCH_DIR = OUTPUT_ROOT / "research"
NOTES_DIR = OUTPUT_ROOT / "notes"
PROMPTS_DIR = OUTPUT_ROOT / "prompts"
AGENT_OUTPUT_DIR = OUTPUT_ROOT / "agent"
ASSETS_DIR = OUTPUT_ROOT / "assets"
LOGS_DIR = OUTPUT_ROOT / "logs"

# SSD vs HDD tree detection — used by security guards to prevent
# accidental writes to the live SSD deployment tree.
# Override with SABLE_SSD_TREE / SABLE_HDD_TREE env vars if needed.
SSD_TREE = os.getenv("SABLE_SSD_TREE", str(HOME_DIR / "Projects" / "Sable"))
HDD_TREE = os.getenv("SABLE_HDD_TREE", str(HOME_DIR / "hdd" / "projects" / "Sable"))

# Display name for the user (used in session personalization)
USER_NAME = os.getenv("SABLE_USER_NAME", "User")

# Port selection: prefer env var, otherwise detect HDD vs SSD instance
_DEFAULT_PORT = "61771" if HDD_TREE in str(_ROOT) else "61770"
PORT = int(os.getenv("PORT", os.getenv("SABLE_PORT", _DEFAULT_PORT)))

# --------------------------------------------------------------------------
# Runtime data paths — single source of truth used by server.py and any
# other module that needs these files.
# --------------------------------------------------------------------------
BRAIN_DIR = _ROOT / "Brain"
MEMORY_PATH = BRAIN_DIR / "Memory.json"
PROTECTED_PATH = BRAIN_DIR / "Protected.json"
PROCEDURAL_PATH = BRAIN_DIR / "Procedural.json"
PERSONALITY_PATH = BRAIN_DIR / "user_personality.json"
INSTRUCTION_DIR = _ROOT / "instruction"
PERSONAL_PATH = INSTRUCTION_DIR / "personal.md"
MEMORY_SEARCH_SETTINGS_PATH = _ROOT / "system/memory_search_settings.json"
AGENT_CONFIG_PATH = _ROOT / "system/agent_config.json"

# User-created skills (managed via memory consolidation)
SKILLS_JSON_PATH = BRAIN_DIR / "skills.json"

# Maximum prompt length (chars) before memory vectorization is skipped entirely.
# Prevents RAM spikes when huge messages are sent. Configurable via web settings.
MEMORY_SEARCH_MAX_PROMPT_CHARS = 20000

# Browser profile directories — single source of truth for all browser data paths.
# All profiles live under system/ to keep the project root clean.
_SYSTEM = _ROOT / "system"
_ACTIVE_ACCOUNT_FILE = _SYSTEM / ".active_account"


def get_active_account() -> str:
    """Get the active browser account name from the config file.

    When the file is empty or missing, auto-selects the best available account
    using priority: fresh (lowest number) > captcha-blocked (oldest) and persists
    the selection so subsequent calls are stable.
    """
    try:
        name = _ACTIVE_ACCOUNT_FILE.read_text(encoding="utf-8").strip()
        if name:
            return name
    except OSError:
        pass

    # Auto-select best available account instead of falling back to legacy name
    selected = get_next_available_account()
    if selected:
        set_active_account(selected)
        logger.info("Auto-selected active account: %s (was unset)", selected)
        return selected

    # No accounts exist at all — fall back to legacy name as last resort
    return "browser-data"


def set_active_account(name: str) -> None:
    """Persist the active browser account name to a config file."""
    try:
        _ACTIVE_ACCOUNT_FILE.write_text(name + "\n", encoding="utf-8")
    except OSError as exc:
        logger.warning("Failed to write active account file: %s", exc)


# ── Sync-fallback tracking ──────────────────────────────────────────────────
# When sync_context fails for an account, we persist the account name here so
# every subsequent chat on that account gets [SYSTEM INSTRUCTION] injected into
# the first message until sync_context succeeds again.
_SYNC_FAILED_FILE = _SYSTEM / ".sync_failed_accounts"


def mark_sync_failed(account: str) -> None:
    """Flag an account as needing instruction fallback injection."""
    try:
        existing = set()
        if _SYNC_FAILED_FILE.exists():
            existing = {l.strip() for l in _SYNC_FAILED_FILE.read_text(encoding="utf-8").splitlines() if l.strip()}
        if account not in existing:
            existing.add(account)
            _SYNC_FAILED_FILE.write_text("\n".join(existing) + "\n", encoding="utf-8")
            logger.info("Marked %s as sync-failed (instruction fallback enabled)", account)
    except OSError as exc:
        logger.warning("Failed to write sync-failed file: %s", exc)


def clear_sync_failed(account: str) -> None:
    """Remove sync-failed flag after a successful sync_context."""
    try:
        if not _SYNC_FAILED_FILE.exists():
            return
        lines = [l.strip() for l in _SYNC_FAILED_FILE.read_text(encoding="utf-8").splitlines() if l.strip() and l.strip() != account]
        if lines:
            _SYNC_FAILED_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
        else:
            _SYNC_FAILED_FILE.unlink(missing_ok=True)
        logger.info("Cleared sync-failed flag for %s", account)
    except OSError as exc:
        logger.warning("Failed to update sync-failed file: %s", exc)


def needs_instruction_fallback(account: str | None = None) -> bool:
    """Check if the given (or currently active) account needs instruction injection."""
    if account is None:
        account = get_active_account()
    try:
        if not _SYNC_FAILED_FILE.exists():
            return False
        return any(l.strip() == account for l in _SYNC_FAILED_FILE.read_text(encoding="utf-8").splitlines())
    except OSError:
        return False


def get_browser_data_dir() -> Path:
    """Return the browser data directory for the currently active account."""
    return _SYSTEM / get_active_account()


# Backward-compatible constant — resolves at import time.
# Code that needs the *current* active account should call get_browser_data_dir().
BROWSER_DATA_DIR = _SYSTEM / "browser-data"
BROWSER_SCRAPER_DATA_DIR = _SYSTEM / "browser-scraper-data"
BROWSER_AUTOMATION_DATA_DIR = _SYSTEM / "automation-browser-data"

URL = "https://chat.qwen.ai/api/v2/chat/completions"
NEW_CHAT_URL = "https://chat.qwen.ai/api/v2/chats/new"
STOP_URL = "https://chat.qwen.ai/api/v2/chat/completions/stop"

# Each model carries its own list of selectable "thinking modes" — some
# others support several (qwen3.7-max: Fast/Thinking, qwen3.7-plus:
# Fast/Auto/Thinking). Each thinking mode entry maps directly onto the
# feature_config fields the upstream API expects. Add/remove model or mode
# entries here to control what's selectable in the UI.
MODELS = [
    {
        "id": "qwen3.8-max",
        "label": "Qwen3.8 Max",
        "max_session_chars": 3_000_000,
        "capabilities": {"image": True, "video": False, "document": True, "audio": False},
        "thinking_modes": [
            {
                "id": "fast",
                "label": "Fast",
                "thinking_enabled": False,
                "auto_thinking": False,
                "thinking_mode": "Fast",
            },
            {
                "id": "auto",
                "label": "Auto",
                "thinking_enabled": True,
                "auto_thinking": True,
                "thinking_mode": "Auto",
            },
            {
                "id": "thinking",
                "label": "Thinking",
                "thinking_enabled": True,
                "auto_thinking": False,
                "thinking_mode": "Thinking",
            },
        ],
    },
    {
        "id": "qwen3.7-max",
        "label": "Qwen3.7 Max",
        "max_session_chars": 3_000_000,
        "capabilities": {"image": True, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {
                "id": "fast",
                "label": "Fast",
                "thinking_enabled": False,
                "auto_thinking": False,
                "thinking_mode": "Fast",
            },
            {
                "id": "thinking",
                "label": "Thinking",
                "thinking_enabled": True,
                "auto_thinking": False,
                "thinking_mode": "Thinking",
            },
        ],
    },
    {
        "id": "qwen3.7-plus",
        "label": "Qwen3.7 Plus",
        "max_session_chars": 3_000_000,
        "capabilities": {"image": True, "video": False, "document": True, "audio": False},
        "thinking_modes": [
            {
                "id": "fast",
                "label": "Fast",
                "thinking_enabled": False,
                "auto_thinking": False,
                "thinking_mode": "Fast",
            },
            {
                "id": "auto",
                "label": "Auto",
                "thinking_enabled": True,
                "auto_thinking": True,
                "thinking_mode": "Auto",
            },
            {
                "id": "thinking",
                "label": "Thinking",
                "thinking_enabled": True,
                "auto_thinking": False,
                "thinking_mode": "Thinking",
            },
        ],
    },
    {
        "id": "qwen3.8-omni-flash",
        "label": "Qwen3.8 Omni Flash",
        "max_session_chars": 3_000_000,
        "capabilities": {"image": True, "video": False, "document": True, "audio": False},
        "thinking_modes": [
            {
                "id": "fast",
                "label": "Fast",
                "thinking_enabled": False,
                "auto_thinking": False,
                "thinking_mode": "Fast",
            },
            {
                "id": "thinking",
                "label": "Thinking",
                "thinking_enabled": True,
                "auto_thinking": False,
                "thinking_mode": "Thinking",
            },
        ],
    },
    # ponytail: DeepSeek unified all modes into one model.
    # Vision auto-detected from ref_file_ids; expert mode removed upstream.
    {
        "id": "deepseek-instant",
        "label": "DeepSeek",
        "api_backend": "deepseek",
        "api_model_type": None,
        "max_session_chars": 4_000_000,
        "capabilities": {"image": True, "video": False, "document": True, "audio": False},
        "thinking_modes": [
            {
                "id": "fast",
                "label": "Fast",
                "thinking_enabled": False,
                "auto_thinking": False,
                "thinking_mode": "Fast",
            },
            {
                "id": "thinking",
                "label": "Thinking",
                "thinking_enabled": True,
                "auto_thinking": False,
                "thinking_mode": "Thinking",
            },
        ],
    },
    # ── z.ai (GLM) — browser-assisted backend ──
    {
        "id": "zai-glm-5.3-flash",
        "label": "GLM-5.3-Flash",
        "api_backend": "zai",
        "api_model_type": "x-preview-l",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": True, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "low", "label": "Low", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Low"},
            {"id": "high", "label": "High", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "High"},
            {"id": "max", "label": "Max", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Max"},
        ],
    },
    {
        "id": "zai-glm-5.3",
        "label": "GLM-5.3",
        "api_backend": "zai",
        "api_model_type": "glm-5.3",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": False, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "low", "label": "Low", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Low"},
            {"id": "high", "label": "High", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "High"},
            {"id": "max", "label": "Max", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Max"},
        ],
    },
    {
        "id": "zai-glm-5.2",
        "label": "GLM-5.2",
        "api_backend": "zai",
        "api_model_type": "glm-5.2",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": False, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "thinking", "label": "Thinking", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Thinking"},
        ],
    },
    {
        "id": "zai-glm-5-turbo",
        "label": "GLM-5-Turbo",
        "api_backend": "zai",
        "api_model_type": "GLM-5-Turbo",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": False, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "thinking", "label": "Thinking", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Thinking"},
        ],
    },
    {
        "id": "zai-glm-5v-turbo",
        "label": "GLM-5V-Turbo",
        "api_backend": "zai",
        "api_model_type": "GLM-5v-Turbo",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": True, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "thinking", "label": "Thinking", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Thinking"},
        ],
    },
    {
        "id": "zai-glm-4.7",
        "label": "GLM-4.7",
        "api_backend": "zai",
        "api_model_type": "glm-4.7",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": False, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "thinking", "label": "Thinking", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Thinking"},
        ],
    },
    {
        "id": "zai-glm-4.6v",
        "label": "GLM-4.6V",
        "api_backend": "zai",
        "api_model_type": "glm-4.6v",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": True, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "thinking", "label": "Thinking", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Thinking"},
        ],
    },
    {
        "id": "gemini-2.5-flash",
        "label": "Gemini 2.5 Flash",
        "api_backend": "gemini",
        "api_model_type": "gemini-2.5-flash",
        "capabilities": {"image": True, "video": False, "document": True, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "low", "label": "Low", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Low"},
            {"id": "medium", "label": "Medium", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Medium"},
            {"id": "high", "label": "High", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "High"},
        ],
    },
    {
        "id": "gemini-2.5-pro",
        "label": "Gemini 2.5 Pro",
        "api_backend": "gemini",
        "api_model_type": "gemini-2.5-pro",
        "capabilities": {"image": True, "video": False, "document": True, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "low", "label": "Low", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Low"},
            {"id": "medium", "label": "Medium", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Medium"},
            {"id": "high", "label": "High", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "High"},
        ],
    },
    # ── Gemini Web (browser-auth, no API key) ──
    {
        "id": "gemini-web",
        "label": "Gemini (Web)",
        "api_backend": "gemini_web",
        "api_model_type": "gemini-web",
        "max_session_chars": 4_000_000,
        "capabilities": {"image": False, "video": False, "document": False, "audio": False},
        "thinking_modes": [
            {"id": "fast", "label": "Fast", "thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"},
            {"id": "thinking", "label": "Thinking", "thinking_enabled": True, "auto_thinking": False, "thinking_mode": "Thinking"},
        ],
    },
]

# Default/current model id — kept for backward compatibility with code that
# imports MODEL directly (chat.py, session.py create_new_chat, etc.)
MODEL = MODELS[0]["id"]

# ---------------------------------------------------------------------------
# Dynamic model registry — user-added models from Providers UI
# ---------------------------------------------------------------------------
_CUSTOM_MODELS_PATH = _SYSTEM / ".custom_models.json"
_HIDDEN_MODELS_PATH = _SYSTEM / ".hidden_models.json"


def _load_hidden_models() -> list[str]:
    """Load list of hidden (user-deleted) static model IDs."""
    if not _HIDDEN_MODELS_PATH.exists():
        return []
    try:
        import json as _json
        data = _json.loads(_HIDDEN_MODELS_PATH.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except Exception:
        pass
    return []


def _save_hidden_models(ids: list[str]) -> None:
    """Persist hidden model IDs."""
    import json as _json
    _HIDDEN_MODELS_PATH.write_text(_json.dumps(ids, indent=2), encoding="utf-8")


def _load_custom_models() -> list[dict]:
    """Load user-added model definitions."""
    if not _CUSTOM_MODELS_PATH.exists():
        return []
    try:
        import json as _json
        data = _json.loads(_CUSTOM_MODELS_PATH.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except Exception:
        pass
    return []


def _save_custom_models(models: list[dict]) -> None:
    """Persist user-added model definitions."""
    import json as _json
    _CUSTOM_MODELS_PATH.write_text(_json.dumps(models, indent=2), encoding="utf-8")


def get_all_models() -> list[dict]:
    """Return static + custom models merged, excluding hidden/deleted ones."""
    hidden = set(_load_hidden_models())
    custom = _load_custom_models()
    custom_ids = {m["id"] for m in custom}
    # Static models: exclude hidden and custom-overridden
    merged = [m for m in MODELS if m["id"] not in custom_ids and m["id"] not in hidden]
    # Custom models: exclude hidden
    merged.extend(m for m in custom if m.get("id") not in hidden)
    return merged


def add_custom_model(model_def: dict) -> None:
    """Add or update a custom model definition."""
    customs = _load_custom_models()
    mid = model_def.get("id", "")
    # Replace if exists, else append
    customs = [m for m in customs if m.get("id") != mid]
    customs.append(model_def)
    _save_custom_models(customs)


def remove_custom_model(model_id: str) -> bool:
    """Remove a custom model. Returns True if removed."""
    customs = _load_custom_models()
    new = [m for m in customs if m.get("id") != model_id]
    if len(new) < len(customs):
        _save_custom_models(new)
        return True
    return False


def get_model_config(model_id: str | None = None) -> dict:
    """Return the model config dict for model_id, falling back to the default MODEL.

    Searches both static MODELS and user-added custom models.
    Falls back to the first entry rather than raising.
    """
    target = model_id or MODEL
    for entry in get_all_models():
        if entry["id"] == target:
            return entry
    return get_all_models()[0]


def get_thinking_mode_config(model_id: str | None = None, thinking_mode_id: str | None = None) -> dict:
    """Return the selected thinking-mode config for a model.

    Falls back to that model's first (default) thinking mode if
    thinking_mode_id is missing or not supported by the model — e.g. the
    client requests "auto" on qwen3.7-max, which doesn't have that mode.

    Always returns a dict with safe defaults for all expected keys
    (auto_thinking, thinking_mode, thinking_enabled) so incomplete
    custom model configs never cause KeyError downstream.
    """
    _defaults = {"thinking_enabled": False, "auto_thinking": False, "thinking_mode": "Fast"}
    modes = get_model_config(model_id).get("thinking_modes", [{**_defaults, "id": "fast", "label": "Fast"}])
    selected = None
    if thinking_mode_id:
        for mode in modes:
            if mode["id"] == thinking_mode_id:
                selected = mode
                break
    if selected is None:
        selected = modes[0] if modes else {"id": "fast", "label": "Fast"}
    return {**_defaults, **selected}

# --------------------------------------------------------------------------
# Session tokens — loaded from .session_tokens.json (gitignored) so they
# are never committed to the repository.  Playwright auto-refresh is the
# real authentication mechanism; these are only used as the initial seed.
# --------------------------------------------------------------------------

def _load_session_tokens() -> dict:
    token_file = _ROOT / "system" / ".session_tokens.json"
    if token_file.exists():
        try:
            import json as _json
            return _json.loads(token_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}

_SESSION_TOKENS = _load_session_tokens()

COOKIES: str = _SESSION_TOKENS.get("COOKIES", "")
BX_UA: str = _SESSION_TOKENS.get("BX_UA", "")
BX_UMIDTOKEN: str = _SESSION_TOKENS.get("BX_UMIDTOKEN", "")


# --------------------------------------------------------------------------
# Per-account Qwen WAF token store (list-based — tokens accumulate).
# Format: {"browser-data-acc1": [{"cookies": "...", "bx_ua": "...", "bx_umidtoken": "..."}, ...]}
# Tokens don't expire, so we keep all of them and use the most recent.
# --------------------------------------------------------------------------

_QWEN_TOKENS_PATH = _SYSTEM / ".qwen_tokens.json"
_QWEN_MAX_TOKENS_PER_ACCOUNT = 10
_QWEN_LEGACY_MIGRATED = False  # guard so migration only runs once


def _resolve_active_account() -> str:
    """Get the active account name. Delegates to get_active_account()."""
    return get_active_account()


def load_qwen_token_store() -> dict[str, list[dict[str, str]]]:
    """Load per-account Qwen WAF token store.

    Returns {account: [{cookies, bx_ua, bx_umidtoken}, ...]}.
    Handles migration from old flat .session_tokens.json format (runs once only).
    """
    global _QWEN_LEGACY_MIGRATED
    import json as _json
    raw: dict = {}
    if _QWEN_TOKENS_PATH.exists():
        try:
            raw = _json.loads(_QWEN_TOKENS_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass

    store: dict[str, list[dict[str, str]]] = {}
    for key, val in raw.items():
        if isinstance(val, list):
            store[key] = [v for v in val if isinstance(v, dict) and v.get("cookies")]
        elif isinstance(val, dict) and val.get("cookies"):
            # Migrate old flat format → list
            store[key] = [val]
        else:
            store[key] = []

    # One-time migration from global .session_tokens.json (guarded)
    if not store and not _QWEN_LEGACY_MIGRATED and _SESSION_TOKENS.get("COOKIES"):
        _QWEN_LEGACY_MIGRATED = True
        account = _resolve_active_account()
        entry = {
            "cookies": _SESSION_TOKENS.get("COOKIES", ""),
            "bx_ua": _SESSION_TOKENS.get("BX_UA", ""),
            "bx_umidtoken": _SESSION_TOKENS.get("BX_UMIDTOKEN", ""),
        }
        store[account] = [entry]
        save_qwen_token_store(store)

    return store


def save_qwen_token_store(store: dict[str, list[dict[str, str]]]) -> None:
    """Persist the per-account Qwen WAF token store atomically (write-to-tmp + rename)."""
    import json as _json
    import tempfile
    import os as _os
    try:
        data = _json.dumps(store, indent=2)
        fd, tmp_path = tempfile.mkstemp(
            dir=str(_QWEN_TOKENS_PATH.parent), suffix=".tmp"
        )
        try:
            with _os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data)
            _os.replace(tmp_path, str(_QWEN_TOKENS_PATH))
        except BaseException:
            try:
                _os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except Exception:
        pass


def get_qwen_tokens_for_account(account: str | None = None) -> dict[str, str] | None:
    """Get the most recent Qwen WAF tokens for an account.

    Returns {cookies, bx_ua, bx_umidtoken} or None if nothing cached.
    """
    store = load_qwen_token_store()
    if not store:
        return None

    def _latest(entries: list[dict[str, str]]) -> dict[str, str] | None:
        valid = [e for e in entries if e.get("cookies")]
        return valid[-1] if valid else None

    # Explicit account: strict lookup only. No fallback.
    if account is not None:
        entries = store.get(account)
        if not entries:
            return None
        return _latest(entries)

    # No explicit account: fall back to active account only.
    active = _resolve_active_account()
    if active in store:
        tok = _latest(store[active])
        if tok:
            return tok
    return None


def save_qwen_tokens_for_account(
    cookies: str,
    bx_ua: str,
    bx_umidtoken: str,
    account: str | None = None,
) -> None:
    """Save Qwen WAF tokens for an account. Replaces any existing entry (1 per account)."""
    if not cookies:
        return
    acct = account or _resolve_active_account()
    store = load_qwen_token_store()
    store[acct] = [{"cookies": cookies, "bx_ua": bx_ua, "bx_umidtoken": bx_umidtoken}]
    save_qwen_token_store(store)



# --------------------------------------------------------------------------
# Qwen account exhaustion tracking (daily quota resets at UTC 00:00)
# --------------------------------------------------------------------------

_QWEN_EXHAUSTION_PATH = _SYSTEM / ".qwen_exhaustion.json"
_QWEN_CAPTCHA_BLOCK_PATH = _SYSTEM / ".qwen_captcha_blocks.json"


def _load_exhaustion_store() -> dict[str, dict]:
    import json as _json
    if _QWEN_EXHAUSTION_PATH.exists():
        try:
            return _json.loads(_QWEN_EXHAUSTION_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _save_exhaustion_store(store: dict[str, dict]) -> None:
    import json as _json
    import tempfile, os as _os
    try:
        data = _json.dumps(store, indent=2)
        fd, tmp = tempfile.mkstemp(dir=str(_QWEN_EXHAUSTION_PATH.parent), suffix=".tmp")
        try:
            with _os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data)
            _os.replace(tmp, str(_QWEN_EXHAUSTION_PATH))
        except BaseException:
            try:
                _os.unlink(tmp)
            except OSError:
                pass
            raise
    except Exception:
        pass


def mark_account_exhausted(account: str) -> None:
    """Mark an account as quota-exhausted with current UTC timestamp."""
    from datetime import datetime, timezone
    store = _load_exhaustion_store()
    store[account] = {
        "exhausted": True,
        "exhausted_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_exhaustion_store(store)
    logger.info("Account %s marked exhausted", account)


def is_account_exhausted(account: str) -> bool:
    """Check if account is exhausted. Auto-resets if exhausted_at is before today's UTC midnight
    plus a per-account jitter (0-60 min) to prevent thundering herd at reset boundary."""
    from datetime import datetime, timezone, timedelta
    store = _load_exhaustion_store()
    entry = store.get(account)
    if not entry or not entry.get("exhausted"):
        return False
    # Check if quota has reset (new UTC day + jitter)
    exhausted_at = entry.get("exhausted_at")
    if exhausted_at:
        try:
            dt = datetime.fromisoformat(exhausted_at)
            now = datetime.now(timezone.utc)
            # FIX #6: Per-account jitter (0-60 min) based on account name hash.
            # Prevents all accounts from resetting at exactly UTC midnight,
            # which causes concurrent requests to select the same freshly-reset account.
            _jitter_minutes = hash(account) % 60
            _reset_time = datetime.combine(now.date(), datetime.min.time(), tzinfo=timezone.utc) + timedelta(minutes=_jitter_minutes)
            if dt < _reset_time:
                store[account] = {"exhausted": False, "exhausted_at": None}
                _save_exhaustion_store(store)
                return False
        except (ValueError, TypeError):
            pass
    return True


def get_all_exhaustion_status() -> dict[str, bool]:
    """Return {account_name: is_exhausted} for all tracked accounts."""
    store = _load_exhaustion_store()
    result = {}
    for account in store:
        result[account] = is_account_exhausted(account)
    return result


def _load_captcha_block_store() -> dict[str, str]:
    """Load captcha block timestamps. Returns {account_name: iso_timestamp}."""
    import json as _json
    if _QWEN_CAPTCHA_BLOCK_PATH.exists():
        try:
            return _json.loads(_QWEN_CAPTCHA_BLOCK_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _save_captcha_block_store(store: dict[str, str]) -> None:
    """Atomically save captcha block timestamps."""
    import json as _json
    import tempfile, os as _os
    try:
        data = _json.dumps(store, indent=2)
        fd, tmp = tempfile.mkstemp(dir=str(_QWEN_CAPTCHA_BLOCK_PATH.parent), suffix=".tmp")
        try:
            with _os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data)
            _os.replace(tmp, str(_QWEN_CAPTCHA_BLOCK_PATH))
        except BaseException:
            try:
                _os.unlink(tmp)
            except OSError:
                pass
            raise
    except Exception:
        pass


def mark_account_captcha_blocked(account: str) -> None:
    """Mark an account as captcha-blocked with current UTC timestamp."""
    from datetime import datetime, timezone
    store = _load_captcha_block_store()
    store[account] = datetime.now(timezone.utc).isoformat()
    _save_captcha_block_store(store)
    logger.info("Account %s marked captcha-blocked", account)


def is_account_captcha_blocked(account: str) -> bool:
    """Check if account is captcha-blocked. Auto-clears if blocked before today's UTC midnight."""
    from datetime import datetime, timezone
    store = _load_captcha_block_store()
    ts = store.get(account)
    if not ts:
        return False
    try:
        dt = datetime.fromisoformat(ts)
        now = datetime.now(timezone.utc)
        if dt.date() < now.date():
            del store[account]
            _save_captcha_block_store(store)
            return False
    except (ValueError, TypeError):
        pass
    return True


def clear_account_captcha_block(account: str) -> None:
    """Manually clear captcha block for an account."""
    store = _load_captcha_block_store()
    if account in store:
        del store[account]
        _save_captcha_block_store(store)


def get_all_captcha_block_status() -> dict[str, bool]:
    """Return {account_name: is_captcha_blocked} for all tracked accounts."""
    store = _load_captcha_block_store()
    result = {}
    for account in store:
        result[account] = is_account_captcha_blocked(account)
    return result


def get_next_available_account(
    exclude: set[str] | None = None,
    prefer_non_captcha: bool = True,
) -> str | None:
    """Find the next available Qwen account, preferring non-captcha-blocked ones.

    Selection priority when prefer_non_captcha=True:
      1. Fresh accounts (not exhausted, not captcha-blocked), lowest number first
      2. If no fresh accounts, return the earliest captcha-blocked account (oldest timestamp)
      3. Returns None only if all accounts are rate-limit exhausted

    Args:
        exclude: Set of account names to skip (e.g. already-tried in current request).
        prefer_non_captcha: If True, avoid captcha-blocked accounts unless no fresh ones exist.

    Returns:
        Account name (e.g. 'browser-data-acc3') or None if all exhausted.
    """
    import re as _re
    exclude = exclude or set()
    fresh: list[tuple[int, str]] = []
    captcha_blocked: list[tuple[str, int, str]] = []  # (timestamp, num, name)
    try:
        captcha_store = _load_captcha_block_store() if prefer_non_captcha else {}
        for entry in _SYSTEM.iterdir():
            m = _re.match(r"browser-data-acc(\d+)$", entry.name)
            if entry.is_dir() and m:
                name = entry.name
                if name in exclude:
                    continue
                if is_account_exhausted(name):
                    continue  # rate-limited accounts are fully skipped
                num = int(m.group(1))
                if prefer_non_captcha:
                    ts = captcha_store.get(name)
                    if ts and is_account_captcha_blocked(name):
                        captcha_blocked.append((ts, num, name))
                    else:
                        fresh.append((num, name))
                else:
                    fresh.append((num, name))
    except OSError:
        return None

    # Priority 1: fresh accounts, sorted by account number
    if fresh:
        fresh.sort(key=lambda t: t[0])
        return fresh[0][1]

    # Priority 2: earliest captcha-blocked account (oldest timestamp = most likely recovered)
    if captcha_blocked:
        captcha_blocked.sort(key=lambda t: t[0])  # oldest timestamp first
        return captcha_blocked[0][2]

    return None


def get_available_accounts_reverse(
    exclude: set[str] | None = None,
    limit: int = 5,
) -> list[str]:
    """Return up to `limit` available accounts sorted highest-number first.

    Used by background tasks (summarizer, consolidation, subagents) so they
    don't compete with the main chat auto-switch which searches forward.

    Skips rate-limit exhausted accounts. Includes captcha-blocked accounts
    (they may have recovered) but sorts them after fresh ones.

    Args:
        exclude: Account names to skip.
        limit: Max accounts to return (default 5).

    Returns:
        List of account names, highest number first.
    """
    import re as _re
    exclude = exclude or set()
    fresh: list[tuple[int, str]] = []
    captcha_blocked: list[tuple[int, str]] = []
    try:
        captcha_store = _load_captcha_block_store()
        for entry in _SYSTEM.iterdir():
            m = _re.match(r"browser-data-acc(\d+)$", entry.name)
            if entry.is_dir() and m:
                name = entry.name
                if name in exclude:
                    continue
                if is_account_exhausted(name):
                    continue
                num = int(m.group(1))
                ts = captcha_store.get(name)
                if ts and is_account_captcha_blocked(name):
                    captcha_blocked.append((num, name))
                else:
                    fresh.append((num, name))
    except OSError:
        return []

    # Sort descending (highest number first)
    fresh.sort(key=lambda t: t[0], reverse=True)
    captcha_blocked.sort(key=lambda t: t[0], reverse=True)

    result = [name for _, name in fresh]
    result.extend(name for _, name in captcha_blocked)
    return result[:limit]


def auto_switch_account(
    current_account: str,
    error_type: str,
    exclude: set[str] | None = None,
    reverse: bool = False,
) -> str | None:
    """Mark the failing account and find the next available one.

    Shared auto-switch logic used by both main chat and subagents.
    Mirrors the marking + selection from chat.py auto-switch handler.

    Args:
        current_account: The account that just failed (e.g. 'browser-data-acc3').
        error_type: One of 'rate_limited', 'waf_blocked', 'empty_exhausted'.
        exclude: Additional accounts to skip (already-tried in this request).
        reverse: If True, search highest-number-first (for subagents/background).
                 If False, search lowest-number-first (for main chat).

    Returns:
        Next account name or None if all exhausted.
    """
    import logging as _logging
    _logger = _logging.getLogger(__name__)

    # Mark the failing account
    if error_type == "waf_blocked":
        mark_account_captcha_blocked(current_account)
        _logger.info("[auto-switch] Marked %s as captcha-blocked", current_account)
    elif error_type == "empty_exhausted":
        mark_account_exhausted(current_account)
        _logger.info("[auto-switch] Marked %s as exhausted (empty_exhausted)", current_account)
    elif error_type == "rate_limited":
        mark_account_exhausted(current_account)
        _logger.info("[auto-switch] Marked %s as exhausted (rate_limited)", current_account)

    # Build exclusion set
    _exclude = set(exclude or {})
    _exclude.add(current_account)

    # Find next account
    if reverse:
        candidates = get_available_accounts_reverse(exclude=_exclude, limit=10)
        return candidates[0] if candidates else None
    else:
        return get_next_available_account(exclude=_exclude)


# --------------------------------------------------------------------------
# Tool output limits
# --------------------------------------------------------------------------
DEFAULT_MAX_TOOL_OUTPUT_CHARS = 100_000


def get_max_tool_output_chars() -> int:
    """Read tool output cap from system/settings.json (default 100k)."""
    try:
        import json as _json
        p = _SYSTEM / "settings.json"
        if p.is_file():
            data = _json.loads(p.read_text(encoding="utf-8"))
            val = data.get("max_tool_output_chars")
            if isinstance(val, int) and val > 0:
                return val
    except Exception:
        pass
    return DEFAULT_MAX_TOOL_OUTPUT_CHARS


# ── Per-provider account pinning ────────────────────────────────────────────
# settings.json: "provider_accounts": {"gemini": "browser-data-acc4", "zai": null}
# A provider mapped to an account name always uses that profile's browser.
# null / absent → follow the global active account (shared behavior).

# A provider may be referenced by a friendly name; the first key that exists
# in settings wins. Lets users write "gemini" while the backend is "gemini_web".
_PROVIDER_ALIASES: dict[str, tuple[str, ...]] = {
    "gemini_web": ("gemini_web", "gemini"),
    "zai": ("zai",),
    "qwen": ("qwen",),
    "deepseek": ("deepseek",),
}


def get_provider_account(provider: str) -> str | None:
    """Return the pinned account name for a provider, or None to follow active."""
    if not provider:
        return None
    try:
        import json as _json
        p = _SYSTEM / "settings.json"
        if p.is_file():
            data = _json.loads(p.read_text(encoding="utf-8"))
            mapping = data.get("provider_accounts")
            if isinstance(mapping, dict):
                for key in _PROVIDER_ALIASES.get(provider, (provider,)):
                    val = mapping.get(key)
                    if isinstance(val, str) and val.strip():
                        return val.strip()
    except Exception:
        pass
    return None


def set_provider_account(provider: str, account: str | None) -> None:
    """Pin (or clear, with None) a provider to a specific account."""
    import json as _json
    p = _SYSTEM / "settings.json"
    data: dict = {}
    if p.is_file():
        try:
            data = _json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    mapping = data.get("provider_accounts")
    if not isinstance(mapping, dict):
        mapping = {}
    if account:
        mapping[provider] = account
    else:
        mapping.pop(provider, None)
    data["provider_accounts"] = mapping
    p.write_text(_json.dumps(data, indent=2), encoding="utf-8")


def get_provider_browser_dir(provider: str) -> Path:
    """Resolve the browser data dir for a provider.

    Pinned account wins; otherwise follows the global active account.
    """
    pinned = get_provider_account(provider)
    if pinned:
        return _SYSTEM / pinned
    return get_browser_data_dir()



